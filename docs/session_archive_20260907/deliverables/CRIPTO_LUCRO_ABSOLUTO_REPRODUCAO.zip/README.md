# Reprodução v4 — lucro absoluto

Python 3.13 e dependências de requirements.txt. Na pasta extraída, `python REPRODUZIR.py` verifica os hashes e reconstrói todo o diagnóstico a partir das 616 respostas públicas gravadas; nenhuma consulta externa é feita. A nova hora de execução é diferente, mas dados, fontes, critérios, características, pontuação e seleção precisam ser idênticos. `python -m pytest -q tests` executa os 41 testes incluídos; cinco controles adicionais de congelamento passaram no repositório, totalizando 46.

O treino reparado está incluído. A auditoria integral de sua construção continua nos pacotes anteriores. Este pacote é suficiente para reproduzir o diagnóstico v4, não autoriza executar ordens e não contém contas/chaves. Não rode o acompanhamento sobre uma cópia do livro como se ela fosse o monitor ativo. O acompanhamento real desta tarefa usa work/altcoin-profit-data no worktree original, conforme RUNBOOK.

O objetivo é lucro líquido absoluto; não há carteira de referência externa. A permissão para escolher qualquer corretora não significa que o adaptador já cubra outras além da Binance pública. Os resultados anteriores permanecem preservados.
