# Reprodução da continuação

Este ZIP é um complemento do pacote ALTCOINS_REPRODUCAO.zip já entregue,
SHA256 56e24223d6e97e9240d7f0af907010b68ddaee6a734a12de7bf570fda8361789.
Extraia primeiro aquele pacote e depois este, na mesma pasta. O complemento
adiciona payoff-data e payoff-expected, preservando data/ e expected/ originais.
Use o Python 3.13 com as dependências daquele pacote.

    python -m pytest tests/test_altcoin_payoff.py -q
    python -m scripts.prepare_altcoin_payoff --base-data-dir data --base-results-dir expected --data-dir payoff-data --output-dir payoff-reproduced --offline

O modo --offline não consulta rede e falha se faltar uma resposta registrada.
Compare payoff-reproduced/results.json e samples_identity_corrected.json.gz
com payoff-expected/. O caso não tem ordens, scheduler ou promoção de modelo.

MANIFEST.json lista hashes dos membros, exceto o próprio manifesto.
