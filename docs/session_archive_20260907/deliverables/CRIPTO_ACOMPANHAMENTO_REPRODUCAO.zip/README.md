# Reprodução do piloto de observação

Este pacote reproduz o diagnóstico coletado em 07/09 e seus controles sem baixar preços novos. O artefato de treino reparado está incluído, com hash; a auditoria completa de sua formação continua nos pacotes ALTCOINS_REPRODUCAO e CRIPTO_CONTINUACAO_REPRODUCAO anteriores.

Python 3.13. Dependências em requirements.txt. Na pasta extraída:

```
python REPRODUZIR.py
python -m scripts.check_altcoin_forward_design --output design-reproduzido.json
python -m pytest -q tests
```

REPRODUZIR.py permite apenas respostas existentes no cache, verifica hashes e exige igualdade de todo o snapshot, exceto recorded_after_acquisition, que registra a nova execução. Os 39 testes deste pacote cobrem analogia, payoff e observador. No repositório também passaram cinco testes do congelamento, total 44.

Os registros da coleta original e seus caminhos de origem são preservados. Não executar tick sobre uma cópia do livro como se ela fosse o monitor ativo. O monitor ativo usa a pasta de trabalho original descrita no RUNBOOK, e somente ele deve escrever no livro. Não há execução de ordens neste código.

Todos os arquivos fornecidos constam de FILE_HASHES.json. O programa antigo que gravou o preflight é rastreado pelo commit cbe5229 e freeze_preflight.json; freeze.json corresponde ao observador com registro de alterações do catálogo, anterior à primeira decisão futura. O modelo e os preços do diagnóstico não foram modificados.
