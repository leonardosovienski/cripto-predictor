from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,shutil
W=Path(r'C:\Cripto\correcao-pr110-20260910')
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\closure110')
phase=sys.argv[1]
O=R/phase
O.mkdir(exist_ok=False)
T=Path(r'C:\Cripto\operacao\temporarios')/('continuity-'+phase)
T.mkdir(exist_ok=False)
(T/'empty.env').write_text('# Synthetic checks only\n',encoding='utf-8')
env=os.environ.copy()
for key in list(env):
    if any(x in key.upper() for x in ('API_KEY','AUTH_TOKEN','API_SECRET','SECRET_KEY')):env.pop(key,None)
env.update(CRIPTO_ENV_FILE=str(T/'empty.env'),GEMINI_API_KEY='test-gemini-key-for-unit-tests-only',SERP_API_KEY='test-serp-key-for-unit-tests-only',LLM_PROVIDER='gemini',GEMINI_MODEL='gemini-2.5-flash',PYTHONPATH=str(W),PYTHONIOENCODING='utf-8',PREDICTOR_EVENTS_PATH=str(T/'events.jsonl'),PREDICTOR_OPS_STATE_DIR=str(T/'state'),COVERAGE_FILE=str(O/'runtime.coverage'),PYRIGHT_PYTHON_CACHE_DIR=str(T/'pyright'))
env.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
for k in ('DATA','OUTPUT','CACHE','LOGS'):env[k+'_DIR']=env['GARIMPO_'+k+'_DIR']=str(T/k.lower())
py=str(W/'.venv/Scripts/python.exe')
uv=r'C:\Cripto\pesquisa-20260909\work\tooling\bin\uv.exe'
state={'started_at_utc':datetime.now(timezone.utc).isoformat(),'project':str(W),'phase':phase,'private_configuration_loaded':False,'checks':[]}
state['blas_thread_limits'] = {k: env[k] for k in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS')}
def check(name,args):
    now=datetime.now(timezone.utc).isoformat()
    p=subprocess.run(args,cwd=W,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
    (O/(name+'.log')).write_text(p.stdout+p.stderr,encoding='utf-8')
    row={'name':name,'command':args,'exit_code':p.returncode,'started_at_utc':now,'finished_at_utc':datetime.now(timezone.utc).isoformat()}
    state['checks'].append(row)
    (O/'validation.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    return p.returncode
check('ruff',[py,'-m','ruff','check','.'])
check('format',[py,'-m','ruff','format','--check','--diff','.'])
if phase == 'final02':
    state['scope'] = 'Complete suite after the Windows-only test expectation correction; unchanged runtime and prior build/type/coverage evidence retained in final01.'
    check('tests',[py,'-m','pytest','-q','-ra','--basetemp',str(T/'pytest'),'--junitxml',str(O/'tests.xml')])
else:
    check('pyright',[uv,'run','--no-sync','pyright'])
    check('scanner',[py,'scripts/scan_secrets.py','.'])
    check('h6_freeze',[py,'-m','scripts.freeze_h6_definition','--check'])
    check('build',[uv,'build'])
    check('tests',[py,'-m','coverage','run','--rcfile=coverage-runtime.ini','-m','pytest','-q','-ra','--basetemp',str(T/'pytest'),'--junitxml',str(O/'tests.xml')])
    check('coverage',[py,'-m','coverage','report','--rcfile=coverage-runtime.ini'])
    check('coverage_json',[py,'-m','coverage','json','--rcfile=coverage-runtime.ini','-o',str(O/'coverage.json')])
state['finished_at_utc']=datetime.now(timezone.utc).isoformat()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','*.py','*.toml','*.lock','.github/workflows/*'],cwd=W,text=True).splitlines()
state['source_hashes']={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in paths if (W/p).is_file()}
(O/'validation.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
raise SystemExit(any(c['exit_code'] for c in state['checks']))
