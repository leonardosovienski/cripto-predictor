import hashlib
import json
import os
import re
import subprocess
import sys
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import unquote

P = Path(sys.argv[1])
F = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\organization_20260910')
phase = sys.argv[2]
R = F.parent
names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=P).decode().split('\0')
tracked = set(filter(None, names))
rows, findings, historic, encoding = [], [], [], []
for name in sorted(n for n in tracked if n.lower().endswith('.md')):
    data = (P / name).read_bytes()
    try:
        body = data.decode('utf-8-sig')
    except UnicodeDecodeError:
        encoding.append(name)
        continue
    fence = None
    count = 0
    for line_number, line in enumerate(body.splitlines(), 1):
        marker = re.match(r'^\s*(?:>\s*)?(`{3,}|~{3,})', line)
        if marker:
            fence = marker.group(1)[0] if fence is None else (None if marker.group(1)[0] == fence else fence)
            continue
        if fence:
            continue
        for target in re.findall(r'!?\[[^\]\n]+\]\((<[^>]+>|[^()\s]+)(?:\s+["\'][^)]*)?\)', line):
            target = target.strip('<>')
            if target.startswith(('#', 'https:', 'http:', 'mailto:', 'data:')):
                continue
            count += 1
            target = unquote(target.split('#')[0].split('?')[0])
            local = Path(target) if re.match(r'^[a-zA-Z]:[/\\]', target) else P / Path(name).parent / target
            local = Path(os.path.abspath(local))
            kind = 'missing_local_target' if not local.exists() else ('local_only_target_inside_repo' if local.is_file() and local.is_relative_to(P) and local.relative_to(P).as_posix() not in tracked else None)
            if kind:
                row = {'file': name, 'line': line_number, 'target': target, 'kind': kind}
                origin = None
                if name == 'docs/evidence/remaining_dependencies_20260910/review_snapshot.md':
                    origin = R
                elif name.startswith('docs/continuity_20260909/local-root/'):
                    origin = Path(r'C:\Cripto')
                if origin is not None:
                    resolved = Path(os.path.abspath(origin / target))
                    row.update({'origin_directory': str(origin), 'local_target': str(resolved), 'local_target_exists': resolved.exists(), 'disposition': 'preserved_historical_bytes_use_original_base'})
                    historic.append(row)
                else:
                    findings.append(row)
    rows.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'lines': len(body.splitlines()), 'local_links': count})
result = {'at_utc': datetime.now(UTC).isoformat(), 'project': str(P), 'phase': phase, 'documents': len(rows), 'local_links_checked': sum(x['local_links'] for x in rows), 'utf8_errors': encoding, 'unresolved_current_links': findings, 'historical_context_links': len(historic), 'historical_targets_missing_at_origin': [x for x in historic if not x['local_target_exists']], 'scope': 'UTF-8 and local file destinations; not external URL availability or section-anchor verification.'}
for suffix, value in [('summary', result), ('inventory', rows), ('historical_links', historic)]:
    (F / f'{phase}_markdown_{suffix}.json').write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
