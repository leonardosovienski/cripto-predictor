from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
f=p/'GarimpoInvestimentos/v3/paper_trader.py';s=f.read_text(encoding='utf-8');a=s.index('"""',3)+3
s='''"""Theoretical paper ledger, subject to the scientific family freeze.

Historical cached signals are not prospective observations. New records require
an open family and a current decision timestamp. No orders or capital are enabled.
"""'''+s[a:]
s=s.replace('import logging\n','import logging\nimport math\n')
s=s.replace('from GarimpoInvestimentos.core.paths import DATA_DIR','from GarimpoInvestimentos.core.paths import DATA_DIR\nfrom GarimpoInvestimentos.durable_io import file_lock, atomic_write\nfrom GarimpoInvestimentos.governance import load_scientific_state\nfrom GarimpoInvestimentos.analyzers.trials import FrozenFamilyError\nfrom GarimpoInvestimentos.v3.collectors.record_io import validate_observation')
s=s.replace('    return _PAPER_DIR / f"{symbol}_paper.jsonl"','    validate_observation(symbol, 0, {})\n    return _PAPER_DIR / f"{symbol}_paper.jsonl"')
a=s.index('        try:\n            if json.loads(line)');b=s.index('    return False',a)
s=s[:a]+'''        row = json.loads(line)
        if not isinstance(row, dict):
            raise ValueError("historico paper invalido")
        if row.get("timestamp_exchange_ms") == timestamp_exchange_ms:
            return True
''' + s[b:]
a=s.index('def _record_paper_trade(')
s=s[:a]+'''def _require_open_family() -> None:
    if "funding_oi_hmm_v3" in load_scientific_state().frozen_families:
        raise FrozenFamilyError("Paper V3 bloqueado: funding_oi_hmm_v3 esta congelada; preservar livro existente")


''' + s[a:]
s=s.replace('    position = signal.direction * signal.strength * kelly_fraction','    _require_open_family()\n    if not math.isfinite(kelly_fraction) or not 0 < kelly_fraction <= 1 or ref_price is None or not math.isfinite(ref_price) or ref_price <= 0:\n        raise ValueError("paper exige preco valido e fracao em (0,1]")\n    now_ms = int(datetime.now(UTC).timestamp() * 1000)\n    if not 0 <= now_ms - signal.timestamp_signal_ms <= 300_000 or not 0 <= now_ms - signal.timestamp_exchange_ms <= 8 * _SPOT_CANDLE_MS:\n        raise ValueError("sinal desatualizado nao pode ser registrado como prospectivo")\n    position = signal.direction * signal.strength * kelly_fraction',1)
s=s.replace('        "symbol": symbol,\n        "timestamp_exchange_ms": signal.timestamp_exchange_ms,','        "symbol": symbol,\n        "recording_mode": "SHADOW_REFERENCE_CLOSE_ONLY",\n        "capital_enabled": False,\n        "timestamp_entry_ms": now_ms,\n        "timestamp_exchange_ms": signal.timestamp_exchange_ms,',1)
a=s.index('    path.parent.mkdir(parents=True, exist_ok=True)',s.index('def _record_paper_trade'));b=s.index('    # Telemetria estruturada',a)
s=s[:a]+'''    with file_lock(path):
        if _already_recorded(symbol, signal.timestamp_exchange_ms):
            raise ValueError("sinal paper ja registrado")
        original = path.read_bytes() if path.exists() else b""
        separator = b"\\n" if original and not original.endswith(b"\\n") else b""
        atomic_write(path, original + separator + (json.dumps(paper, ensure_ascii=False, allow_nan=False) + "\\n").encode("utf-8"))

''' + s[b:]
s=s.replace('    signals = await run_symbol(','    _require_open_family()\n    validate_observation(symbol, 0, {})\n    signals = await run_symbol(',1)
s=s.replace('_ref_price(latest.timestamp_exchange_ms, spot_index)','_ref_price(int(datetime.now(UTC).timestamp() * 1000), spot_index)')
s=s.replace('default homologado','default historico de pesquisa')
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/v3/paper_report.py';s=f.read_text(encoding='utf-8');a=s.index('"""',3)+3
s='''"""Descriptive gross returns from a theoretical ledger; not realized profit.

Per-row horizons and reference dates are preserved. Legacy retrospective records
are counted explicitly and do not become prospective evidence. Costs, allocation,
execution and an intratrade mark path are absent: no portfolio P&L or MaxDD is certified.
"""'''+s[a:]
s=s.replace('from pathlib import Path','from pathlib import Path\nfrom datetime import UTC, datetime')
s=s.replace('from GarimpoInvestimentos.v3.collectors.spot_collector import load_spot_csv','from GarimpoInvestimentos.v3.collectors.spot_collector import load_spot_csv\nfrom GarimpoInvestimentos.v3.collectors.record_io import validate_observation')
s=s.replace('    return _PAPER_DIR / f"{symbol}_paper.jsonl"','    validate_observation(symbol, 0, {})\n    return _PAPER_DIR / f"{symbol}_paper.jsonl"')
s=s.replace('    trades = []\n    with open','    trades = []\n    identities = set()\n    with open',1)
s=s.replace('                trades.append(json.loads(line))','                row = json.loads(line)\n                if not isinstance(row, dict) or row.get("symbol") != symbol:\n                    raise ValueError("registro paper invalido")\n                identity = row["timestamp_exchange_ms"]\n                if identity in identities:\n                    raise ValueError("registro paper duplicado")\n                identities.add(identity)\n                trades.append(row)')
s=s.replace('    equity, acc = [], 1.0','    equity, acc = [1.0], 1.0')
s=s.replace('    trades = _load_paper_trades(symbol)','    if isinstance(horizon_hours, bool) or not isinstance(horizon_hours, int) or horizon_hours <= 0:\n        raise ValueError("horizon_hours deve ser inteiro positivo")\n    trades = _load_paper_trades(symbol)',1)
s=s.replace('        "cum_pnl": 0.0,\n        "max_dd": 0.0,','        "cum_pnl": None,  # compatibility alias: sum of gross trade returns, not portfolio P&L\n        "sum_gross_trade_returns": None,\n        "max_dd": None,\n        "scientific_state": "DESCRIPTIVE_REPLAY",\n        "capital_enabled": False,\n        "portfolio_metrics_status": "UNAVAILABLE_ALLOCATION_COSTS_EXECUTION_AND_MARK_PATH",\n        "retrospective_records": 0,')
s=s.replace('    ms_horizon = horizon_hours * 3_600_000','    time_index = SortedTimeIndex(spot_index)')
s=s.replace('        entry_ms = t.get("timestamp_exchange_ms")','        entry_ms = t.get("timestamp_entry_ms", t.get("timestamp_exchange_ms"))\n        row_horizon = t.get("horizon_hours", horizon_hours)\n        if not isinstance(row_horizon, int) or row_horizon < 0:\n            raise ValueError("horizonte paper invalido")\n        recorded = datetime.fromisoformat(t["signal_ts_utc"])\n        if recorded.tzinfo is None:\n            raise ValueError("paper exige timestamp com timezone")\n        if "timestamp_entry_ms" not in t or int(recorded.astimezone(UTC).timestamp() * 1000) > entry_ms + 300_000:\n            summary["retrospective_records"] += 1')
s=s.replace('        exit_px = _closest_price(entry_ms + ms_horizon, spot_index)','        if not math.isfinite(position):\n            raise ValueError("position deve ser finita")\n        if position != 0 and row_horizon == 0:\n            raise ValueError("posicao ativa sem horizonte")\n        exit_px = time_index.as_of(entry_ms + row_horizon * _SPOT_CANDLE_MS - _SPOT_CANDLE_MS, _PRICE_TOLERANCE_MS)')
s=s.replace('if exit_px is None or entry_px <= 0:','if exit_px is None or not math.isfinite(entry_px) or not math.isfinite(exit_px) or entry_px <= 0 or exit_px <= 0:')
s=s.replace('        fwd = math.log(exit_px / entry_px)\n        pnl = position * fwd','        pnl = position * (exit_px / entry_px - 1)')
s=s.replace('        summary["max_dd"] = round(max_drawdown(_equity_curve(returns)), 6)','        summary["sum_gross_trade_returns"] = summary["cum_pnl"]')
s=s.replace('    logger.info("P&L acumulado (log): %+.4f", s["cum_pnl"])\n    logger.info("MaxDD corrente     : %.2f%%", s["max_dd"] * 100)','    logger.info("Soma bruta de retornos por trade: %s", s["sum_gross_trade_returns"])\n    logger.info("PnL/MaxDD de carteira nao estimaveis: %s", s["portfolio_metrics_status"])')
s=s.replace('            "cum_pnl": float(s["cum_pnl"]),\n            "max_dd": float(s["max_dd"]),','            **({"sum_gross_trade_returns": float(s["cum_pnl"])} if s["cum_pnl"] is not None else {}),')
s=s.replace('metadata={"symbol": s["symbol"], "by_regime": s["by_regime"], "by_reason": s["by_reason"]},','metadata={"symbol": s["symbol"], "by_regime": s["by_regime"], "by_reason": s["by_reason"], "scientific_state": s["scientific_state"], "portfolio_metrics_status": s["portfolio_metrics_status"]},')
f.write_text(s,encoding='utf-8')
