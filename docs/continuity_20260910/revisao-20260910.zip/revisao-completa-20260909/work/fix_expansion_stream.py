from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
f=p/'GarimpoInvestimentos/trading/binance_spot_collector.py';s=f.read_text(encoding='utf-8')
s=s.replace('        self.synchronizers[symbol].install_snapshot(observation)','        self.synchronizers[symbol].install_snapshot(observation)\n        self.store.record_health("resnapshot", symbol)')
s=s.replace('            self.store.new_session()','            self.store.new_session()\n            for sync in self.synchronizers.values():\n                sync.invalidate()')
a=s.index('                    # Start consuming');b=s.index('            except asyncio.CancelledError:',a)
s=s[:a]+'''                    async def consume() -> None:
                        async for message in ws:
                            await self.handle(message)
                            self.store.heartbeat()

                    consumer = asyncio.create_task(consume())
                    snapshots = [asyncio.create_task(self.resnapshot(s)) for s in self.symbols]
                    stopped = asyncio.create_task(shutdown.wait())
                    tasks = [consumer, stopped, *snapshots]
                    pending = set(tasks)
                    try:
                        async with asyncio.timeout(23 * 60 * 60):
                            while pending:
                                done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
                                if stopped in done:
                                    return
                                for task in done:
                                    task.result()
                                if consumer in done:
                                    raise ConnectionError("stream encerrou sem shutdown")
                                if all(task.done() for task in snapshots):
                                    backoff = 1.0
                    finally:
                        for task in tasks:
                            task.cancel()
                        await asyncio.gather(*tasks, return_exceptions=True)
''' + s[b:]
s=s.replace('                await asyncio.sleep(min(60.0, backoff) * random.uniform(0.8, 1.2))','                try:\n                    await asyncio.wait_for(shutdown.wait(), timeout=min(60.0, backoff) * random.uniform(0.8, 1.2))\n                except TimeoutError:\n                    pass')
s=s.replace('return Path("data") / "binance_spot_microstructure.sqlite3"','return DATA_DIR / "binance_spot_microstructure.sqlite3"')
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/trading/microstructure_quality.py';s=f.read_text(encoding='utf-8')
s=s.replace('from GarimpoInvestimentos.trading.store','from GarimpoInvestimentos.trading.contracts import ensure_utc, require_finite\nfrom GarimpoInvestimentos.trading.store',1)
s=s.replace('    now = (now or datetime.now(UTC)).astimezone(UTC)','    now = ensure_utc(now or datetime.now(UTC), "now")\n    require_finite(stale_seconds, "stale_seconds")\n    if stale_seconds <= 0:\n        raise ValueError("stale_seconds deve ser positivo")')
s=s.replace('            if age > stale_seconds:','            if age < 0:\n                findings.append(WatchdogFinding("critical", symbol, kind, "received_in_future"))\n            if kind != "snapshot" and age > stale_seconds:')
s=s.replace('            if row["scientific_state"]','            if kind == "snapshot":\n                depth = latest.get((symbol, "depth"))\n                if depth and depth["session_id"] != row["session_id"]:\n                    findings.append(WatchdogFinding("critical", symbol, kind, "snapshot_session_mismatch"))\n            if row["scientific_state"]')
s=s.replace('    result: list[dict[str, Any]] = []','    health = store._conn.execute("SELECT symbol,COUNT(*) AS n FROM collector_health WHERE metric=\'resnapshot\' AND recorded_at>=? AND recorded_at<? GROUP BY symbol", (start.isoformat(), (start + timedelta(days=1)).isoformat())).fetchall()\n    resync_counts = {row["symbol"]: row["n"] for row in health}\n    result: list[dict[str, Any]] = []',1)
s=s.replace('            previous_sequence: int | None = None','            previous_sequences: dict[str, int] = {}\n            observed_minutes: set[int] = set()')
s=s.replace('                ingest_latencies.append','                observed_minutes.add(int((received - start).total_seconds() // 60))\n                temporal += int(ingested < received)\n                ingest_latencies.append',1)
a=s.index('                if (\n                    kind == "depth"');b=s.index('                if kind == "bbo":',a)
s=s[:a]+'''                payload = json.loads(row["payload_json"])
                if kind == "depth":
                    previous = previous_sequences.get(row["session_id"])
                    if previous is not None and not (payload["first_update_id"] <= previous + 1 <= payload["final_update_id"]):
                        gaps += 1
                    previous_sequences[row["session_id"]] = sequence
                if kind == "snapshot":
                    crossed += int(not payload["bids"] or not payload["asks"] or payload["bids"][0][0] >= payload["asks"][0][0])
''' + s[b:]
s=s.replace('"coverage": int(bool(selected)),','"coverage": len(observed_minutes) / 1440 if kind != "snapshot" else None,\n                    "coverage_definition": "fraction of UTC minute bins containing an observation; not continuous uptime",')
s=s.replace('"resynchronizations": 0,','"resynchronizations": resync_counts.get(symbol, 0) if kind in {"depth", "snapshot"} else None,')
f.write_text(s,encoding='utf-8')
# Fixture must reference its actual order; mismatched order identity is invalid.
f=p/'tests/test_trading_contracts.py';s=f.read_text(encoding='utf-8');s=s.replace('def test_order_avg_fill_price_and_remaining_qty():\n    order = Order(\n        order_id=new_id("order"),','def test_order_avg_fill_price_and_remaining_qty():\n    order = Order(\n        order_id="o1",');f.write_text(s,encoding='utf-8')
