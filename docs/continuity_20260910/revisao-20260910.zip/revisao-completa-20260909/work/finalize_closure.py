from pathlib import Path
from datetime import UTC, datetime
import importlib.metadata
import json
import subprocess
import xml.etree.ElementTree as ET

R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
P = Path(r'C:\Cripto\pesquisa-20260909')
N = Path(r'C:\Cripto\fechamento-revisao-20260910')
def read(path): return json.loads((R/path).read_text(encoding='utf-8-sig'))
def git(path, *args): return subprocess.check_output(['git',*args],cwd=path,text=True).strip()
head = 'ac4184e7d3377a8f14aeebac5016c3e18f82cfcf'
ci = read('closure_audit/ci_main.json')
post = read('postmerge_closure01/validation.json')
state = read('closure_audit/after_validation.json')
assert ci['four_jobs_passed'] and ci['head'] == head
assert post['head'] == head and post.get('finished_at_utc') and all(c['exit_code'] == 0 for c in post['checks'])
cases = ET.parse(R/'postmerge_closure01/tests.xml').getroot().findall('.//testcase')
skips = sum(c.find('skipped') is not None for c in cases)
failures = sum(c.find('failure') is not None or c.find('error') is not None for c in cases)
passed = len(cases)-skips-failures
assert (passed,skips,failures) == (1505,1,0)
assert git(P,'rev-parse','HEAD') == head == git(P,'ls-remote','origin','refs/heads/main').split()[0]
assert git(P,'rev-parse','HEAD^{tree}') == git(N,'rev-parse','HEAD^{tree}')
assert state['budget_matches_reservation'] and state['operational_status'] == 'M docs/NEXT_CHAT_PROMPT.md'
direct = json.loads(importlib.metadata.distribution('cripto-predictor').read_text('direct_url.json'))
assert 'pesquisa-20260909' in direct['url'] and direct['dir_info']['editable']
llm, carry = read('closure_audit/llm_status.json'), read('closure_audit/carry_status.json')
assert llm['counts'] == {'FUTURE':84}
assert carry['phase'] == 'WAITING' and carry['ledger_rows'] == carry['orders_sent'] == 0 and not carry['entry_observed']
result = {
    'at_utc':datetime.now(UTC).isoformat(),
    'summary':'PR #116 integrado em ac4184e. Suíte Windows do commit final e pós-merge: 1.505 aprovados, zero falhas e um skip. Quatro jobs aprovados no PR e no main. Correção adicional de isolamento e erratas documentais concluídas; dependências de dados/evidência/tempo permanecem abertas.',
    'pr':116,'head':'19da2534baec32028f330d217c32588df35ce19b','merge':head,
    'tree':git(P,'rev-parse','HEAD^{tree}'),'pr_run':34518776001,'main_run':34520193415,
    'pr_four_jobs_passed':True,'main_four_jobs_passed':True,
    'postmerge_passed':passed,'postmerge_skipped':skips,'postmerge_failed':failures,
    'editable_installation':direct['url'],'owner_prompt_preserved':True,
    'frozen_llm_checkout_preserved':True,'operational_budget_preserved':True,
    'llm_counts':llm['counts'],'carry_phase':carry['phase'],
    'readiness':'engineering corrected in reviewed scope; current snapshot pending; historical and future evidence incomplete; no personal/prospective profit validated',
}
(R/'closure_audit/integration.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
