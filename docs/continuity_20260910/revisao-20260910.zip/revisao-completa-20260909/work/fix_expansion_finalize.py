from pathlib import Path

P = Path(r'C:\Cripto\auditoria-ampliada-20260910')
def edit(name, old, new):
    p=P/name
    text=p.read_text(encoding='utf-8')
    assert old in text, (name,old[:80])
    p.write_text(text.replace(old,new),encoding='utf-8')

edit('GarimpoInvestimentos/trading/portfolio.py', '    assets = sorted(returns_by_asset)\n', '''    for asset, values in returns_by_asset.items():
        _require_paired_series(values, values, f"correlation_matrix:{asset}")
        if _variance(values) == 0:
            raise ValueError(f"correlation_matrix:{asset}: variancia zero")
    assets = sorted(returns_by_asset)
''')
edit('GarimpoInvestimentos/v3/paper_trader.py', '    for line in path.read_text(encoding="utf-8").splitlines():', '    found = False\n    for line in path.read_text(encoding="utf-8").splitlines():')
edit('GarimpoInvestimentos/v3/paper_trader.py', '            return True\n    return False', '            found = True\n    return found')
edit('GarimpoInvestimentos/v3/paper_report.py', '    # P&L realizado: precisa do preço D+horizon (spot)', '''    for row in trades:
        recorded = datetime.fromisoformat(row["signal_ts_utc"])
        if recorded.tzinfo is None:
            raise ValueError("paper exige timestamp com timezone")
        entry = row.get("timestamp_entry_ms")
        if entry is None or int(recorded.astimezone(UTC).timestamp() * 1000) > entry + 300_000:
            summary["retrospective_records"] += 1

    # Retorno bruto descritivo: precisa do preco no horizonte de cada registro.''')
edit('GarimpoInvestimentos/v3/paper_report.py', '''        recorded = datetime.fromisoformat(t["signal_ts_utc"])
        if recorded.tzinfo is None:
            raise ValueError("paper exige timestamp com timezone")
        if "timestamp_entry_ms" not in t or int(recorded.astimezone(UTC).timestamp() * 1000) > entry_ms + 300_000:
            summary["retrospective_records"] += 1
''','')
edit('GarimpoInvestimentos/v3/macro_features.py', '    if window_days < 0:', '    if isinstance(window_days, bool) or not isinstance(window_days, int) or window_days < 0:')
edit('GarimpoInvestimentos/v3/macro_features.py', '    event_dates = [e.event_date for e in ev]', '''    if not assume_calendar_known:
        years = {event.event_date.year for event in ev}
        if not ev or any(_ts_to_date(fv.timestamp_exchange_ms).year not in years for fv in feature_vectors):
            raise ValueError("Calendario sem cobertura para os anos das features")
    event_dates = [e.event_date for e in ev]''')
edit('GarimpoInvestimentos/dpl/macro_calendar.py', '''    published_at = timestamp: conservador de propósito. A data do evento já é
    pública com meses de antecedência (o piso real seria bem mais cedo), então
    usar o próprio dia como published_at nunca introduz look-ahead — só é mais
    cauteloso do que precisaria ser."""''', '''    A versao atual e datada pelo recebimento. A disponibilidade historica das
    datas exige uma copia arquivada: o dia do evento nao prova publicacao."""''')
edit('GarimpoInvestimentos/durable_io.py', 'def load_json_history(path: Path) -> list[dict]:', '''def _reject_constant(value: str):
    raise ValueError(f"JSON nao finito: {value}")


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Chave JSON duplicada: {key}")
        result[key] = value
    return result


def strict_json_loads(value: str) -> object:
    return json.loads(value, parse_constant=_reject_constant, object_pairs_hook=_unique_object)


def load_json_history(path: Path) -> list[dict]:''')
edit('GarimpoInvestimentos/durable_io.py', '    data = json.loads(path.read_text(encoding="utf-8"))', '    data = strict_json_loads(path.read_text(encoding="utf-8"))')

b='GarimpoInvestimentos/v3/backtest_v3.py'
edit(b,'import argparse\n','import argparse\nimport hashlib\nimport uuid\n')
edit(b,'from datetime import datetime','from datetime import UTC, datetime')
edit(b,'from dataclasses import dataclass','from dataclasses import asdict, dataclass')
edit(b,'from GarimpoInvestimentos.analyzers.trials import TRIALS_PATH, register_trial','from GarimpoInvestimentos.analyzers.trials import FrozenFamilyError, TRIALS_PATH, register_trial\nfrom GarimpoInvestimentos.governance import load_scientific_state\nfrom GarimpoInvestimentos.durable_io import atomic_write\nfrom GarimpoInvestimentos.dpl.macro_calendar import DEFAULT_CALENDAR_PATH\nfrom GarimpoInvestimentos.v3.collectors.record_io import validate_observation')
edit(b,'    execution_assumption: str = (','    returns_artifact: str | None = None\n    diagnostic_verdict: str = "UNCOMPUTED"\n    sharpe_basis: str = "per_signal_unannualized_sample_std"\n    psr_assumption: str = "IID diagnostic; overlapping trades and selection invalidate confidence"\n    execution_assumption: str = (')
edit(b,'    return (mean_r / downside_std) * math.sqrt(len(returns))','    return mean_r / downside_std')
edit(b,'    if not math.isfinite(kelly_fraction) or not 0 < kelly_fraction <= 1:', '''    validate_observation(symbol, 0, {})
    CostModel(taker_fee_bps=taker_fee_bps, slippage_bps=slippage_bps)
    for value, label in ((stop_loss_bps, "stop_loss_bps"), (take_profit_bps, "take_profit_bps"), (fr_zscore_threshold, "fr_zscore_threshold"), (minimum_net_edge, "minimum_net_edge")):
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"{label} deve ser finito e nao negativo")
    if not math.isfinite(min_regime_confidence) or not 0 <= min_regime_confidence <= 1:
        raise ValueError("min_regime_confidence deve estar em [0,1]")
    if not math.isfinite(kelly_fraction) or not 0 < kelly_fraction <= 1:''')
edit(b,'    sym_dir = _DATA_ROOT / symbol\n','''    sym_dir = _DATA_ROOT / symbol
    input_paths = [sym_dir / name for name in ("funding.csv", "oi.csv", "spot_binance_1h.csv")]
    if use_macro_dxy:
        input_paths.extend([dxy_closes_path, DEFAULT_CALENDAR_PATH])
    input_hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in input_paths if path is not None and path.exists()}
    parameters = {
        "symbol": symbol, "slippage_bps": slippage_bps, "taker_fee_bps": taker_fee_bps,
        "horizon_hours": horizon_hours, "fr_window": fr_window, "kelly_fraction": kelly_fraction,
        "stop_loss_bps": stop_loss_bps, "take_profit_bps": take_profit_bps,
        "fr_zscore_threshold": fr_zscore_threshold, "min_regime_confidence": min_regime_confidence,
        "cost_aware_filter": cost_aware_filter, "minimum_edge_calibration_sample": minimum_edge_calibration_sample,
        "minimum_net_edge": minimum_net_edge, "use_macro_dxy": use_macro_dxy,
        "macro_window_days": macro_window_days, "dxy_closes_path": str(dxy_closes_path) if dxy_closes_path else None,
        "macro_calendar_available_at": macro_calendar_available_at.isoformat() if macro_calendar_available_at else None,
        "use_oi_volume_ratio": use_oi_volume_ratio, "is_days": _IS_DAYS, "oos_days": _OOS_DAYS,
        "purge_days": _PURGE_DAYS, "step_days": _STEP_DAYS, "hmm_random_state": 42,
        "family": "funding_oi_hmm_v3", "sharpe_basis": "per_signal_unannualized_sample_std",
    }
''')
edit(b,'            std_r = math.sqrt(sum((r - mean_r) ** 2 for r in fold_pnl) / len(fold_pnl))\n            fold_sharpe = (mean_r / std_r) * math.sqrt(len(fold_pnl)) if std_r > 1e-12 else 0.0','            std_r = math.sqrt(sum((r - mean_r) ** 2 for r in fold_pnl) / (len(fold_pnl) - 1))\n            fold_sharpe = mean_r / std_r if std_r > 1e-12 else 0.0')
edit(b,'std_r = math.sqrt(sum((r - mean_r) ** 2 for r in all_oos_returns) / len(all_oos_returns))','std_r = math.sqrt(sum((r - mean_r) ** 2 for r in all_oos_returns) / (len(all_oos_returns) - 1))')
edit(b,'(mean_r / std_r) * math.sqrt(len(all_oos_returns)) if std_r > 1e-12 else 0.0','mean_r / std_r if std_r > 1e-12 else 0.0')
edit(b,'        final_verdict=final_verdict,\n        verdict_reason=verdict_reason,','''        final_verdict="UNVALIDATED",
        diagnostic_verdict=final_verdict,
        verdict_reason="Economic validation unavailable: spot proxy, uncalibrated fills/costs, overlapping-return IID PSR. Diagnostic: " + verdict_reason,''')
p=P/b
s=p.read_text(encoding='utf-8')
start=s.index('    _log_summary(result)\n')
end=s.index('    return result\n',start)
s=s[:start]+'''    # Never overwrite the legacy wfa_returns.json or another run's evidence.
    for source, digest in input_hashes.items():
        if hashlib.sha256(Path(source).read_bytes()).hexdigest() != digest:
            raise RuntimeError(f"Input changed during WFA: {source}")
    run_id = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%fZ") + "-" + uuid.uuid4().hex[:12]
    artifact = sym_dir / "research_runs" / run_id / "returns.json"
    result.returns_artifact = str(artifact)
    atomic_write(artifact, (json.dumps({
        "schema_version": "wfa-descriptive/2", "run_id": run_id,
        "created_at_utc": datetime.now(UTC).isoformat(),
        "parameters": parameters, "input_sha256": input_hashes,
        "result": asdict(result), "net": all_oos_returns, "gross": all_gross_returns,
        "closed_trade_equity": agg_equity,
        "net_interval_assumption": "descriptive moving block bootstrap; not post-selection confidence",
    }, ensure_ascii=False, allow_nan=False, indent=2) + "\\n").encode("utf-8"))
    _log_summary(result)
    _emit_result(result)
'''+s[end:]
p.write_text(s,encoding='utf-8')
edit(b,'def run_kelly_sweep(\n','''def _require_open_sweep() -> str:
    if "funding_oi_hmm_v3" in load_scientific_state().frozen_families:
        raise FrozenFamilyError("Varredura V3 bloqueada: familia funding_oi_hmm_v3 congelada")
    attestation = TRIALS_PATH.with_name(f"{TRIALS_PATH.stem}.harness_attestation.json")
    return json.loads(attestation.read_text(encoding="utf-8"))["pipeline_fingerprint"]


def run_kelly_sweep(
''')
edit(b,'    results: list[WFAResult] = []\n    for kf in kelly_fractions:', '''    fingerprint = _require_open_sweep()
    if not kelly_fractions or len(set(kelly_fractions)) != len(kelly_fractions) or any(not math.isfinite(k) or not 0 < k <= 1 for k in kelly_fractions):
        raise ValueError("Kelly sweep exige fracoes unicas em (0,1]")
    attempts = []
    for kf in kelly_fractions:
        params = {"symbol": symbol, "kelly_fraction": kf, "slippage_bps": slippage_bps, "taker_fee_bps": taker_fee_bps, "horizon_hours": horizon_hours, "fr_window": fr_window, "family": "funding_oi_hmm_v3", "selection_family": "kelly_sweep", "sharpe_basis": "per_signal_unannualized_sample_std"}
        name = "v3-kelly-" + symbol.lower() + "-" + hashlib.sha256(json.dumps(params, sort_keys=True).encode()).hexdigest()[:16]
        register_trial(name, params=params, metric="psr", pipeline_fingerprint=fingerprint, notes="registered before all results; descriptive only")
        attempts.append((name, params))
    results: list[WFAResult] = []
    for kf in kelly_fractions:''')
edit(b,'        results.append(r)\n\n    # Tabela comparativa','''        results.append(r)
        name, params = attempts[len(results) - 1]
        register_trial(name, params=params, sharpe=r.aggregate_sharpe, notes="completed; descriptive only")

    # Tabela comparativa''')
edit(b,'    attestation_path = TRIALS_PATH.with_name(f"{TRIALS_PATH.stem}.harness_attestation.json")\n    attestation = json.loads(attestation_path.read_text(encoding="utf-8"))\n    fingerprint = attestation["pipeline_fingerprint"]','''    fingerprint = _require_open_sweep()
    if not fr_thresholds or not confidence_thresholds or len(set(fr_thresholds)) != len(fr_thresholds) or len(set(confidence_thresholds)) != len(confidence_thresholds):
        raise ValueError("Threshold grid exige listas nao vazias e unicas")
    if any(not math.isfinite(v) or v < 0 for v in fr_thresholds) or any(not math.isfinite(v) or not 0 <= v <= 1 for v in confidence_thresholds):
        raise ValueError("threshold invalido")''')
edit(b,'                "selection_family": "threshold_grid",','                "selection_family": "threshold_grid",\n                "sharpe_basis": "per_signal_unannualized_sample_std",')
edit(b,'            # Registra TODAS as combinações antes de olhar qualquer resultado.','            name += "-" + hashlib.sha256(json.dumps(params, sort_keys=True).encode()).hexdigest()[:16]\n            # Registra TODAS as combinações antes de olhar qualquer resultado.')
edit(b,'                "final_verdict": r.final_verdict,','                "final_verdict": r.final_verdict,') if False else None
edit(b,'    parser.add_argument(\n        "--dxy-closes",','''    parser.add_argument("--macro-calendar-available-at", type=datetime.fromisoformat, default=None,
                        help="UTC documented availability of this exact calendar version; required for H7.")
    parser.add_argument(
        "--dxy-closes",''')
edit(b,'                    dxy_closes_path=args.dxy_closes,','                    dxy_closes_path=args.dxy_closes,\n                    macro_calendar_available_at=args.macro_calendar_available_at,')
edit(b,'CSV local (colunas: date,close)', 'CSV local (colunas: date,close,published_at)')
edit(b,'não sobre um período calendário fixo', 'sem anualizacao; a serie nao tem periodo calendario fixo')
edit(b,'mean/desvio × sqrt(N) sobre a própria amostra de trades,', 'mean/downside_deviation sobre a amostra de sinais,')
edit('tests/test_v3_macro_dxy_integration.py','assert result.final_verdict in ("GO", "NO-GO")', 'assert result.final_verdict == "UNVALIDATED"\n    assert result.diagnostic_verdict in ("GO", "NO-GO")\n    assert Path(result.returns_artifact).is_file()')
edit('tests/test_v3_macro_dxy_integration.py','import csv\n','import csv\nfrom pathlib import Path\n')
