from pathlib import Path

R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
source=(R/'work/run_checks.py').read_text(encoding='utf-8')
source=source.replace('ENV.update({', 'ENV.update({"OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1",')
marker='    state["packages"] = {d.metadata["Name"]: d.version for d in importlib.metadata.distributions()}\n    check("tests",'
replacement='''    state["packages"] = {d.metadata["Name"]: d.version for d in importlib.metadata.distributions()}
    check("build", [CMD, "uv", "build", "--out-dir", str(RUN / "dist")])
    for artifact in (RUN / "dist").iterdir():
        previous = PROJECT / "dist" / artifact.name
        if previous.exists():
            (RUN / "previous_dist").mkdir(exist_ok=True)
            shutil.copy2(previous, RUN / "previous_dist" / artifact.name)
        shutil.copy2(artifact, previous)
    check("windows_status", [CMD, "status"])
    check("windows_help", [CMD, "pipeline", "--help"])
    check("tests",'''
assert marker in source
source=source.replace(marker,replacement)
assert 'OMP_NUM_THREADS' in source
(R/'work/run_postmerge_expansion.py').write_text(source,encoding='utf-8')
print('prepared postmerge runner; not executed')
