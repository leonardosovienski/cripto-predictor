import importlib.metadata
import json
import re
import subprocess
import xml.etree.ElementTree as ET
from datetime import UTC, datetime
from pathlib import Path

R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
L = R / 'publication_chat_20260910'
P = Path(r'C:\Cripto\pesquisa-20260909')
N = Path(r'C:\Cripto\publicacao-conferencia-20260910')

def read(path):
    return json.loads(path.read_bytes())

def git(path, *args):
    return subprocess.check_output(['git', *args], cwd=path, text=True).strip()

pr, main = read(L / 'ci_pr.json'), read(L / 'ci_main.json')
post = read(R / 'postmerge_publication01/validation.json')
state = read(L / 'state_after.json')
head = main['head']
assert pr['four_jobs_passed'] and main['four_jobs_passed']
assert pr['head'] == '08dc4f7548d082d528047ed430087607388cc253'
assert post['head'] == head == state['head']
assert post.get('finished_at_utc') and all(c['exit_code'] == 0 for c in post['checks'])
cases = ET.parse(R / 'postmerge_publication01/tests.xml').getroot().findall('.//testcase')
skips = sum(c.find('skipped') is not None for c in cases)
failures = sum(c.find('failure') is not None or c.find('error') is not None for c in cases)
passed = len(cases) - skips - failures
assert (passed, skips, failures) == (1505, 1, 0)
assert git(P, 'rev-parse', 'HEAD') == head == git(P, 'ls-remote', 'origin', 'refs/heads/main').split()[0]
assert git(P, 'rev-parse', 'HEAD^{tree}') == git(N, 'rev-parse', 'HEAD^{tree}')
assert state['status'] == 'PASS'
direct = json.loads(importlib.metadata.distribution('cripto-predictor').read_text('direct_url.json'))
assert 'pesquisa-20260909' in direct['url'] and direct['dir_info']['editable']
result = {'at_utc': datetime.now(UTC).isoformat(), 'pr': 117, 'head': pr['head'], 'merge': head,
          'tree': git(P, 'rev-parse', 'HEAD^{tree}'), 'pr_run': pr['run'], 'main_run': main['run'],
          'pr_four_jobs_passed': True, 'main_four_jobs_passed': True,
          'postmerge_passed': passed, 'postmerge_skipped': skips, 'postmerge_failed': failures,
          'published_files': 38, 'manifest_files': 31, 'conversation_messages_reread': 179,
          'owner_prompt_preserved': True, 'frozen_llm_checkout_preserved': True,
          'operational_budget_preserved': True, 'editable_installation': direct['url'],
          'scope': 'Public documentation and dated evidence reconciled and integrated; runtime, tests and dependency locks unchanged',
          'remaining': ['H5 original inputs and historical macro/news evidence', 'Aave second-source live archive comparison and independence',
                        'Future manual carry/LLM observations', 'Personal execution/cost evidence'],
          'historical_keys': 'Current keys retained by owner direction; old usage/revocation not established, nonblocking',
          'economic_conclusion': 'Conditional historical Aave result; personal or prospective profit not validated'}
with (L / 'integration.json').open('x', encoding='utf-8') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
report = R / 'REVISAO.md'
previous = report.read_bytes()
assert b'## 19.' not in previous
(L / 'canonical_before_publication.md').write_bytes(previous)
section = f'''
## 19. Conferência do chat, commit e publicação final de 10/09

Foram relidas 179 mensagens recuperadas da conversa até 19:57 UTC de 10/09: 16 mensagens do dono e 163 respostas/atualizações. Os pedidos e afirmações foram confrontados com os resultados datados, recibos preservados e Git. As correções integradas pelos PRs #110–#116 foram mantidas. A documentação pública foi corrigida onde ainda apresentava contrato v3, Aave sem histórico e snapshot necessariamente dependente de nova coleta. Isso não amplia retrospectivamente a cobertura manual da auditoria nem certifica ausência universal de defeitos.

O [PR #117](https://github.com/leonardosovienski/cripto-predictor/pull/117) publicou 38 arquivos alterados/adicionados, incluindo 31 evidências cobertas por manifesto. Commit enviado: `{pr['head']}`; integração no main: `{head}`. Árvore resultante idêntica à do PR. Os quatro jobs foram aprovados no [CI do PR](https://github.com/leonardosovienski/cripto-predictor/actions/runs/{pr['run']}) e no [CI do main](https://github.com/leonardosovienski/cripto-predictor/actions/runs/{main['run']}). [Comprovante de integração](publication_chat_20260910/integration.json).

A [validação pós-merge Windows](postmerge_publication01/validation.json) aprovou sincronização congelada de todos os extras, build, status, ajuda e a suíte completa: **1.505 aprovados, um skip de symlink por privilégio do Windows, zero falhas**. O código, testes, locks e CI permanecem os mesmos do #116. A [verificação dos artefatos](publication_chat_20260910/artifact_validation.json) confirmou 31 hashes, 74 links locais válidos e ausência de valores de segredos configurados; o scanner também retornou zero achados. Os 31 hashes foram reconferidos nos blobs do Git e no checkout integrado.

A [verificação operacional posterior](publication_chat_20260910/state_after.json) confirmou os bytes do repasse, o executor LLM congelado, os registros antigos do banco e a reserva de quota preservados. O repasse local já coincidia byte a byte com o conteúdo publicado antes desta etapa; seu marcador de alteração no Windows decorre de quebras de linha, não de texto faltando no Git. As chaves atuais foram mantidas. Não houve chamada adicional de dados, ordem, assinatura, uso de credencial financeira ou agendamento.

A execução local ficou mais lenta que a anterior. O [diagnóstico preservado](publication_chat_20260910/validation_diagnostics.json) registra pouca memória livre e três amostras distintas do processo: captura de saída, verificação dos pacotes/caminhos e controle estatístico do backtest. A suíte foi mantida, sem interrupção, mudança de captura ou exclusão de testes. Isso não é medição de ganho de velocidade nem prova de causa única da demora.

O estado dos seis itens da seção 18 permanece aplicável: snapshot v4 recuperado offline e válido somente na janela declarada; H5/vintages e custos pessoais sem a evidência necessária; comparação Aave preparada, ainda sem consulta à segunda fonte por quota; carry sem entrada e 84 horários LLM futuros. Históricos de revogação/uso antigo são informação não comprovada e não bloqueante. A análise Aave continua positiva apenas sob as condições históricas/modeladas; lucro pessoal ou prospectivo não foi validado.

O [documento publicado de conferência](C:/Cripto/pesquisa-20260909/docs/CONFERENCIA_CHAT_20260910.md) contém o índice das evidências e comandos de retomada. Bancos, configuração privada, chat e textos de notícias/LLM continuam locais. A captura pública do relatório termina na seção 18 e está identificada como datada; este arquivo continua sendo o registro vivo único.

O [inventário das áreas locais](publication_chat_20260910/worktrees_before_integration.json) registra também a tentativa intermediária antiga em `publicacao-chat-20260909`, parada em três conflitos sobre a captura `4ae9e3d`, e o CSV avulso preservado no snapshot restaurado. A correção e publicação daquela tentativa foram realizadas em `correcao-pr110-20260910` e integradas pelo #110. A área antiga não foi limpa nem reutilizada como código atual; esta publicação não inclui conflitos abandonados ou dados sem procedência suficiente como se fossem novas correções.
'''
(R / 'work/publication_report_section.md').write_text(section, encoding='utf-8')
text = previous.decode('utf-8') + section
links = re.findall(r'\[[^\]]+\]\(([^)]+)\)', text)
local = [p for p in links if not p.startswith(('https://', 'http://', '#'))]
missing = [p for p in local if not (Path(p) if Path(p).is_absolute() else R / p).exists()]
assert not missing
assert len(re.findall(r'^## \d+\.', text, re.MULTILINE)) == 19
report.write_text(text, encoding='utf-8')
with (L / 'final_report_validation.json').open('x', encoding='utf-8') as stream:
    json.dump({'status': 'PASS', 'sections': 19, 'local_links': len(local), 'missing_links': missing}, stream, indent=2)
print(json.dumps(result, ensure_ascii=False))
