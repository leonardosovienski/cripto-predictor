import hashlib
import json
import os
import re
import subprocess
from collections import Counter, defaultdict
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(r'C:\Cripto')
P = ROOT / 'pesquisa-20260909'
R = ROOT / 'operacao/relatorios/REVISAO_COMPLETA_20260909'
F = R / 'organization_20260910'
F.mkdir(exist_ok=False)
stats = defaultdict(lambda: {'files': 0, 'bytes': 0, 'directories': 0})
errors, links, stack = [], [], [ROOT]
with (F / 'file_inventory.private.jsonl').open('w', encoding='utf-8') as output:
    while stack:
        parent = stack.pop()
        if parent == F:
            continue
        try:
            with os.scandir(parent) as entries:
                for entry in entries:
                    path = Path(entry.path)
                    relative = path.relative_to(ROOT).as_posix()
                    group = relative.split('/')[0]
                    if entry.is_symlink() or path.is_junction():
                        links.append(relative)
                        continue
                    if entry.is_dir(follow_symlinks=False):
                        stats[group]['directories'] += 1
                        stack.append(path)
                    elif entry.is_file(follow_symlinks=False):
                        meta = entry.stat(follow_symlinks=False)
                        stats[group]['files'] += 1
                        stats[group]['bytes'] += meta.st_size
                        output.write(json.dumps({'path': relative, 'bytes': meta.st_size, 'mtime_ns': meta.st_mtime_ns}, ensure_ascii=False) + '\n')
        except OSError as exc:
            errors.append({'path': str(parent), 'type': type(exc).__name__})

names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=P).decode().split('\0')
names = [n for n in names if n]
tracked = set(names)
md_names = [n for n in names if n.lower().endswith('.md')]

def historical(name):
    return name.startswith(('docs/evidence/', 'docs/session_archive_', 'docs/source_archive_', 'docs/continuity_20260909/local-root/')) or name in ('docs/NEXT_CHAT_PROMPT.md', 'CR_FREEZE_INDEX.md', 'CR_RESEARCH_FREEZE.md')

def without_fences(text):
    result = []
    fence = None
    for line in text.splitlines():
        token = re.match(r'^\s*(?:>\s*)?(`{3,}|~{3,})', line)
        if token:
            if fence is None:
                fence = token.group(1)[0]
            elif token.group(1)[0] == fence:
                fence = None
            result.append('')
        else:
            result.append('' if fence else line)
    return result

documents, findings = [], []
for name in md_names:
    path = P / name
    data = path.read_bytes()
    try:
        body = data.decode('utf-8-sig')
    except UnicodeDecodeError:
        findings.append({'file': name, 'kind': 'invalid_utf8'})
        continue
    visible = without_fences(body)
    refs = dict(re.findall(r'^\s*\[([^\]]+)\]:\s*<?([^\s>]+)>?', '\n'.join(visible), re.MULTILINE))
    doc_links = 0
    for number, line in enumerate(visible, 1):
        targets = re.findall(r'!?\[[^\]\n]+\]\((<[^>]+>|[^()\s]+)(?:\s+["\'][^)]*)?\)', line)
        targets += [refs[r] for r in re.findall(r'\[[^\]]+\]\[([^\]]+)\]', line) if r in refs]
        for target in targets:
            target = target.strip('<>')
            if not target or target.startswith(('#', 'https:', 'http:', 'mailto:', 'data:')):
                continue
            doc_links += 1
            target = unquote(target.split('#')[0].split('?')[0])
            local = Path(target) if re.match(r'^[a-zA-Z]:[/\\]', target) else path.parent / target
            if not local.exists():
                findings.append({'file': name, 'line': number, 'target': target, 'kind': 'missing_local_target', 'historical': historical(name)})
            elif local.is_file() and local.is_relative_to(P) and local.relative_to(P).as_posix() not in tracked:
                findings.append({'file': name, 'line': number, 'target': target, 'kind': 'local_only_target_inside_repo', 'historical': historical(name)})
    documents.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                      'lines': len(body.splitlines()), 'title': next((x for x in body.splitlines() if x.startswith('# ')), ''),
                      'historical_or_frozen_location': historical(name), 'local_links': doc_links})

closure = R / 'chat_closure_20260910'
cm = json.loads((closure / 'manifest.json').read_bytes())
for name, digest in cm['files'].items():
    assert hashlib.sha256((closure / name).read_bytes()).hexdigest() == digest, name
assert hashlib.sha256(Path(cm['handoff_path']).read_bytes()).hexdigest() == cm['handoff_sha256']
assert hashlib.sha256((P / 'docs/NEXT_CHAT_PROMPT.md').read_bytes()).hexdigest() == '8969db38ef9a3ec29ee16a780b9572ec9f7d7808cabc9bac17a319616b47fe20'
for stem, value in [('root_inventory', {'groups': stats, 'unreadable': errors, 'links_not_followed': links, 'excluded_current_evidence': str(F)}),
                    ('markdown_inventory', documents), ('markdown_findings', findings)]:
    (F / (stem + '.json')).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
summary = {'at_utc': datetime.now(UTC).isoformat(), 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=P, text=True).strip(),
           'files_inventoried': sum(v['files'] for v in stats.values()), 'bytes_inventoried': sum(v['bytes'] for v in stats.values()),
           'directories_inventoried': sum(v['directories'] for v in stats.values()), 'unreadable': errors, 'links_not_followed': len(links),
           'tracked_markdown_files': len(md_names), 'markdown_bytes': sum(d['bytes'] for d in documents),
           'markdown_local_links_checked': sum(d['local_links'] for d in documents), 'link_findings_by_kind': dict(Counter(f['kind'] for f in findings)),
           'chat_backup_hashes_passed': True, 'owner_prompt_hash_passed': True,
           'scope': 'Full metadata inventory without following links; tracked Markdown decoded and local file targets checked. Historical interpretation and removals require subsequent review.'}
(F / 'baseline.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False))
print(json.dumps({'findings': findings}, ensure_ascii=False))
