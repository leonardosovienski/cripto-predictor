from pathlib import Path
import sys

# Reuse the audited isolated environment and evidence writer without running
# the full suite before focused regressions finish.
runner = Path(r"C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\work\run_checks.py")
sys.argv = [str(runner), "manual_target01"]
exec(compile(runner.read_text(encoding="utf-8").split('CMD = r')[0], str(runner), "exec"))
cmd = r"C:\Cripto\CRIPTO.cmd"
check("ruff", [cmd, "python", "-m", "ruff", "check", "--fix", "scripts/carry_forward_registration.py", "scripts/audit_market_calendar.py", "tests/test_manual_dependencies.py", "tests/test_review_data_contracts.py"])
check("format", [cmd, "python", "-m", "ruff", "format", "scripts/carry_forward_registration.py", "scripts/audit_market_calendar.py", "tests/test_manual_dependencies.py", "tests/test_review_data_contracts.py"])
check("tests", [cmd, "python", "-m", "pytest", "-q", "-ra", "tests/test_manual_dependencies.py", "tests/test_review_data_contracts.py", "tests/test_dpl.py", "tests/test_carry_forward.py", "tests/test_carry_public.py", "--basetemp", str(TEMP / "pytest")])
state["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
save()
raise SystemExit(any(c["exit_code"] != 0 for c in state["checks"]))
