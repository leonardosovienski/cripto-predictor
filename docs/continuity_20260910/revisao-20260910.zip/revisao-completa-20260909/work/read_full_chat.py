import json
from collections import Counter
from pathlib import Path

source = Path(r'C:\Users\leona\.codex\sessions\2026\09\09\rollout-2026-09-09T18-45-21-01a08821-f27f-7970-a87f-f37b1e249910.jsonl')
target = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\closure_audit')
target.mkdir(exist_ok=True)
counts = Counter()
messages = []
for line in source.open(encoding='utf-8'):
    record = json.loads(line)
    payload = record.get('payload', {})
    counts[(record.get('type'), payload.get('type'))] += 1
    if record.get('type') == 'event_msg' and payload.get('type') == 'item_completed':
        item = payload.get('item', {})
        if item.get('type') in ('agentMessage', 'agent_message', 'AgentMessage'):
            body = '\n'.join(c.get('text', '') for c in item.get('content', []) if c.get('type') == 'Text')
            messages.append({'timestamp': record.get('timestamp'), 'role': 'assistant', 'channel': item.get('phase'), 'text': body})
        counts[('item_completed', item.get('type'))] += 1
    if record.get('type') == 'event_msg' and payload.get('type') == 'agent_message':
        messages.append({'timestamp': record.get('timestamp'), 'role': 'assistant', 'channel': payload.get('phase'), 'text': payload.get('message', '')})
    if record.get('type') != 'response_item' or payload.get('type') != 'message':
        continue
    role = payload.get('role')
    channel = payload.get('channel')
    channel = channel or payload.get('phase')
    if role == 'assistant' and channel is None:
        print(json.dumps({'assistant_metadata': {k: v for k, v in payload.items() if k != 'content'}}))
    if role != 'user' and not (role == 'assistant' and channel == 'final'):
        continue
    body = '\n'.join(c.get('text', '') for c in payload.get('content', []) if c.get('type') in ('input_text', 'output_text'))
    if body.startswith(('<environment_context>', '<recommended_plugins>', '<permissions instructions>')):
        continue
    messages.append({'timestamp': record.get('timestamp'), 'role': role, 'channel': channel, 'text': body})
(target / 'conversation_messages.json').write_text(json.dumps(messages, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'source_bytes': source.stat().st_size, 'messages': len(messages), 'roles': dict(Counter(m['role'] for m in messages)), 'saved': str(target / 'conversation_messages.json')}, ensure_ascii=False))
print(json.dumps({'record_types': {str(k): v for k, v in counts.items()}}))
for i, message in enumerate(messages):
    if message['role'] == 'assistant' and message.get('channel') == 'commentary':
        print(json.dumps({'i': i, **message}, ensure_ascii=False))
