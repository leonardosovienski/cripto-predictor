from pathlib import Path
from datetime import UTC,datetime
import hashlib
import json
import subprocess
import sys

P=Path(r'C:\Cripto\pesquisa-20260909')
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
E=P/'docs/evidence/aave_validation_20260910'
manifest=json.loads((E/'MANIFEST.json').read_bytes())['files']
names=[(E/n).relative_to(P).as_posix() for n in manifest]
raw=subprocess.check_output(['git','cat-file','--batch'],input=''.join('HEAD:'+n+'\n' for n in names).encode(),cwd=P)
offset=0
for relative,(name,digest) in zip(names,manifest.items()):
    end=raw.index(b'\n',offset)
    size=int(raw[offset:end].split()[2])
    blob=raw[end+1:end+1+size]
    offset=end+1+size+1
    assert hashlib.sha256(blob).hexdigest()==digest,relative
    assert hashlib.sha256((E/name).read_bytes()).hexdigest()==digest,relative
assert (P/'docs/NEXT_CHAT_PROMPT.md').read_bytes()==(R/'executors_baseline01/initial_next_chat_prompt.md').read_bytes()
result={'checked_at':datetime.now(UTC).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip(),
        'public_files_verified_in_git_and_worktree':len(names),'owner_prompt_preserved':True}
with (R/'profit_search'/sys.argv[1]).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2)
print(json.dumps(result))
