import json
from datetime import datetime, timezone
from pathlib import Path

target = Path(r"C:\Cripto\pesquisa-20260909\docs\manual_dependencies_20260910")
target.mkdir(exist_ok=True)
base = 'https://www.binance.com/en/support/announcement/detail/'
def source(code, published, title):
    return {'url': base + code, 'published_date': published, 'title': title}
events = [
 ('BNXUSDT', '2023-02-16T03:00', '2023-02-22T08:00', 'redenomination', '1:100', 'BinaryX old', 'BinaryX new', [
 source('4d23ada51a2e4fa182835c77d51ba1a9','2023-02-10','BinaryX swap plan'),
 source('fb6c6a1c6a9947b0bd30d58314ab862c','2023-02-21','BNX revised listing time')]),
 ('BTCSTUSDT','2021-03-15T07:00','2021-03-19T07:00','redenomination','1:10','BTCST old','BTCST new',[
 source('2c08ba9e1a1b409fb6a4a2cb2f5ed58b','2021-03-11','BTCST redenomination plan')]),
 ('COCOSUSDT','2021-01-19T02:00','2021-01-23T02:00','redenomination','1000:1','Cocos-BCX old','Cocos-BCX new',[
 source('f555f8013eff42bc9c91eaa48b9da24b','2021-01-18','COCOS redenomination plan')]),
 ('CVCUSDT','2022-12-09T03:00','2023-05-12T08:00','pair_removed_then_relisted',None,'CVC/USDT first episode','CVC/USDT relisted episode',[
 source('13647176b1594beebe1a8aa3f9f843c8','2022-12-07','Trading pairs removal 2022-12-09'),
 source('c968644475a74284a292ecd3af39e6ff','2023-05-11','CVC/USDT and WBETH/ETH additions')]),
 ('DREPUSDT','2021-03-29T04:00','2021-04-02T04:00','redenomination','100:1','DREP old','DREP new',[
 source('51eb4f0351194fab957bb23cc6ee52dd','2021-03-19','DREP redenomination plan'),
 source('a2c87d5944cd4856af5aabd2cb8f68b4','2021-03-22','DREP revised halt and listing dates')]),
 ('FTTUSDT','2022-11-15T04:30','2023-09-22T08:00','pair_removed_then_relisted',None,'FTT/USDT first episode','FTT/USDT relisted episode',[
 source('47642955ae7f4a3688133df8067ac3c2','2022-11-14','Trading pairs removal 2022-11-15'),
 source('fe93095a80944d31b42fa7eb2afdb12c','2023-09-21','Trading pairs addition and removal 2023-09-22')]),
 ('KEYUSDT','2023-02-10T03:00','2023-03-10T08:00','pair_removed_then_relisted',None,'KEY/USDT first episode','KEY/USDT relisted episode',[
 source('7ec33a2d62974c3490b92ff0780ba461','2023-02-08','Trading pairs removal 2023-02-10'),
 source('8ef61bec1227429a910877be141c5af3','2023-03-09','CFX/TRY KEY/USDT STX/TRY USTC/USDT additions')]),
 ('LUNAUSDT','2022-05-13T00:40','2022-05-31T06:00','ticker_reused_different_asset',None,'Terra Classic formerly LUNA now LUNC','Terra 2.0 LUNA',[
 source('514e0ba636e843bda47d5d740b7dadf4','2022-05-13','Pairs removal and tick size updates 2022-05-13'),
 source('d044a6742e484b77a170111460b0eed3','2022-05-28','Terra 2.0 listing; old LUNA renamed LUNC; chart clarification updated 2022-05-31')]),
 ('QUICKUSDT','2023-07-17T03:00','2023-07-21T08:00','redenomination','1:1000','QuickSwap old','QuickSwap new',[
 source('50b38ae7b25a45a7854c94ab67a1e7d0','2023-07-10','QuickSwap swap and redenomination plan')]),
 ('STRAXUSDT','2024-03-20T03:00','2024-03-28T08:00','redenomination','1:10','Stratis old','Stratis new',[
 source('2e6eb8e644664a6ca7b6659a226c41b0','2024-03-08','Stratis swap and redenomination plan'),
 source('033618992939455aa64fd113a2c1e76f','2024-03-28','Stratis swap completed')]),
 ('SUNUSDT','2021-06-14T04:00','2021-06-18T04:00','redenomination','1:1000','SUN old','SUN new',[
 source('f923f2e4056843a9a9b87beb2aaa2f31','2021-06-08','SUN migration and redenomination plan')]),
 ('VIDTUSDT','2022-10-31T03:00','2022-11-09T08:00','redenomination','1:10','VIDT Datalink','VIDT DAO',[
 source('ef40b40af1944bc9b399ad9c52861a04','2022-10-19','VIDT swap redenomination and rebranding plan'),
 source('e7ce7d49c33a49de916a188dacb38f07','2022-11-10','VIDT swap completed')]),
]
result = {'schema_version': 1, 'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
 'scope': 'Retrospective classification of the 12 preserved Binance spot USDT gaps only. Dates manually reconciled from official announcements and their updates. Not a point-in-time complete listing registry.',
 'method': 'A missing full UTC day is explained only if wholly inside [halt,resume). Do not interpolate, change raw data, join returns across episodes, or use this later-acquired registry as a historical signal.',
 'limitations': 'Announcements can be revised; only their currently available versions were read. Boundary partial candles, intraday interruptions, other assets and complete historical investibility are not certified. Reopening/closure dates and unit swaps do not certify liquidity or fills.',
 'events': []}
for sym, halt, resume, kind, ratio, before, after, refs in events:
    result['events'].append({'symbol':sym,'halt_utc':halt+':00+00:00','resume_utc':resume+':00+00:00','event_type':kind,'old_units_to_new_units':ratio,'identity_before':before,'identity_after':after,'sources':refs})
(target/'market_events.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f'Registry written: {len(events)} events')
