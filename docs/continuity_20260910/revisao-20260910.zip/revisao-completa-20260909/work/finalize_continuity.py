"""Close the evidence record only after all required final-state checks succeed."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

P = Path(r'C:\Cripto\pesquisa-20260909')
R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
F = R / 'closure110'

def read(path):
    return json.loads(path.read_bytes())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=P, text=True).strip()

def suite(path):
    root = ET.parse(path).getroot()
    rows = [root] if root.tag == 'testsuite' else list(root.iter('testsuite'))
    result = {k: sum(int(r.attrib.get(k, 0)) for r in rows)
              for k in ('tests', 'errors', 'failures', 'skipped')}
    result['passed'] = result['tests'] - result['errors'] - result['failures'] - result['skipped']
    assert not result['errors'] and not result['failures']
    return result

record = read(F / 'integration.json')
pr_ci = read(F / 'ci_pr.json')
main_ci = read(F / 'ci_main.json')
required = {'quality', 'all-extras', 'container', 'python-314-experimental'}
for ci, head in ((pr_ci, record['head_sha']), (main_ci, record['merge_sha'])):
    assert ci['head_sha'] == head and ci['conclusion'] == 'success'
    assert required == {j['name'] for j in ci['jobs']}
    assert all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in ci['jobs'])
    assert ci['event'] == ('pull_request' if ci is pr_ci else 'push')
final01 = read(F / 'final01/validation.json')
final02 = read(F / 'final02/validation.json')
post = read(R / 'postmerge02/validation.json')
assert all(c['exit_code'] == 0 for c in final01['checks'] if c['name'] != 'tests')
for run in (final02, post):
    assert run.get('finished_at_utc') and all(c['exit_code'] == 0 for c in run['checks'])
assert post['head'] == record['merge_sha'] == git('rev-parse', 'HEAD')
assert git('rev-parse', 'HEAD^{tree}') == git('rev-parse', record['head_sha'] + '^{tree}')
assert git('ls-remote', 'origin', 'refs/heads/main').split()[0] == record['merge_sha']
assert not git('diff', '--name-only', record['validated_base'], 'HEAD', '--',
               'GarimpoInvestimentos', 'charters', 'observation_plans', 'pyproject.toml', 'uv.lock')
changed = [p for p, h in post['source_hashes'].items()
           if hashlib.sha256((P / p).read_bytes()).hexdigest() != h]
assert not changed
assert (P / 'docs/NEXT_CHAT_PROMPT.md').read_bytes() == (R / 'baseline/initial_next_chat_prompt.md').read_bytes()
wheel = read(F / 'final01/wheel_contract.json')
assert wheel.get('finished_at_utc') and not wheel['prohibited_members']
assert all(c['exit_code'] == 0 for c in wheel['checks'])
publication = read(F / 'publication_verification.json')
assert publication['all_recovered_files'] == 9817 and not publication['recovered_mismatches']
assert publication['unchanged_original_archives'] == 21 and not publication['budget_files_recovered']
before = suite(F / 'final02/tests.xml')
after = suite(R / 'postmerge02/tests.xml')
assert before == after == {'tests': 1343, 'errors': 0, 'failures': 0, 'skipped': 1, 'passed': 1342}
record.update({
    'status': 'INTEGRADO_E_VALIDADO_NO_MAIN',
    'completed_at_utc': datetime.now(timezone.utc).isoformat(),
    'required_jobs': sorted(required),
    'pr_four_checks_passed': True, 'main_four_checks_passed': True,
    'tested_and_merged_tree': git('rev-parse', 'HEAD^{tree}'),
    'merged_tree_equals_tested_tree': True,
    'runtime_and_dependencies_equal_PR111': True,
    'local_final_suite': before, 'local_postmerge_suite': after,
    'local_postmerge_all_extras': True,
    'current_source_files_verified': len(post['source_hashes']),
    'owner_prompt_preserved_byte_for_byte': True,
    'working_tree_status': git('status', '--short'),
    'recovered_archives': 24, 'recovered_files': 9817,
    'known_secret_matches_in_examined_exports': publication['known_secret_matches'],
    'runtime_coverage_percent': read(F / 'final01/coverage.json')['totals']['percent_covered'],
    'branch_protection_configured': False,
    'remaining_dependencies': 'DEPENDENCIAS.md; administrative branch protection; D01-D10 in the canonical report',
    'test_failure_history': 'final01 retained: unsafe Windows ZIP input was correctly refused but an error-message expectation failed. The corrected complete final02 and postmerge02 suites pass.',
})
record['summary'] = (
    'PR #110 integrado e validado no main ' + record['merge_sha'] + '. '
    'A árvore ' + record['tested_and_merged_tree'] + ' coincide com a versão testada 64dbdc2; '
    'runtime, dependências e definições congeladas do #111 preservados. '
    'Suítes locais completas antes e depois da integração: 1.342 aprovados, um skip por privilégio de symlink Windows e zero falhas em cada execução, com todos os extras. '
    'Os quatro jobs passaram no PR (run 34421408312) e no main (run 34421841576); all-extras do PR: 1.343 aprovados. '
    'Ruff, formato, Pyright, scanner, H6, build, contrato do wheel instalado fora do checkout e recuperação integral de 24 ZIPs/9.817 arquivos passaram. '
    'Orçamento real e originais preservados; nenhum arquivo de orçamento recuperado. '
    'O checkout operacional está atualizado e o prompt do dono permanece byte a byte, agora também publicado como parte da continuidade. '
    'Não resta falha executável identificada nesta correção. Permanecem dependências de acesso administrativo para proteger main, dados históricos ausentes, observações futuras e condições reais de execução; seus critérios de retomada estão documentados.'
)
(F / 'integration.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': record['status'], 'main': record['merge_sha'], 'local_tests': after, 'source_files_verified': len(post['source_hashes'])}))
