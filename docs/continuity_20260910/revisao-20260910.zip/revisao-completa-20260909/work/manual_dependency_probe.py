"""Bounded new public archive probe and Git-history search for manual closure."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

import httpx

from GarimpoInvestimentos.config import settings
from GarimpoInvestimentos.core.api_guard import allow

P = Path(r'C:\Cripto\pesquisa-20260909')
R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\manual_dependencies')
R.mkdir(parents=True, exist_ok=False)
now = lambda: datetime.now(timezone.utc).isoformat()
git = lambda *args: subprocess.check_output(['git', *args], cwd=P, text=True).strip()
scope = {
    'registered_at_utc': now(), 'head': git('rev-parse', 'HEAD'),
    'branch': git('branch', '--show-current'), 'status': git('status', '--short'),
    'excluded_by_owner': 'branch security and protection settings',
    'manual_scope': 'Historical source/market identity audit, missing-input recovery, secondary contracts and prospective preparation; no orders, accounts, payment or recurring automation.',
    'rpc_endpoint': 'https://arbitrum.api.onfinality.io/public',
    'official_public_endpoint_source': 'https://onfinality.io/en/networks/arbitrum',
    'official_archive_capability_source': 'https://documentation.onfinality.io/support/arbitrum',
    'rpc_calls_max': 2, 'retries': 0, 'timeout_seconds': 12, 'response_bytes_max': 1000000,
    'budget_stage': 'ingest', 'budget_key': 'assets', 'budget_units': 1,
}
(R / 'scope.json').write_text(json.dumps(scope, indent=2), encoding='utf-8')
paths = git('log', '--all', '--format=', '--name-only', '--', '*.db', '*.sqlite', '*.sqlite3', '*predictions*.json', '*predictions*.jsonl', '*llm_cache*', '*feature_store*').splitlines()
history = {
    'at_utc': now(), 'all_local_git_refs_examined': True,
    'matched_paths': sorted(set(p for p in paths if p)),
    'database_or_prediction_export_found': any(p.endswith(('.db', '.sqlite', '.sqlite3', '.json', '.jsonl')) for p in paths),
    'limit': 'Search covers locally available Git refs and specified database/prediction/cache path patterns; not provider accounts or deleted unreachable Git objects.',
}
(R / 'h5_git_history.json').write_text(json.dumps(history, indent=2), encoding='utf-8')
assert settings.API_GUARD_ENABLED and settings.API_GUARD_MAX_INGEST_ASSETS == 28
decision = allow('ingest', 'assets', settings.API_GUARD_MAX_INGEST_ASSETS)
if not decision.allowed:
    (R / 'aave_onfinality.json').write_text(json.dumps({'budget_allowed': False, 'calls': 0}), encoding='utf-8')
    raise SystemExit('Public probe budget exhausted')
params = json.loads((P / 'docs/evidence/economic_round_20260909/h1_rpc/005.json').read_bytes())['request']['params']
records = []
with httpx.Client(timeout=12, trust_env=False, follow_redirects=False) as client:
    for method, method_params in [('eth_chainId', []), ('eth_call', params)]:
        request = {'jsonrpc': '2.0', 'id': len(records) + 1, 'method': method, 'params': method_params}
        item = {'at_utc': now(), 'request': request}
        try:
            with client.stream('POST', scope['rpc_endpoint'], json=request) as response:
                body = b''
                for chunk in response.iter_bytes():
                    body += chunk
                    if len(body) > scope['response_bytes_max']:
                        raise ValueError('Response byte limit')
                (R / f'onfinality-{len(records)+1:02}.response').write_bytes(body)
                item.update(http_status=response.status_code, raw_sha256=hashlib.sha256(body).hexdigest(), response=json.loads(body))
        except Exception as exc:
            item['error_type'] = type(exc).__name__
        records.append(item)
        if method == 'eth_chainId' and item.get('response', {}).get('result') != '0xa4b1':
            break
value = records[-1].get('response', {}).get('result') if len(records) == 2 else None
result = {'at_utc': now(), 'calls': len(records), 'budget_units_consumed': 1, 'records': records,
          'archive_index_available': isinstance(value, str) and len(value) == 66 and value.startswith('0x') and int(value, 16) > 0,
          'historical_liquidity_verified': False, 'economic_result': None}
(R / 'aave_onfinality.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({'calls': len(records), 'archive_index_available': result['archive_index_available'], 'h5_export_found': history['database_or_prediction_export_found']}))
