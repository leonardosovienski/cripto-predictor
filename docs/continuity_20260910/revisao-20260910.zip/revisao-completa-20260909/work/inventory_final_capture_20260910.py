import json
from collections import defaultdict
from pathlib import Path

root = Path(r'C:\Cripto')
R = root / 'operacao/relatorios/REVISAO_COMPLETA_20260909'
F = R / 'organization_20260910'
inventory = defaultdict(lambda: {'files': 0, 'bytes': 0})
for name in ('operacao/dados', 'operacao/saidas', 'operacao/relatorios/REVISAO_COMPLETA_20260909'):
    base = root / name
    for path in base.rglob('*'):
        if path.is_file():
            rel = path.relative_to(base)
            group = name + '/' + (rel.parts[0] if len(rel.parts) > 1 else '<root>')
            key = group + ' | ' + (''.join(path.suffixes[-2:]) or '<none>')
            inventory[key]['files'] += 1
            inventory[key]['bytes'] += path.stat().st_size
(F / 'capture_inventory.json').write_text(json.dumps(inventory, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(sorted(inventory.items(), key=lambda x: x[1]['bytes'], reverse=True)[:45], ensure_ascii=False))
