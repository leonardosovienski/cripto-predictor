from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
f=p/'GarimpoInvestimentos/v3/macro_features.py';s=f.read_text(encoding='utf-8')
s=s.replace('    events: list[MacroEvent] | None = None,','    events: list[MacroEvent] | None = None,\n    calendar_available_at: datetime | None = None,\n    assume_calendar_known: bool = False,',1)
s=s.replace('    ev = events if events is not None else load_macro_calendar(calendar_path)','    if not assume_calendar_known:\n        if calendar_available_at is None:\n            raise ValueError("Calendario exige calendar_available_at documentado para sua versao")\n        known = ensure_utc(calendar_available_at, "calendar_available_at")\n        if any(fv.timestamp_exchange_ms < int(known.timestamp() * 1000) for fv in feature_vectors):\n            raise ValueError("Calendario nao estava documentado no instante de todas as features")\n    ev = events if events is not None else load_macro_calendar(calendar_path)',1)
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/v3/backtest_v3.py';s=f.read_text(encoding='utf-8')
# Read the precise signature before adding a new optional evidence field.
a=s.index('def run_wfa(');b=s.index(') -> WFAResult:',a);sig=s[a:b]
sig+='    macro_calendar_available_at: datetime | None = None,\n'
s=s[:a]+sig+s[b:]
s=s.replace('macro_all = build_macro_event_dummy(all_features, window_days=macro_window_days)','macro_all = build_macro_event_dummy(all_features, window_days=macro_window_days, calendar_available_at=macro_calendar_available_at)')
# datetime may currently be imported locally only.
if 'from datetime import ' not in s.split('logger =')[0]:
 s=s.replace('import math\n','import math\nfrom datetime import datetime\n',1)
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/dpl/macro_calendar.py';s=f.read_text(encoding='utf-8').replace('                    published_at=ts,','                    published_at=ingested_at,\n                    vintage=ingested_at,\n                    collector_version="macro_calendar_observed_vintage_v2",\n                    quality_flags=frozenset({"available_at_receipt", "calendar_publication_history_unverified"}),');f.write_text(s,encoding='utf-8')
# Synthetic event-date unit tests explicitly declare their historical assumption.
f=p/'tests/test_v3_macro_features.py';s=f.read_text(encoding='utf-8');s=s.replace('build_macro_event_dummy(', 'build_macro_event_dummy(assume_calendar_known=True, ')
# Positional argument cannot follow keyword: move the flag immediately before closing via AST instead.
import ast
s=f.read_text(encoding='utf-8');tree=ast.parse(s);lines=s.splitlines(keepends=True);offsets=[0]
for line in lines: offsets.append(offsets[-1]+len(line))
inserts=[]
for node in ast.walk(tree):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='build_macro_event_dummy':
  inserts.append(offsets[node.end_lineno-1]+node.end_col_offset-1)
for offset in sorted(inserts,reverse=True):
 prefix='' if s[:offset].rstrip().endswith(',') else ', '
 s=s[:offset]+prefix+'assume_calendar_known=True'+s[offset:]
f.write_text(s,encoding='utf-8')
f=p/'tests/test_v3_macro_dxy_integration.py';s=f.read_text(encoding='utf-8').replace('        use_macro_dxy=True,\n        dxy_closes_path=dxy_path,','        use_macro_dxy=True,\n        macro_calendar_available_at=datetime.fromtimestamp(start_ms / 1000, tz=UTC),\n        dxy_closes_path=dxy_path,');f.write_text(s,encoding='utf-8')
f=p/'tests/test_v3_paper_report.py';s=f.read_text(encoding='utf-8').replace('    assert eq[0] == 1.1\n    assert abs(eq[1] - 1.1 * 0.95) < 1e-9\n    assert abs(eq[2] - 1.1 * 0.95 * 1.2) < 1e-9','    assert eq[0] == 1.0\n    assert eq[1] == 1.1\n    assert abs(eq[2] - 1.1 * 0.95) < 1e-9\n    assert abs(eq[3] - 1.1 * 0.95 * 1.2) < 1e-9').replace('assert pr._equity_curve([]) == []','assert pr._equity_curve([]) == [1.0]').replace('assert s["cum_pnl"] == 0.0','assert s["cum_pnl"] is None').replace('assert abs(s["cum_pnl"] - 0.09531) < 1e-3','assert abs(s["cum_pnl"] - 0.1) < 1e-9\n    assert s["max_dd"] is None\n    assert s["retrospective_records"] == 1');f.write_text(s,encoding='utf-8')
f=p/'tests/test_paper_idempotency.py';s=f.read_text(encoding='utf-8');s=s.replace('import json\n','import json\nimport pytest\n').replace('def test_already_recorded_ignores_corrupt_lines','def test_already_recorded_refuses_corrupt_history');s=s.replace('        assert paper_trader._already_recorded("BTCUSDT", 999) is False','        with pytest.raises(ValueError):\n            paper_trader._already_recorded("BTCUSDT", 999)');f.write_text(s,encoding='utf-8')
