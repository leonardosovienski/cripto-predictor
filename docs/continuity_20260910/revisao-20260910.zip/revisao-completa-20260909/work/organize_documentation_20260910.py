import re
from pathlib import Path

P = Path(r'C:\Cripto\revisao-arquivos-20260910')
R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
F = R / 'organization_20260910'

def write(name, text):
    (P / name).write_text(text.strip() + '\n', encoding='utf-8')

old = (P / 'README.md').read_text(encoding='utf-8')
table = '\n'.join(line for line in old.splitlines() if re.match(r'^\| (?:# |---|H\d+ )', line))
# Only the scientific table belongs here; discard separator rows from other tables.
table = '\n'.join(['| # | Hipótese | Trial (`trials.json`) | Status |', '|---|---|---|---|'] + [line for line in old.splitlines() if re.match(r'^\| H\d+ ', line)])
write('README.md', r'''
# cripto-predictor (GarimpoInvestimentos + DPL)

Sistema de pesquisa em criptoativos: ingestão e procedência de dados, análises com LLM, diagnósticos quantitativos e avaliação estatística. Nenhuma linha tem lucro pessoal ou futuro comprovado; os resultados históricos positivos de Aave são condicionais aos cenários de custo. A V3 emite diagnóstico `UNVALIDATED`.

## Comece aqui

- [Continuidade atual](CONTINUAR_AQUI.md): ordem de leitura e limites de execução.
- [Conferência de arquivos e documentação de 10/09/2026](docs/CONFERENCIA_ARQUIVOS_20260910.md): conteúdo preservado, limpeza, backups e referências históricas.
- [Configuração deste PC](docs/CONFIGURACAO_LOCAL.md): caminhos em `C:\Cripto`, ambiente e configuração privada.
- [Conferência do chat de 10/09](docs/CONFERENCIA_CHAT_20260910.md) e [auditoria ampliada](docs/AUDITORIA_AMPLIADA_20260910.md): correções, evidências e dependências.
- [Índice da documentação](docs/README.md): pesquisa, dados, recuperação e histórico.

Referência técnica anterior a esta conferência: `main` em `94fc9e7` (PR #117), validado no Windows com **1.505 testes aprovados e um skip de symlink**, e quatro jobs de CI aprovados no [commit integrado](https://github.com/leonardosovienski/cripto-predictor/actions/runs/34525972190). Essa contagem é datada; confira o SHA e os checks do commit que pretende usar.

## Execução neste Windows

Código operacional: `C:\Cripto\pesquisa-20260909`. Use o atalho que aplica os caminhos e o ambiente do projeto:

```powershell
C:\Cripto\CRIPTO.cmd status
C:\Cripto\CRIPTO.cmd pipeline --help
C:\Cripto\CRIPTO.cmd uv --version
```

O `status` verifica a configuração sem consultar APIs. Credenciais ficam somente em `C:\Cripto\configuracao\pipeline.env`, conforme o [mapa local](docs/CONFIGURACAO_LOCAL.md). O [exemplo público](GarimpoInvestimentos/.env.example) documenta os nomes das variáveis; ele não substitui o perfil deste PC.

O ambiente aceita Python 3.13 ou 3.14. As dependências e suas fontes estão fixadas em [pyproject.toml](pyproject.toml) e [uv.lock](uv.lock); Core 3.2.0 e Ops 4.1.0 são distribuições externas, sem cópias vendorizadas. Para manutenção, a sincronização completa é `C:\Cripto\CRIPTO.cmd uv sync --frozen --all-extras`. Os extras `llm`, `v3`, `excel`, `science` e `test` são necessários para exercitar toda a suíte.

As verificações locais usam ambiente sintético e diretórios isolados, sem carregar as chaves privadas. O executor de validação e os resultados por commit ficam no [registro da revisão](docs/REVISAO_COMPLETA_20260909.md). Não apresente testes executados com extras faltantes como validação completa. No Windows, a falta de privilégio para symlink pode causar o único skip documentado.

Coletas conectadas exigem janela, fontes e orçamento disponíveis. Os limites atuais são 28 unidades de ingestão, 8 tentativas de notícias por provedor e 6 chamadas lógicas de LLM por provedor, por dia UTC. Consulte [guardas de API](docs/API_GUARDS.md) e os protocolos antes de executar; nenhum agendamento está ativado por esta configuração.

## Dados e componentes

| Componente | Contrato e limite |
|---|---|
| DPL | Ingestão com contratos de instrumento, moeda, temporalidade e procedência; cobertura depende da fonte e da versão histórica disponível. |
| Feature Store | Banco oficial em `C:\Cripto\operacao\saidas\feature_store.db`; snapshots e inputs versionados preservam o contexto das novas previsões. Atualizações de dados brutos e de resultados não equivalem a um banco inteiro imutável. |
| LLM | Mercado armazenado, notícias e juiz identificado; carimbos de recebimento e conteúdo preservado não recuperam fontes históricas perdidas. |
| Backtest | Retornos medidos após a previsão; bootstrap e DSR sujeitos aos contratos de amostra, unidades e comparabilidade das tentativas. |
| V3 | HMM, funding/OI e walk-forward; causalidade da filtragem depende do ajuste e dos dados de cada avaliação. Custos não têm calibração de execução pessoal comprovada. |
| Operação | Ferramentas de lock, heartbeat e diagnóstico disponíveis; executores manuais obedecem aos protocolos próprios. |

Em 10/09/2026, o banco operacional contém três previsões, dois snapshots de mercado e um registro de inputs. O snapshot v4 usa 200 barras BTCUSDT fechadas, recuperadas de um recibo já existente, e vence em **11/09/2026 às 02:00 UTC**. Ele não ficará atualizado pela existência deste README. Use [backup e restauração](docs/BACKUP_RESTORE.md) para preservar o estado real antes de manutenção.

## Estado científico

As famílias antigas seguem o [charter](charters/scientific_state.json), o [índice de congelamento](CR_FREEZE_INDEX.md) e o [manifesto científico](CR_RESEARCH_FREEZE.md). Novas linhas possuem registros separados; a infraestrutura não reabre hipóteses encerradas.

''' + table + r'''

A H5 continua com reprodutibilidade histórica limitada: faltam seus dados brutos originais. Os resultados e intervalos históricos são preservados com as ressalvas registradas em [HYPOTHESES.md](docs/HYPOTHESES.md). Controles sintéticos validam propriedades do software, sem demonstrar lucro de mercado.

## Dependências de pesquisa

- **Aave:** comparação com uma segunda fonte preparada, ainda sem execução conectada concluída; acesso a histórico, independência da fonte e orçamento precisam ser verificados. Veja [validação e custos](docs/AAVE_VALIDACAO_20260910.md).
- **Carry manual v2:** entrada prevista para 12/09/2026, das 00:00 às 01:00 UTC; encerramento em 05/12. O protocolo continua sem observações nesta conferência.
- **LLM pareado manual v3:** 84 janelas diárias de 12/09 a 04/12, das 12:00 às 13:00 UTC; o último alvo matura em 13/12. O executor está congelado em `C:\Cripto\auditoria-ampliada-20260910`, commit `595f120`.
- **Históricos e custos:** originais H5, versões macro com disponibilidade temporal comprovada e extratos pessoais de execução/custos continuam sem evidência suficiente. Ausência não significa custo zero.

Os caminhos, protocolos e condições de retomada estão na [conferência do chat](docs/CONFERENCIA_CHAT_20260910.md). As chaves atuais foram mantidas por decisão do dono; administração de segurança da branch ficou fora do escopo. Nenhuma ordem, agendamento, capital ou pagamento foi ativado.

## Preservação e histórico

Git contém código, documentação e evidências selecionadas. Configuração privada, banco operacional, dados completos e cópia privada do chat ficam em `C:\Cripto`; clonar o repositório sozinho não restaura toda a operação. O pacote original e `restaurado-20260908` permanecem preservados.

Documentos datados registram o estado de suas respectivas etapas. Para interpretar caminhos e instruções antigos, consulte a [conferência de arquivos](docs/CONFERENCIA_ARQUIVOS_20260910.md) e o [índice documental](docs/README.md). O [prompt original](docs/NEXT_CHAT_PROMPT.md) permanece intacto como mandato.
''')
write('CONTINUAR_AQUI.md', r'''
# Continuar o projeto Cripto

Comece pela [conferência dos arquivos de 10/09/2026](docs/CONFERENCIA_ARQUIVOS_20260910.md) e pela [conferência do chat](docs/CONFERENCIA_CHAT_20260910.md). Elas complementam os registros anteriores com o mapa de preservação, backup e dependências.

1. Leia `C:\Cripto\AGENTS.md`, [CONFIGURACAO_LOCAL.md](docs/CONFIGURACAO_LOCAL.md) e [NEXT_CHAT_PROMPT.md](docs/NEXT_CHAT_PROMPT.md), preservado como mandato.
2. Leia o registro vivo `C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\REVISAO.md` e confira o estado real do Git e dos quatro jobs do commit atual. O [índice da revisão](docs/REVISAO_COMPLETA_20260909.md) explica sua localização.
3. Para recuperar dados, confira o [mapa de arquivos e backups](docs/CONFERENCIA_ARQUIVOS_20260910.md), os [pacotes anteriores](docs/continuity_20260909/README.md) e o [manifesto do corte de 09/09](docs/continuity_20260909/MANIFEST.json). Não extraia arquivos sobre bancos ou snapshots existentes.
4. Consulte [dependências executadas](docs/manual_dependencies_20260910/EXECUCAO.md) e [Aave](docs/AAVE_VALIDACAO_20260910.md), respeitando suas erratas e datas.

O código operacional fica em `C:\Cripto\pesquisa-20260909`; use `C:\Cripto\CRIPTO.cmd`. O executor LLM do protocolo manual v3 permanece congelado em `C:\Cripto\auditoria-ampliada-20260910`, commit `595f1203475d04b01966ac3471bbafd6770dbb4d`. Não substitua esse executor pelo código de desenvolvimento.

O banco operacional, após recuperação do snapshot v4 em 10/09, tem três previsões, dois snapshots e um registro de inputs. O backup publicado anteriormente tem três previsões, um snapshot e um registro de inputs: são instantes distintos, sem fusão automática. A validade do v4 termina em 11/09/2026 02:00 UTC.

O carry manual v2 aguarda 12/09/2026 00:00–01:00 UTC; a coleta LLM pareada v3 começa em 12/09 12:00–13:00 UTC. Não há agendamento ativado. A comparação Aave com segunda fonte depende do acesso e do orçamento diário. Dados originais H5, versões macro comprovadas e extratos pessoais continuam sem evidência suficiente.

A revisão do PR #110 e sua integração estão em [RESOLUCAO_PR110.md](docs/continuity_20260909/RESOLUCAO_PR110.md). Os ZIPs mantêm seus cortes anteriores; a captura intermediária `4ae9e3d` não é o estado final. A publicação posterior do PR #117 foi integrada em `94fc9e7`; confira o HEAD atual antes de reutilizar sua validação.

O guia local `C:\Cripto\LEIA_PRIMEIRO.md` aponta para a retomada preservada e para a revisão atual. A cópia privada do chat fica fora do Git. Execute apenas pendências compatíveis com os protocolos, sem repetir coletas idênticas já malsucedidas, inventar dados, reiniciar quotas ou reabrir famílias encerradas. Chaves atuais mantidas pelo dono; segurança da branch excluída. Nenhuma operação financeira autorizada.
''')
write('docs/BACKUP_RESTORE.md', r'''
# Backup e restauração do Feature Store

Neste PC, o banco ativo é `C:\Cripto\operacao\saidas\feature_store.db`. Ele é ignorado pelo Git. O utilitário [feature_store_backup.py](../scripts/feature_store_backup.py) usa a API de backup online do SQLite, inclusive em WAL, e publica a cópia somente após verificar sua integridade.

## Criar, verificar e testar a restauração

Execute pelo perfil local. Os destinos precisam ser novos e permanecer em `C:\Cripto`:

```powershell
$backupStamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$backupPath = "C:\Cripto\backups\feature-store-$backupStamp"
$restorePath = "C:\Cripto\operacao\temporarios\restore-feature-store-$backupStamp"
C:\Cripto\CRIPTO.cmd python -m scripts.feature_store_backup create --database C:\Cripto\operacao\saidas\feature_store.db --output $backupPath
if ($LASTEXITCODE -ne 0) { throw 'Falha ao criar backup' }
C:\Cripto\CRIPTO.cmd python -m scripts.feature_store_backup verify --backup $backupPath
if ($LASTEXITCODE -ne 0) { throw 'Falha ao verificar backup' }
C:\Cripto\CRIPTO.cmd python -m scripts.feature_store_backup restore --backup $backupPath --destination $restorePath
if ($LASTEXITCODE -ne 0) { throw 'Falha ao testar restauração' }
```

O backup contém `feature_store.db` independente de WAL/SHM e `BACKUP_MANIFEST.json` com versão, instante UTC, tamanho e SHA-256. A verificação compara o manifesto e executa `PRAGMA integrity_check`. A restauração recusa destino existente e produz `DESTINO\output\feature_store.db`; ela não substitui o banco ativo.

Depois, consulte a cópia restaurada em modo somente leitura e compare o conteúdo com o backup. O banco ativo pode ter avançado após a captura; compare com o instante registrado, não apenas com uma contagem antiga da documentação. A conferência de 10/09 inclui um teste de restauração no [registro de arquivos](CONFERENCIA_ARQUIVOS_20260910.md).

## O que este backup cobre

Esta ferramenta cobre somente o Feature Store. A recuperação completa também depende do código Git, runtimes congelados, dados brutos, protocolos, diários, relatórios, configuração privada e banco `C:\Cripto\operacao\dados\api_guard_budget.db`. Preserve o estado das quotas; não apague, zere ou restaure uma versão antiga desse banco para contornar o orçamento.

O [mapa local](CONFIGURACAO_LOCAL.md), a [conferência de arquivos](CONFERENCIA_ARQUIVOS_20260910.md) e o [pacote histórico](continuity_20260909/README.md) identificam esses componentes e seus cortes. O pacote original e os arquivos restaurados são preservados integralmente. Não restaure sobre a instalação existente.

Backups nesta raiz compartilham o mesmo disco; eles não protegem contra sua perda física. O mandato atual mantém todo o armazenamento do projeto em `C:\Cripto` e não ativa rotina automática de backup. Retenção ou uma cópia externa exigem uma decisão específica; isso não impede o uso das cópias locais verificadas.
''')
write('docs/API_GUARDS.md', r'''
# Guardas antes de chamadas externas

As guardas limitam unidades de trabalho nos pontos que as invocam. Elas não substituem os limites dos provedores nem estabelecem um teto monetário. Neste PC, o perfil privado usa:

```dotenv
API_GUARD_ENABLED=true
API_GUARD_MAX_INGEST_ASSETS=28
API_GUARD_MAX_NEWS_ATTEMPTS_PER_PROVIDER=8
API_GUARD_MAX_LLM_CALLS_PER_PROVIDER=6
```

Os valores estão documentados em [CONFIGURACAO_LOCAL.md](CONFIGURACAO_LOCAL.md). Pela semântica do código, limite `0` deixa a respectiva etapa sem teto; não use esse valor para contornar uma quota esgotada.

## Persistência e escopo

O consumo fica em `DATA_DIR/api_guard_budget.db`, neste perfil `C:\Cripto\operacao\dados\api_guard_budget.db`, por dia UTC, etapa e provedor. O incremento usa transação SQLite `BEGIN IMMEDIATE`; processos e reinícios compartilham o mesmo orçamento. A virada normal é às 00:00 UTC. Preservar o banco é parte da continuidade; não apague, zere ou restaure quotas antigas para permitir novas chamadas.

Na Fase 1, a guarda é aplicada antes da ingestão de cada ativo, de cada tentativa de notícias e de cada chamada lógica de LLM. Os executores manuais posteriores usam seus próprios pontos de reserva do orçamento compartilhado; veja [EXECUCAO.md](manual_dependencies_20260910/EXECUCAO.md) e [AUDITORIA_AMPLIADA_20260910.md](AUDITORIA_AMPLIADA_20260910.md). Uma unidade lógica pode envolver várias requisições HTTP ou retries do cliente. A existência desta guarda não comprova cobertura universal de V3, scripts auxiliares ou serviços externos.

## Cache e rastreabilidade

- Fear & Greed é cacheado por processo e limite, evitando a mesma busca por ativo na rodada.
- Notícias bem-sucedidas são cacheadas no processo por fonte, consulta e limite; o router aceita a entrada apenas quando a idade desde o recebimento está entre zero e menos de uma hora.
- Bloqueios no fluxo da Fase 1 emitem `api_guard_skipped`, com etapa, ativo e motivo. Os executores manuais também registram seus estados e recusas nos artefatos definidos pelo protocolo.

Os limites podem alterar a população coletada. Mudanças em provedores, orçamento ou roteamento precisam de protocolo e amostra novos; H5 permanece encerrada. Consulte [fontes de notícias](NEWS_PROVIDERS.md). Nenhum agendamento ou pagamento foi ativado por esta configuração.
''')
news = (P / 'docs/NEWS_PROVIDERS.md').read_text(encoding='utf-8')
news = news.replace('variaveis de credencial e configuracao do projeto. Copie-o para `.env` no mesmo\ndiretorio e preencha os valores localmente; o `.env` e ignorado pelo Git.\n\nO padrao preserva a H5:', 'variaveis de credencial e configuracao do projeto. Neste PC, preencha somente\n`C:\\Cripto\\configuracao\\pipeline.env`, seguindo [CONFIGURACAO_LOCAL.md](CONFIGURACAO_LOCAL.md),\ne execute pelo atalho `C:\\Cripto\\CRIPTO.cmd`. Nunca publique os valores.\n\nO perfil atual usa SerpAPI. Esta escolha de provedor nao reativa a H5, que permanece encerrada:')
news = news.replace('continua marcada por `input_degradado=1`.', 'continua marcada por `input_degradado=1`.\n\nOs contratos atuais tambem preservam inputs e carimbos de recebimento para novas\nprevisoes, conforme [a auditoria ampliada](AUDITORIA_AMPLIADA_20260910.md). Isso nao\nrecupera noticias originais de previsoes historicas nem comprova retroativamente\na disponibilidade de uma versao da fonte.')
write('docs/NEWS_PROVIDERS.md', news)
index = (P / 'docs/README.md').read_text(encoding='utf-8')
index = index.replace('# Índice da documentação', '# Índice da documentação\n\nComece pela [conferência de arquivos de 10/09](CONFERENCIA_ARQUIVOS_20260910.md) e por [CONTINUAR_AQUI.md](../CONTINUAR_AQUI.md). Esses índices distinguem operação atual, backups e registros históricos.')
index = index.replace('[Estado da pesquisa](CURRENT_RESEARCH_STATE_20260908.md): conclusão econômica, correções e pendências atuais.', '[Estado da pesquisa em 08/09](CURRENT_RESEARCH_STATE_20260908.md): registro histórico; suas pendências não substituem os adendos de 10/09.')
index = index.replace('[agendamento pendente](evidence/carry_forward_20260908/scheduling.json)', '[registro histórico do agendamento](evidence/carry_forward_20260908/scheduling.json)')
index = index.replace('- [Política de merge](POLITICA_DE_MERGE.md), [backup e restauração](BACKUP_RESTORE.md) e [incidente SerpAPI](SECURITY_INCIDENT_SERPAPI.md).', '- [Política de merge e histórico de incidentes](POLITICA_DE_MERGE.md), [backup e restauração](BACKUP_RESTORE.md) e [registro histórico do incidente SerpAPI](SECURITY_INCIDENT_SERPAPI.md). A segurança da branch está excluída do escopo atual; o dono decidiu manter as chaves atuais. As ações antigas não são requisitos novos de revogação.')
write('docs/README.md', index)
config = (P / 'docs/CONFIGURACAO_LOCAL.md').read_text(encoding='utf-8')
config = config.replace('Leia este arquivo, [NEXT_CHAT_PROMPT.md](NEXT_CHAT_PROMPT.md) e o [resultado econômico de 09/09](evidence/economic_round_20260909/RESULTADOS.md).', 'Leia este arquivo, [a conferência atual dos arquivos](CONFERENCIA_ARQUIVOS_20260910.md), [CONFERENCIA_CHAT_20260910.md](CONFERENCIA_CHAT_20260910.md) e [NEXT_CHAT_PROMPT.md](NEXT_CHAT_PROMPT.md), preservado como mandato. O [resultado econômico de 09/09](evidence/economic_round_20260909/RESULTADOS.md) é histórico; a avaliação Aave posterior está em [AAVE_VALIDACAO_20260910.md](AAVE_VALIDACAO_20260910.md).')
write('docs/CONFIGURACAO_LOCAL.md', config)
rootguide = Path(r'C:\Cripto\LEIA_PRIMEIRO.md')
(F / 'LEIA_PRIMEIRO.before.md').write_bytes(rootguide.read_bytes())
rootguide.write_text(r'''# Cripto neste computador

O trabalho e o armazenamento do projeto ficam em **C:\Cripto**. Para continuar sem depender do chat:

1. Leia [AGENTS.md](AGENTS.md) e a [configuração local](pesquisa-20260909/docs/CONFIGURACAO_LOCAL.md).
2. Abra a [retomada preservada de 10/09](RETOMADA_APOS_CHAT_20260910.md) e a [conferência dos arquivos](pesquisa-20260909/docs/CONFERENCIA_ARQUIVOS_20260910.md), que a complementa.
3. Consulte o [registro vivo da revisão](operacao/relatorios/REVISAO_COMPLETA_20260909/REVISAO.md), o [índice documental](pesquisa-20260909/docs/README.md) e o estado real do Git.

| Local | Finalidade |
|---|---|
| `pesquisa-20260909` | Código operacional e ambiente atual |
| `auditoria-ampliada-20260910` | Executor LLM manual v3 congelado em `595f120` |
| `restaurado-20260908` | Código, ambientes, dados e diários preservados da migração |
| `configuracao/pipeline.env` | Configuração privada, fora do Git |
| `operacao` | Dados novos, saídas, cache, estado, logs e relatórios |
| `backups` | Cópias locais verificadas; compartilham o mesmo disco |

```powershell
C:\Cripto\CRIPTO.cmd status
C:\Cripto\CRIPTO.cmd pipeline --help
```

O [prompt original](pesquisa-20260909/docs/NEXT_CHAT_PROMPT.md) permanece intacto como mandato. O fechamento de 09/09 com 1.285 testes é histórico. A referência posterior ao PR #117 (`94fc9e7`) tem 1.505 testes aprovados e um skip de symlink; os resultados de cada publicação seguinte ficam no registro vivo. Não reaproveite a validação de um SHA como se fosse de outro.

`LEIA-ME.md`, `RETOMAR_NO_CODEX.md`, `dados.zip`, os manifestos e os utilitários originais pertencem ao pacote de migração. Preserve-os e preserve toda a pasta restaurada. Não execute restauração sobre esta instalação. Worktrees antigos registram etapas diferentes; aparência de duplicação não significa que podem ser apagados.

O backup privado do chat está em `operacao/relatorios/REVISAO_COMPLETA_20260909/chat_closure_20260910`; seus hashes e o guia de retomada foram verificados. Ele não é publicado no Git.

Nenhum agendamento ou capital foi ativado. Carry e LLM aguardam as janelas dos protocolos; dados originais H5, versões macro comprovadas, segunda fonte Aave e extratos pessoais ainda têm dependências documentadas. As chaves atuais foram mantidas por decisão do dono, e a segurança da branch ficou fora do escopo.
''', encoding='utf-8')
print('Updated eight tracked guides and the local root guide; original handoff and frozen files untouched.')
