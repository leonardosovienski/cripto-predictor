from pathlib import Path
import hashlib
import json
import subprocess

P=Path(r'C:\Cripto\pesquisa-20260909')
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
E=P/'docs/evidence/dependency_execution_20260910'
manifest=json.loads((E/'manifest.json').read_bytes())['files']
names=[(E/n).relative_to(P).as_posix() for n in manifest]
payload=''.join('HEAD:'+n+'\n' for n in names).encode()
raw=subprocess.check_output(['git','cat-file','--batch'],input=payload,cwd=P)
offset=0
bad=[]
for relative,(name,digest) in zip(names,manifest.items()):
    split=raw.index(b'\n',offset)
    header=raw[offset:split].split()
    size=int(header[2])
    blob=raw[split+1:split+1+size]
    offset=split+1+size+1
    worktree=(E/name).read_bytes()
    assert hashlib.sha256(worktree).hexdigest()==digest,relative
    if hashlib.sha256(blob).hexdigest()!=digest:
        bad.append({'path':relative,'worktree_bytes':len(worktree),'blob_bytes':len(blob),
            'only_crlf_difference':worktree.replace(b'\r\n',b'\n')==blob.replace(b'\r\n',b'\n'),
            'worktree_crlf':worktree.count(b'\r\n'),'blob_crlf':blob.count(b'\r\n')})
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip(),'files':len(names),'mismatches':bad}
out=R/'executor_dependencies/git_bytes_before_fix.json'
with out.open('x',encoding='utf-8') as stream: json.dump(record,stream,indent=2)
print(json.dumps(record))
