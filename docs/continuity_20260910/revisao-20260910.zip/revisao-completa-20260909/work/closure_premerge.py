from pathlib import Path
from datetime import UTC, datetime
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
N = Path(r'C:\Cripto\fechamento-revisao-20260910')
def read(path): return json.loads((R/path).read_bytes())
def git(*args): return subprocess.check_output(['git', *args], cwd=N, text=True).strip()
def tests(path):
    cases = ET.parse(R/path).getroot().findall('.//testcase')
    failures = sum(c.find('failure') is not None or c.find('error') is not None for c in cases)
    skips = sum(c.find('skipped') is not None for c in cases)
    return {'passed': len(cases)-failures-skips, 'failed': failures, 'skipped': skips}
first = read('closure_full01/validation.json')
final = read('closure_final02/status.json')
ci = read('closure_audit/ci_pr_final.json')
scanner = json.loads((R/'closure_audit/scanner_final.log').read_text(encoding='utf-8-sig'))
differences = [p for p,h in first['source_hashes'].items() if hashlib.sha256((N/p).read_bytes()).hexdigest() != h]
head = git('rev-parse', 'HEAD')
assert head == final['head'] == ci['head'] == '19da2534baec32028f330d217c32588df35ce19b'
assert git('status', '--porcelain') == ''
assert git('ls-remote', 'origin', 'refs/heads/main').split()[0] == ci['base']
assert differences == ['tests/test_test_environment_isolation.py']
assert final['exit_code'] == 0 and scanner['finding_count'] == 0 and ci['four_jobs_passed']
assert [(c['name'], c['exit_code']) for c in first['checks'] if c['exit_code']] == [('secrets', 1)]
assert all(c['exit_code'] == 0 for c in read('closure_full01/wheel_contract.json')['checks'])
assert tests('closure_final02/tests.xml') == {'passed':1505,'failed':0,'skipped':1}
record = {'at_utc':datetime.now(UTC).isoformat(),'head':head,'base':ci['base'],
    'initial_full_suite':tests('closure_full01/tests.xml'),
    'final_full_suite':tests('closure_final02/tests.xml'),
    'final_full_suite_evidence':'closure_final02/status.json',
    'initial_nonpassing_check':'scanner identified three synthetic sentinels; naming corrected without changing scanner',
    'final_scanner':scanner,'source_files_compared':len(first['source_hashes']),
    'source_files_changed_since_first_full_suite':differences,
    'runtime_and_dependencies_unchanged': not git('diff','--name-only','a917927','HEAD','--','GarimpoInvestimentos','scripts','pyproject.toml','uv.lock','charters'),
    'final_pr_four_jobs_passed':True,'wheel_contract_passed':True,'owner_prompt_not_in_pr':True,
    'pr110_rechecked':{'merged':True,'merge_sha':'9b8de9802c61570610bc0b212bdb0bb4c4e1d643','inline_comments':0,'copilot_review':'not performed; requester quota exceeded'},
}
(R/'closure_audit/premerge.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(record,ensure_ascii=False))
