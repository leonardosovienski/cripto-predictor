from pathlib import Path
import sys
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
runner=R/'work/run_checks.py'
sys.argv=[str(runner),'executors_target03']
source=runner.read_text(encoding='utf-8').split('if PHASE.startswith("postmerge"):')[0]
exec(compile(source,str(runner),'exec'))
result=check('targeted',[CMD,'python','-m','pytest','tests/test_paired_llm.py','tests/test_recover_aave_history.py','-q','-ra','--basetemp',str(TEMP/'pytest'),'--junitxml',str(RUN/'tests.xml')])
typed=check('new_code_types',[CMD,'uv','run','--no-sync','pyright','scripts/paired_llm.py','scripts/paired_llm_source.py','scripts/recover_aave_history.py'])
raise SystemExit(result.returncode or typed.returncode)
