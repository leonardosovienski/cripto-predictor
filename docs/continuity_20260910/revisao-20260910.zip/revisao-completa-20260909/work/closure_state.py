from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys

R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
P = Path(r'C:\Cripto\pesquisa-20260909')
W = Path(r'C:\Cripto\auditoria-ampliada-20260910')
N = Path(r'C:\Cripto\fechamento-revisao-20260910')
def git(path, *args):
    return subprocess.check_output(['git', *args], cwd=path, text=True).strip()
def rows(path, query):
    with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as conn:
        return conn.execute(query).fetchall()
budget = rows(Path(r'C:\Cripto\operacao\dados\api_guard_budget.db'), 'SELECT bucket,stage,guard_key,used FROM api_budget ORDER BY bucket,stage,guard_key')
expected = json.loads((R / 'expansion_budget_incident/result.json').read_bytes())['after']
db = Path(r'C:\Cripto\operacao\saidas\feature_store.db')
record = {
    'at_utc': datetime.now(UTC).isoformat(),
    'operational_head': git(P, 'rev-parse', 'HEAD'),
    'operational_status': git(P, 'status', '--porcelain'),
    'correction_head': git(N, 'rev-parse', 'HEAD'),
    'correction_status': git(N, 'status', '--porcelain'),
    'llm_frozen_checkout_head': git(W, 'rev-parse', 'HEAD'),
    'llm_frozen_checkout_status': git(W, 'status', '--porcelain'),
    'owner_prompt_sha256': hashlib.sha256((P / 'docs/NEXT_CHAT_PROMPT.md').read_bytes()).hexdigest(),
    'budget': budget,
    'budget_matches_reservation': sorted(budget) == sorted(map(tuple, expected)),
    'database_quick_check': rows(db, 'PRAGMA quick_check'),
    'table_counts': {table: rows(db, f'SELECT COUNT(*) FROM {table}')[0][0] for table in ('predictions', 'prediction_inputs', 'market_snapshots')},
    'snapshot_versions': rows(db, 'SELECT feature_version,COUNT(*) FROM market_snapshots GROUP BY feature_version'),
    'runtime_diff_from_a917': git(N, 'diff', '--name-only', 'a917927', 'HEAD', '--', 'GarimpoInvestimentos', 'scripts', 'charters', 'pyproject.toml', 'uv.lock'),
}
assert record['budget_matches_reservation']
assert record['owner_prompt_sha256'] == '8969db38ef9a3ec29ee16a780b9572ec9f7d7808cabc9bac17a319616b47fe20'
assert record['llm_frozen_checkout_head'] == '595f1203475d04b01966ac3471bbafd6770dbb4d'
assert not record['llm_frozen_checkout_status']
assert not record['runtime_diff_from_a917']
assert record['database_quick_check'] == [('ok',)]
target = R / 'closure_audit' / (sys.argv[1] + '.json')
assert not target.exists()
target.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(record, ensure_ascii=False))
