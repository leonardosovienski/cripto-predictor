from pathlib import Path

P = Path(r'C:\Cripto\auditoria-ampliada-20260910')

def update(name, pairs):
    path = P / name
    text = path.read_text(encoding='utf-8')
    for old, new in pairs:
        assert old in text, (name, old[:100])
        text = text.replace(old, new)
    path.write_text(text, encoding='utf-8')

update('GarimpoInvestimentos/trading/contracts.py', [
    ('import uuid', 'import math\nimport uuid'),
    ('def ensure_utc(value: datetime, label: str) -> datetime:', '''def require_finite(value: float, label: str) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{label} deve ser um número finito")


def ensure_utc(value: datetime, label: str) -> datetime:'''),
    ('if value.tzinfo is None:', 'if value.tzinfo is None or value.utcoffset() is None:'),
    ('        if self.holding_period_hours <= 0:', '''        for name in ("holding_period_hours", "target_position_fraction", "slippage_limit_bps", "estimated_round_trip_friction", "stop_loss_pct", "take_profit_pct"):
            value = getattr(self, name)
            if value is not None:
                require_finite(value, f"TradeIntent.{name}")
        if self.holding_period_hours <= 0:'''),
    ('        if self.qty <= 0:', '        require_finite(self.qty, f"{type(self).__name__}.qty")\n        if self.qty <= 0:'),
    ('        if self.price <= 0:', '        require_finite(self.price, "Fill.price")\n        if self.price <= 0:'),
    ('        if self.fee < 0:', '        require_finite(self.fee, "Fill.fee")\n        if self.fee < 0:'),
    ('        if self.limit_price is not None and self.limit_price <= 0:', '        if self.limit_price is not None:\n            require_finite(self.limit_price, "Order.limit_price")\n        if self.limit_price is not None and self.limit_price <= 0:'),
    ('        object.__setattr__(self, "created_at", created)', '''        fill_ids = set()
        for fill in self.fills:
            if fill.order_id != self.order_id or fill.fill_id in fill_ids:
                raise ValueError("Order: fill de outra ordem ou fill_id duplicado")
            fill_ids.add(fill.fill_id)
            if fill.filled_at < created:
                raise ValueError("Order: fill anterior a created_at")
            if self.accepted_at is not None and fill.filled_at < ensure_utc(self.accepted_at, "accepted_at"):
                raise ValueError("Order: fill anterior a accepted_at")
        object.__setattr__(self, "created_at", created)'''),
    ('        if self.avg_entry_price <= 0:', '        require_finite(self.avg_entry_price, "Position.avg_entry_price")\n        if self.avg_entry_price <= 0:'),
    ('        return self.qty * mark_price', '        require_finite(mark_price, "mark_price")\n        if mark_price <= 0:\n            raise ValueError("mark_price deve ser > 0")\n        return self.qty * mark_price'),
    ('    def unrealized_pnl(self, mark_price: float) -> float:\n        sign', '    def unrealized_pnl(self, mark_price: float) -> float:\n        self.notional(mark_price)\n        sign'),
    ('        if self.entry_price <= 0 or self.exit_price <= 0:', '        require_finite(self.entry_price, "SettlementRecord.entry_price")\n        require_finite(self.exit_price, "SettlementRecord.exit_price")\n        require_finite(self.fees_paid, "SettlementRecord.fees_paid")\n        if self.entry_price <= 0 or self.exit_price <= 0:'),
])

update('GarimpoInvestimentos/trading/execution.py', [
    ('import Fill, Order, OrderStatus', 'import Fill, Order, OrderStatus, require_finite'),
    ('def apply_fill(order: Order, fill: Fill) -> Order:\n', '''def apply_fill(order: Order, fill: Fill) -> Order:
    for existing in order.fills:
        if existing.fill_id == fill.fill_id:
            if existing != fill:
                raise OrderLifecycleError("fill_id já existe com conteúdo diferente")
            return order
'''),
    ('        self._fills_by_order[fill.order_id] = (*existing, fill)', '''        for previous in existing:
            if previous.fill_id == fill.fill_id:
                if previous != fill:
                    raise OrderLifecycleError("fill_id já existe com conteúdo diferente")
                return
        self._fills_by_order[fill.order_id] = (*existing, fill)'''),
    ('    exchange_filled_qty: float\n', '    exchange_filled_qty: float\n    reasons: tuple[str, ...] = ()\n'),
    ('    exchange_fills = adapter.reported_fills(order.order_id)', '''    require_finite(tolerance, "tolerance")
    if tolerance < 0:
        raise ValueError("tolerance não pode ser negativa")
    exchange_fills = adapter.reported_fills(order.order_id)'''),
    ('''    if abs(local_qty - exchange_qty) <= tolerance:
        return None
    return ReconciliationBreak(order.order_id, local_qty, exchange_qty)''', '''    reasons = []
    if abs(local_qty - exchange_qty) > tolerance:
        reasons.append("quantity")
    local = {f.fill_id: f for f in order.fills}
    remote = {f.fill_id: f for f in exchange_fills}
    if len(remote) != len(exchange_fills) or any(f.order_id != order.order_id for f in exchange_fills):
        reasons.append("invalid_exchange_receipts")
    if local.keys() != remote.keys():
        reasons.append("fill_identity")
    for key in local.keys() & remote.keys():
        a, b = local[key], remote[key]
        if any(abs(getattr(a, field) - getattr(b, field)) > tolerance for field in ("qty", "price", "fee")) or a.filled_at != b.filled_at or a.liquidity != b.liquidity:
            reasons.append("fill_content")
            break
    return ReconciliationBreak(order.order_id, local_qty, exchange_qty, tuple(reasons)) if reasons else None'''),
    ('        existing_order_id = self._client_order_ids.get(client_order_id)', '''        if not client_order_id.strip():
            raise OrderLifecycleError("client_order_id não pode ser vazio")
        existing_order_id = self._client_order_ids.get(client_order_id)'''),
    ('            return self._orders[existing_order_id]\n        self._orders[order.order_id] = order', '''            existing = self._orders[existing_order_id]
            fields = ("instrument", "side", "order_type", "qty", "limit_price")
            if any(getattr(existing, f) != getattr(order, f) for f in fields):
                raise OrderLifecycleError("client_order_id já existe com condições diferentes")
            return existing
        if order.order_id in self._orders:
            raise OrderLifecycleError("order_id já pertence a outro client_order_id")
        self._orders[order.order_id] = order'''),
    ('        self._orders[order.order_id] = order\n\n    def open_orders', '''        previous = self._orders[order.order_id]
        if any(getattr(previous, f) != getattr(order, f) for f in ("intent_id", "instrument", "side", "order_type", "qty", "limit_price", "created_at")):
            raise OrderLifecycleError("update não pode alterar identidade ou condições da ordem")
        if not set(previous.fills).issubset(order.fills):
            raise OrderLifecycleError("update não pode remover ou alterar fills")
        if previous.status in _TERMINAL_STATES and order != previous:
            raise OrderLifecycleError("update não pode reabrir estado terminal")
        self._orders[order.order_id] = order

    def open_orders'''),
])

update('GarimpoInvestimentos/trading/microstructure.py', [
    ('import Instrument, OrderSide, ensure_utc', 'import Instrument, OrderSide, ensure_utc, require_finite'),
    ('        if self.price <= 0:', '        require_finite(self.price, "OrderBookLevel.price")\n        require_finite(self.qty, "OrderBookLevel.qty")\n        if self.price <= 0:'),
    ('        if bid_prices != sorted(bid_prices, reverse=True):', '        if len(set(bid_prices)) != len(bid_prices):\n            raise ValueError("OrderBookSnapshot.bids contêm preços duplicados")\n        if bid_prices != sorted(bid_prices, reverse=True):'),
    ('        if ask_prices != sorted(ask_prices):', '        if len(set(ask_prices)) != len(ask_prices):\n            raise ValueError("OrderBookSnapshot.asks contêm preços duplicados")\n        if ask_prices != sorted(ask_prices):'),
    ('        return self.filled_qty >= self.requested_qty - 1e-12', '        return self.filled_qty > 0 and math.isclose(self.filled_qty, self.requested_qty, rel_tol=1e-12, abs_tol=0.0)'),
    ('        for price, qty in (*self.bids, *self.asks):\n', '        for price, qty in (*self.bids, *self.asks):\n            require_finite(price, "DepthUpdate.price")\n            require_finite(qty, "DepthUpdate.qty")\n'),
    ('        for book, changes in ((self._bids, update.bids), (self._asks, update.asks)):', '        bids, asks = self._bids.copy(), self._asks.copy()\n        for book, changes in ((bids, update.bids), (asks, update.asks)):'),
    ('        if not self._bids or not self._asks:', '        if not bids or not asks:'),
    ('        self._last_update_id = update.final_update_id', '        if max(bids) >= min(asks):\n            raise DepthSequenceGap("update cruzou o book; resnapshot obrigatório")\n        self._bids, self._asks = bids, asks\n        self._last_update_id = update.final_update_id'),
    ('    if qty <= 0:\n', '    require_finite(qty, "qty")\n    if not isinstance(side, OrderSide):\n        raise ValueError("side inválido")\n    if qty <= 0:\n'),
    ('        if remaining <= 1e-12:', '        if remaining <= 0:'),
    ('if filled_qty > 1e-12 else None', 'if filled_qty > 0 else None'),
    ('    if not (0 <= participation_rate <= 1):', '    for label, value in (("participation_rate", participation_rate), ("volatility_bps", volatility_bps), ("kappa", kappa)):\n        require_finite(value, label)\n    if not (0 <= participation_rate <= 1):'),
])

update('GarimpoInvestimentos/trading/report.py', [
    ('        notionals[position.instrument.key] = position.notional(mark)', '        key = position.instrument.key\n        notionals[key] = notionals.get(key, 0.0) + position.notional(mark)'),
])

update('GarimpoInvestimentos/trading/costs.py', [
    ('import OrderSide', 'import OrderSide, require_finite'),
    ('    if qty <= 0:', '    for label, value in (("qty", qty), ("taker_fee_bps", taker_fee_bps), ("latency_penalty_bps_per_leg", latency_penalty_bps_per_leg)):\n        require_finite(value, label)\n    if qty <= 0:'),
    ('    if entry_book.instrument != exit_book.instrument:', '    if entry_book.instrument.asset_class != "crypto_spot":\n        raise ValueError("spot round trip exige instrumento crypto_spot")\n    if entry_book.instrument != exit_book.instrument:'),
])

update('GarimpoInvestimentos/trading/portfolio.py', [
    ('import Direction, Position', 'import Direction, Position, require_finite'),
    ('    if len(a) != len(b):', '    for value in (*a, *b):\n        require_finite(value, label)\n    if len(a) != len(b):'),
    ('    total = sum(abs(v) for v in notionals_by_key.values())', '    for value in notionals_by_key.values():\n        require_finite(value, "notional")\n    total = sum(abs(v) for v in notionals_by_key.values())'),
    ('\n    if equity <= 0:', '\n    require_finite(equity, "equity")\n    if equity <= 0:'),
    ('        if equity <= 0:', '        require_finite(equity, "equity")\n        if equity <= 0:'),
    ('    if target_vol < 0 or asset_vol < 0:', '    for label, value in (("target_vol", target_vol), ("asset_vol", asset_vol), ("capital", capital)):\n        require_finite(value, label)\n    if target_vol < 0 or asset_vol < 0:'),
    ('    if leverage <= 0:', '    require_finite(leverage, "leverage")\n    require_finite(maintenance_margin_rate, "maintenance_margin_rate")\n    if leverage <= 0:'),
    ('    if abs(local_balance - reported_balance) <= tolerance:', '    for label, value in (("local_balance", local_balance), ("reported_balance", reported_balance), ("tolerance", tolerance)):\n        require_finite(value, label)\n    if tolerance < 0:\n        raise ValueError("tolerance não pode ser negativa")\n    if abs(local_balance - reported_balance) <= tolerance:'),
])
