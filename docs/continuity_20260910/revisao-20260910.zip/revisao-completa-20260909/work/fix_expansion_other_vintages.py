from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
f=p/'GarimpoInvestimentos/dpl/providers/bcb.py';s=f.read_text(encoding='utf-8');a=s.index('"""',3)+3
s='''"""BCB SGS current observations, stamped at the receipt of this vintage.

Reference dates identify periods, not releases. A fixed lag cannot date revisions.
Historical as-of use requires an independently documented release/vintage archive.
"""'''+s[a:]
s=s.replace('from datetime import UTC, datetime, timedelta','from datetime import UTC, datetime\nimport math\nfrom GarimpoInvestimentos.trading.contracts import ensure_utc')
s=s.replace('        self.series_code = series_code','        if isinstance(series_code, bool) or not isinstance(series_code, int) or series_code <= 0 or not name:\n            raise ValueError("series_code/name invalido")\n        if isinstance(publish_lag_days, bool) or not isinstance(publish_lag_days, int) or publish_lag_days < 0:\n            raise ValueError("lag invalido")\n        self.series_code = series_code')
s=s.replace('        self._lag = timedelta(days=publish_lag_days)','        # Legacy parameter accepted for compatibility; never used to backdate publication.')
s=s.replace('        vintage = collected_at or datetime.now(UTC)','        if isinstance(limit, bool) or not isinstance(limit, int) or limit <= 0:\n            raise ValueError("limit deve ser inteiro positivo")\n        if collected_at is not None:\n            ensure_utc(collected_at, "collected_at")')
s=s.replace('            rows = await self._get(limit)','            rows = await self._get(limit)\n            vintage = ensure_utc(collected_at or datetime.now(UTC), "collected_at")')
s=s.replace('        points = []\n        for item in rows:','        points = []\n        seen = {}\n        for item in rows:')
s=s.replace('            points.append(\n                SignalPoint(','            value = float(item["valor"])\n            if not math.isfinite(value) or ref > vintage:\n                raise ValueError("valor/data SGS invalido")\n            if ref in seen:\n                if seen[ref] != value:\n                    raise ValueError("observacoes SGS conflitantes")\n                continue\n            seen[ref] = value\n            points.append(\n                SignalPoint(',1)
s=s.replace('value=float(item["valor"]),','value=value,').replace('published_at=ref + self._lag,','published_at=vintage,\n                    collector_version="bcb_observed_vintage_v2",\n                    quality_flags=frozenset({"publication_history_unverified", "available_at_receipt"}),')
s=s.replace('        return points','        return sorted(points, key=lambda point: point.timestamp)')
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/dpl/providers/fear_greed.py';s=f.read_text(encoding='utf-8').replace('from datetime import UTC, datetime','from datetime import UTC, datetime\nimport math\nimport time')
s=s.replace('O índice de um dia é publicado naquele mesmo dia → published_at = timestamp.','O timestamp da API e a referencia. Esta versao fica disponivel no recebimento;\nnao existe prova de publicacao historica neste endpoint.')
s=s.replace('    def __init__(self):\n        self._cache: dict[int, list[SignalPoint]] = {}','    def __init__(self, cache_ttl_seconds: float = 300.0):\n        if not math.isfinite(cache_ttl_seconds) or cache_ttl_seconds <= 0:\n            raise ValueError("cache_ttl_seconds deve ser positivo finito")\n        self._cache_ttl_seconds = cache_ttl_seconds\n        self._cache: dict[int, tuple[float, tuple[SignalPoint, ...]]] = {}')
s=s.replace('        if limit in self._cache:\n            return self._cache[limit]','        if isinstance(limit, bool) or not isinstance(limit, int) or limit <= 0:\n            raise ValueError("limit deve ser inteiro positivo")\n        cached = self._cache.get(limit)\n        if cached and time.monotonic() - cached[0] < self._cache_ttl_seconds:\n            return list(cached[1])')
s=s.replace('        points = []','        received_at = datetime.now(UTC)\n        points = []\n        seen = {}',1)
s=s.replace('            points.append(\n                SignalPoint(','            value = float(item["value"])\n            if not math.isfinite(value) or not 0 <= value <= 100 or ts > received_at:\n                raise ValueError("Fear and Greed com valor/data invalido")\n            if ts in seen:\n                if seen[ts] != value:\n                    raise ValueError("Fear and Greed com observacoes conflitantes")\n                continue\n            seen[ts] = value\n            points.append(\n                SignalPoint(',1)
s=s.replace('value=float(item["value"]),','value=value,').replace('published_at=ts,  # índice diário publicado no próprio dia','published_at=received_at,\n                    vintage=received_at,\n                    collector_version="fear_greed_observed_vintage_v2",\n                    quality_flags=frozenset({"publication_history_unverified", "available_at_receipt"}),')
s=s.replace('        self._cache[limit] = points\n        return points','        points.sort(key=lambda point: point.timestamp)\n        self._cache[limit] = (time.monotonic(), tuple(points))\n        return list(points)')
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/dpl/derivatives.py';s=f.read_text(encoding='utf-8').replace('COLLECTOR_VERSION = "funding-oi-v3/1"','COLLECTOR_VERSION = "funding-oi-v3/2"').replace('separators=(",", ":"))','separators=(",", ":"), allow_nan=False)')
s=s.replace('published_at=event_at,','published_at=ingested_at,').replace('        published_at = event_at','        published_at = ingested_at')
s=s.replace('frozenset({"published_at_exchange"})','frozenset({"available_at_receipt", "publication_history_unverified"})').replace('frozenset({"published_at_exchange_timestamp"})','frozenset({"available_at_receipt", "publication_history_unverified"})')
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/v3/pipeline.py';s=f.read_text(encoding='utf-8');a=s.index('    cache_paths = [path for path in');b=s.index('    quality_states = {}',a)
s=s[:a]+'''    # A CSV mtime is not an authenticated acquisition/publication timestamp.
    # This read establishes availability of this version now, not in the past.
    ingested_at = datetime.now(UTC)
''' + s[b:];f.write_text(s,encoding='utf-8')
