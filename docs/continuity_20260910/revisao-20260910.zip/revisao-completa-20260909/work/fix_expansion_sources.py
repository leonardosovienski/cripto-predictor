from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
f=p/'GarimpoInvestimentos/v3/collectors/binance_vision.py';s=f.read_text(encoding='utf-8')
a=s.index('"""',3)+3
s='''"""Public Binance archives with mandatory checksum and explicit market identity.

Spot klines use /data/spot; funding and OI use /data/futures/um.
Spot archive timestamps from 2025-01-01 are microseconds, normalized to ms.
Cached archives are immutable observed versions, not historical availability proof.
Official schema: https://github.com/binance/binance-public-data/blob/master/README.md
"""'''+s[a:]
s=s.replace('import logging\n','import logging\nimport json\nimport re\n')
s=s.replace('from GarimpoInvestimentos.core.paths import CACHE_DIR','from GarimpoInvestimentos.core.paths import CACHE_DIR\nfrom GarimpoInvestimentos.durable_io import atomic_write, file_lock\nfrom GarimpoInvestimentos.v3.collectors.record_io import validate_observation, unique_records')
a=s.index('def _cache_path(');b=s.index('# ------------------------------------------------------------------ #\n# Iteradores',a)
s=s[:a]+'''def _cache_path(rel_url: str, market: str = "futures/um") -> Path:
    if market not in {"futures/um", "spot"} or ".." in rel_url or "\\\\" in rel_url or rel_url.startswith("/"):
        raise ValueError("caminho de arquivo Vision invalido")
    return _CACHE_DIR / "verified_v2" / market.replace("/", "_") / rel_url.replace("/", "__")


def _verify_checksum(content: bytes, checksum_text: str) -> bool:
    fields = checksum_text.strip().split()
    return bool(fields and re.fullmatch(r"[a-fA-F0-9]{64}", fields[0]) and fields[0].lower() == hashlib.sha256(content).hexdigest())


def _download_zip(rel_url: str, client: httpx.Client, *, market: str = "futures/um") -> bytes | None:
    cache = _cache_path(rel_url, market)
    checksum = cache.with_suffix(cache.suffix + ".CHECKSUM")
    url = f"https://data.binance.vision/data/{market}/{rel_url}"
    with file_lock(cache):
        if cache.exists():
            content = cache.read_bytes()
            if not checksum.exists() or not _verify_checksum(content, checksum.read_text(encoding="utf-8")):
                raise OSError(f"Cache Vision sem checksum valido: {cache}")
            return content
        response = client.get(url)
        if response.status_code == 404:
            logger.warning("Arquivo Vision ausente: %s", url)
            return None
        response.raise_for_status()
        content = response.content
        cr = client.get(f"{url}.CHECKSUM")
        cr.raise_for_status()
        if not _verify_checksum(content, cr.text):
            raise OSError(f"Checksum SHA256 nao confere para {url}")
        # Publish data last: a data file always has its source/checksum receipt.
        atomic_write(checksum, cr.text.encode("utf-8"))
        receipt = {"url": url, "retrieved_at": datetime.now(UTC).isoformat(), "sha256": hashlib.sha256(content).hexdigest(), "historical_availability_verified": False}
        atomic_write(cache.with_suffix(".receipt.json"), json.dumps(receipt, sort_keys=True).encode("utf-8"))
        atomic_write(cache, content)
        return content


def _read_csv_rows(zip_bytes: bytes) -> list[list[str]]:
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
        files = [item for item in archive.infolist() if not item.is_dir()]
        if len(files) != 1 or not files[0].filename.lower().endswith(".csv") or files[0].file_size > 64 * 1024 * 1024:
            raise ValueError("Vision ZIP exige um CSV de ate 64 MiB")
        text = archive.read(files[0]).decode("utf-8-sig")
    rows = [row for row in csv.reader(io.StringIO(text)) if row]
    if rows and rows[0][0].strip().lower() in {"calc_time", "open_time", "create_time"}:
        rows = rows[1:]
    return rows


''' + s[b:]
# Validate externally supplied symbols/ranges before building URLs.
s=s.replace('    start = datetime.fromtimestamp(start_ms / 1000, tz=UTC)','    validate_observation(symbol, start_ms, {})\n    if end_ms < start_ms:\n        raise ValueError("intervalo Vision invalido")\n    start = datetime.fromtimestamp(start_ms / 1000, tz=UTC)')
a=s.index('def load_klines_vision');b=s.index('def load_oi_vision',a);part=s[a:b]
part=part.replace('    start = datetime.fromtimestamp','    if interval != "1h":\n        raise ValueError("KlineRecord deste pipeline representa somente 1h")\n    available_at_ms = min(end_ms, int(datetime.now(UTC).timestamp() * 1000))\n    start = datetime.fromtimestamp',1)
part=part.replace('_download_zip(rel, client)','_download_zip(rel, client, market="spot")')
part=part.replace('                ts = int(row[0])\n                if start_ms <= ts <= end_ms:','                raw_ts = int(row[0])\n                ts = raw_ts // 1000 if y >= 2025 else raw_ts\n                if y >= 2025 and raw_ts % 1000:\n                    raise ValueError("open_time nao alinhado em ms")\n                if start_ms <= ts and ts + 3_600_000 <= available_at_ms:')
s=s[:a]+part+s[b:]
a=s.index('                if ts is None or not (start_ms <= ts <= end_ms):');b=s.index('    out.sort(key=lambda r: r.timestamp_ms)',a)
s=s[:a]+'''                if ts is None or row[1] != symbol:
                    raise ValueError("metrics Vision com data/symbol divergente")
                if not start_ms <= ts <= end_ms:
                    continue
                out.append(OIRecord(symbol, ts, float(row[2]), float(row[3])))
''' + s[b:]
s=s.replace('return out\n\n\ndef load_klines','return unique_records(out, "funding_time_ms")\n\n\ndef load_klines')
s=s.replace('return out\n\n\ndef load_oi','return unique_records(out, "open_ms")\n\n\ndef load_oi')
s=s.replace('return out\n\n\ndef _parse_metrics','return unique_records(out, "timestamp_ms")\n\n\ndef _parse_metrics')
f.write_text(s,encoding='utf-8')
for name in ['GarimpoInvestimentos/v3/pipeline.py','GarimpoInvestimentos/v3/backtest_v3.py','GarimpoInvestimentos/v3/paper_report.py','GarimpoInvestimentos/v3/vision_ingest.py','GarimpoInvestimentos/analyzers/hypothesis_loop_runner.py','tests/test_v3_macro_dxy_integration.py']:
 f=p/name;s=f.read_text(encoding='utf-8').replace('spot_1h.csv','spot_binance_1h.csv');f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/dpl/providers/dxy.py';s=f.read_text(encoding='utf-8');a=s.index('"""',3)+3
s='''"""FRED DTWEXBGS observed vintage, not an invented historical publication date.

The H.10 release is weekly and historical FRED values can be revised.
This current CSV provides no publication history. Values become usable at receipt.
Historical tests require archived releases or a separately verified vintage table.
https://www.federalreserve.gov/releases/h10/about.htm
"""'''+s[a:]
s=s.replace('import io\n','import io\nimport math\n')
s=s.replace('        self._series = series','        if isinstance(publish_lag_days, bool) or not isinstance(publish_lag_days, int) or publish_lag_days < 0:\n            raise ValueError("publish_lag_days nao pode ser negativo ou fracionario")\n        self._series = series')
s=s.replace('        raw = await self._get_csv()','        if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:\n            raise ValueError("limit deve ser inteiro positivo")\n        raw = await self._get_csv()\n        received_at = datetime.now(UTC)')
s=s.replace('        for row in rows[-limit:]:','        seen: dict[datetime, float] = {}\n        for row in rows:\n            if row.get(self._series) == ".":\n                continue')
s=s.replace('            except (KeyError, ValueError):\n                continue  # "." = feriado/sem dado publicado — pula, não interpola','            except (KeyError, ValueError) as exc:\n                raise ValueError("Linha FRED invalida") from exc\n            if not math.isfinite(value) or value <= 0 or day > received_at:\n                raise ValueError("Valor/data FRED invalido")\n            if day in seen:\n                if seen[day] != value:\n                    raise ValueError("FRED tem observacoes conflitantes")\n                continue\n            seen[day] = value')
s=s.replace('published_at=_add_business_days(day, self._lag_business_days),','published_at=received_at,\n                    vintage=received_at,\n                    collector_version="fred_observed_vintage_v2",\n                    quality_flags=frozenset({"publication_history_unverified", "available_at_receipt"}),')
s=s.replace('        return points','        return sorted(points, key=lambda point: point.timestamp)[-limit:]')
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/dpl/business_days.py';s=f.read_text(encoding='utf-8');a=s.index('"""',3)+3
s='''"""Weekend-only calendar arithmetic; does not establish publication availability.

A fixed business-day lag ignores holidays, release hours and revised vintages.
Use documented publication timestamps for causal historical research.
"""'''+s[a:];s=s.replace('    if n < 0:','    if isinstance(n, bool) or not isinstance(n, int) or n < 0:');f.write_text(s,encoding='utf-8')
