from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
f=p/'GarimpoInvestimentos/v3/costs.py';s=f.read_text(encoding='utf-8').replace('from dataclasses import dataclass','from dataclasses import dataclass\nfrom GarimpoInvestimentos.trading.contracts import require_finite')
s=s.replace('    def friction(self, position: float) -> float:','''    def __post_init__(self) -> None:
        for name in ("taker_fee_bps", "slippage_bps"):
            require_finite(getattr(self, name), name)
            if getattr(self, name) < 0:
                raise ValueError("custos nao podem ser negativos")

    def friction(self, position: float, *, exit_price_ratio: float = 1.0) -> float:''')
s=s.replace('        per_leg = (self.taker_fee_bps','        require_finite(position, "position")\n        require_finite(exit_price_ratio, "exit_price_ratio")\n        if exit_price_ratio <= 0:\n            raise ValueError("exit_price_ratio deve ser positivo")\n        per_leg = (self.taker_fee_bps')
s=s.replace('return 2.0 * per_leg * abs(position)','return (1 + exit_price_ratio) * per_leg * abs(position)')
s=s.replace('        n_windows = horizon_hours / _FUNDING_WINDOW_HOURS','        for name, value in (("position", position), ("funding_rate", funding_rate), ("horizon_hours", horizon_hours)):\n            require_finite(value, name)\n        if horizon_hours < 0:\n            raise ValueError("horizon_hours nao pode ser negativo")\n        n_windows = horizon_hours / _FUNDING_WINDOW_HOURS')
s=s.replace('        if position == 0.0:','        require_finite(gross, "gross")\n        require_finite(position, "position")\n        if position == 0.0:')
s=s.replace('aproximação conservadora\n     documentada','cenario de taxa constante, que pode subestimar ou superestimar o realizado,\n     explicitamente sem garantia conservadora')
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/trading/cost_policy.py';s=f.read_text(encoding='utf-8');a=s.index('"""',3)+3
s='''"""Route simulation costs by instrument; historical use is not execution calibration.

Neither the fixed-bps perpetual scenario nor the spot order-book simulation has
account/tier/size-specific calibration sufficient to certify realized profitability.
Historical frozen NO-GO results remain preserved; they are not recalibrated here.
"""'''+s[a:];s=s.replace('CALIBRATED_FOR_VERDICT = frozenset({PERP})','CALIBRATED_FOR_VERDICT = frozenset()')
s=s.replace('f"o modelo de custo de {classe!r} (walk-the-book, trading/costs.py) e "','f"o modelo de custo de {classe!r} e "').replace('"explicitamente NAO CALIBRADO contra execucao real (override 2026-08-14). "','"NAO CALIBRADO contra execucao real para conta/tamanho/tier. "');f.write_text(s,encoding='utf-8')
f=p/'tests/test_trading_report_and_cost_policy.py';s=f.read_text(encoding='utf-8').replace('def test_perp_sustenta_veredito_porque_foi_o_que_julgou_H1_H2_H3():','def test_uso_historico_de_perp_nao_prova_calibracao_para_veredito():');s=s.replace('    assert_verdict_grade(perp)  # não levanta\n    assert isinstance(cost_model_for(perp, for_verdict=True), CostModel)','    with pytest.raises(UncalibratedCostModel):\n        assert_verdict_grade(perp)\n    with pytest.raises(UncalibratedCostModel):\n        cost_model_for(perp, for_verdict=True)');f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/v3/economic_gate.py';s=f.read_text(encoding='utf-8')
s=s.replace('    z_score: float = 1.96,','    z_score: float = 1.96,\n    max_lag: int = 0,')
s=s.replace('    values = [float(value) for value in signed_returns if math.isfinite(float(value))]','    values = [float(value) for value in signed_returns]\n    if any(not math.isfinite(value) for value in values):\n        raise ValueError("edge sample must be finite")')
s=s.replace('    if minimum_sample < 2 or z_score <= 0:','    if minimum_sample < 2 or not math.isfinite(z_score) or z_score <= 0 or isinstance(max_lag, bool) or not isinstance(max_lag, int) or max_lag < 0:')
s=s.replace('    standard_error = st.stdev(values) / math.sqrt(len(values))','''    n = len(values)
    centered = [value - mean for value in values]
    variance = sum(value * value for value in centered) / n
    lag_limit = min(max_lag, n - 1)
    for lag in range(1, lag_limit + 1):
        covariance = sum(centered[i] * centered[i - lag] for i in range(lag, n)) / n
        variance += 2 * (1 - lag / (lag_limit + 1)) * covariance
    standard_error = math.sqrt(max(0, variance) / (n - 1))''')
s=s.replace('    """Estimate mean signed return without looking at the evaluation period."""','    """Descriptive IS mean with Bartlett HAC error for declared overlap lag.\n\n    This is an in-sample screen, not a post-selection confidence guarantee.\n    """')
s=s.replace('        direction not in {-1, 1}\n','        direction not in {-1, 1}\n        or not math.isfinite(horizon_hours)\n        or not math.isfinite(minimum_net_edge)\n')
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/v3/backtest_v3.py';s=f.read_text(encoding='utf-8').replace('direction: estimate_edge(values, minimum_sample=minimum_edge_calibration_sample)','direction: estimate_edge(values, minimum_sample=minimum_edge_calibration_sample, max_lag=max(0, math.ceil(horizon_hours / 8) - 1))');s=s.replace('net = gross + funding - costs.friction(position)','net = gross + funding - costs.friction(position, exit_price_ratio=math.exp(barrier.log_return))');f.write_text(s,encoding='utf-8')
