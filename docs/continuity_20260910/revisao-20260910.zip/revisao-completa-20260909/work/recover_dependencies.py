"""Bounded recovery: one new archive source and public GitHub artifact inventory."""
from datetime import UTC, datetime
from pathlib import Path
import json
import httpx
from GarimpoInvestimentos.config import settings
from GarimpoInvestimentos.core.api_guard import allow

ROOT = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\executor_dependencies')
ROOT.mkdir(parents=True, exist_ok=False)
now = lambda: datetime.now(UTC).isoformat()
def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
scope = {'registered_at': now(), 'aave_endpoint': 'https://arb-mainnet.g.alchemy.com/public',
 'free_evidence': 'https://www.alchemy.com/rpc/arbitrum', 'rpc_calls_max': 2,
 'github_artifact_list_pages_max': 8, 'response_bytes_max': 3000000,
 'retries': 0, 'orders': False, 'accounts': False, 'payments': False,
 'same_reserve_and_period': True, 'budget_units_max': 2}
save('scope.json', scope)
assert settings.API_GUARD_ENABLED and settings.API_GUARD_MAX_INGEST_ASSETS == 28
def request(client, name, method, url, **kwargs):
    row = {'at': now(), 'method': method, 'url': url}
    try:
        with client.stream(method, url, **kwargs) as response:
            body = bytearray()
            for chunk in response.iter_bytes(chunk_size=65536):
                body.extend(chunk)
                if len(body) > 3000000:
                    raise ValueError('Response limit')
            row['status'] = response.status_code
            row['response'] = json.loads(body)
    except Exception as exc:
        row['error_type'] = type(exc).__name__
    save(name, row)
    return row
with httpx.Client(timeout=15, trust_env=False, follow_redirects=False) as client:
    if allow('ingest', 'assets', 28).allowed:
        old = json.loads(Path(r'C:\Cripto\pesquisa-20260909\docs\evidence\economic_round_20260909\h1_rpc\005.json').read_bytes())['request']['params']
        for i, (method, params) in enumerate([('eth_chainId', []), ('eth_call', old)], 1):
            row = request(client, f'aave-{i}.json', 'POST', scope['aave_endpoint'],
                          json={'jsonrpc':'2.0', 'id':i, 'method':method, 'params':params})
            if i == 1 and row.get('response', {}).get('result') != '0xa4b1':
                break
        save('aave-result.json', {'last_response': row, 'calls': i})
        print('Aave probe saved', flush=True)
    if allow('ingest', 'assets', 28).allowed:
        artifacts = []
        complete = False
        for page in range(1, 9):
            row = request(client, f'artifacts-page-{page}.json', 'GET',
                f'https://api.github.com/repos/leonardosovienski/cripto-predictor/actions/artifacts?per_page=100&page={page}',
                headers={'Accept': 'application/vnd.github+json'})
            if row.get('status') != 200:
                break
            values = row.get('response', {}).get('artifacts', [])
            artifacts.extend(values)
            if len(values) < 100:
                complete = True
                break
        save('artifact-inventory.json', {'at':now(), 'listing_complete':complete,
            'count':len(artifacts), 'artifacts':artifacts})
        print(json.dumps({'artifact_count':len(artifacts), 'listing_complete':complete}), flush=True)
