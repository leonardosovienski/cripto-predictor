import json
import re
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
S = R/'remaining_six_20260910'
P = Path(r'C:\Cripto\pesquisa-20260909')


def save(name, value):
    with (S/name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)


def status(name, command):
    run = subprocess.run(command, cwd=P, capture_output=True, text=True, encoding='utf-8')
    assert run.returncode == 0, name
    obj = json.loads(run.stdout)
    save(name, obj)
    return obj


carry = status('carry_status.json', [sys.executable, '-m', 'scripts.carry_forward_registration', '--directory',
    r'C:\Cripto\operacao\dados\carry-manual-20260912-v2'])
llm = status('llm_status.json', [sys.executable, str(R/'work/isolated_python.py'), '-m', 'scripts.paired_llm', '--directory',
    r'C:\Cripto\operacao\dados\llm-paired-manual-20260912-v3'])
second = status('aave_status.json', [sys.executable, str(R/'work/compare_aave_second_source.py')])
save('access_check.json', {
    'checked_at': datetime.now(UTC).isoformat(),
    'opera_connector': 'UNAUTHORIZED: reauthentication required; tab list unavailable',
    'available_cua_surfaces': 'Only Codex in-app browser; initial inventory had one GitHub documentation tab',
    'provider_dashboard_examined': False,
    'scope_limit': 'Not a claim that the owner lacks accounts or sessions elsewhere',
    'documentation_browser_failure': 'blockreq.com timed out in in-app browser; public endpoint docs available through web search',
    'owner_instruction': 'Keep current keys; working keys are not to be revoked as a prerequisite',
    'credential_changes': 0, 'financial_credentials_used': False,
    'historical_revocation_evidence': 'Not verified; nonblocking historical information',
    'historical_usage_exact': 'Not reconstructed; administrative reservation is not measured use',
})
save('historical_recovery_routes.json', {
    'at': datetime.now(UTC).isoformat(), 'acquisition_this_round': False,
    'h5': {'state': 'ORIGINAL_INPUTS_NOT_RECOVERED',
        'required': ['Original prediction/response', 'Exact prompt/model/settings', 'Market input and source identity',
                     'News input and then-available publication version', 'Prediction timestamps and integrity evidence'],
        'scope': 'Previous local/Git/artifact searches preserved; Sep10 preflight is not old H5',
        'new_independent_action': 'No identical full-disk rescan; no additional backup or authenticated source identified'},
    'macro': {'state': 'DOCUMENTED_ROUTE_NOT_DOWNLOADED_OR_VALIDATED',
        'series': 'DTWEXBGS; nominal broad USD index, not ICE DXY',
        'official_series': 'https://alfred.stlouisfed.org/series?seid=DTWEXBGS',
        'official_download_contract': 'https://alfred.stlouisfed.org/help/downloaddata',
        'scope_for_next_acquisition': 'One series, observation interval 2024-01-01 to 2026-09-09; real-time periods with original README and vintage list; at most 200 selected vintages, two downloads, 20MB total, zero retries, one shared ingestion unit',
        'temporal_acceptance': 'Preserve observation_date, value, realtime_start_date, realtime_end_date and receipt time separately. Prove release timezone/hour or conservatively delay past the full possible release day. Original intraday availability remains unknown without stronger evidence.',
        'method_acceptance': 'No initial-release or current-value substitution under an unchanged feature version; no economic claim until downstream temporal contract and exact intended vintage are validated',
        'bcb_route': 'https://www.bcb.gov.br/controleinflacao/comunicadoscopom',
        'bcb_limit': 'Copom communications can support policy-target decisions. They do not replace realized Selic/IPCA/FX series or certify their vintages.',
        'news_limit': 'An article date alone does not recover original H5 article text, historical revision, ingestion or LLM answer'},
    'aave': {'state': 'IMPLEMENTED_OFFLINE_VERIFIED_WAITING_QUOTA',
        'source_docs': 'https://blockreq.com/docs/build/public-endpoints/',
        'public_endpoint': 'https://arbitrum-one-rpc.blockreq.com/v1/rpc/public',
        'prepared_protocol': str(S/'aave_second_source/protocol.json'),
        'independence_limit': 'Separate operator/endpoint is not proof of different upstream archive nodes; upstream provenance remains to be established'},
    'costs': {'state': 'PERSONAL_EVIDENCE_NOT_PROVIDED_OR_IDENTIFIED',
        'available': 'Funded-capital, execution-cost, additional-cost, conversion and break-even scenarios already computed in section 15',
        'required_for_personal_claim': ['Account-specific fee schedule and pair/network', 'Time, side, size, average fill, commissions and currency',
            'Cash/margin reconciliation and funding/borrow/gas/bridge/conversion records', 'Infrastructure/development allocation and applicable tax assumptions'],
        'no_substitution': 'Third-party transaction receipts and public fee tables do not prove personal fills or cost; no execution authorized'},
})
print(json.dumps({'carry': carry, 'llm': llm, 'aave': second}, ensure_ascii=False))
