"""Fast-forward the operational checkout while preserving the owner's prompt bytes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

P = Path(r'C:\Cripto\pesquisa-20260909')
W = Path(r'C:\Cripto\correcao-pr110-20260910')
R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
F = R / 'closure110'
merged = sys.argv[1]
tested = '64dbdc2b6172de054c08be9c462772fcb3336da6'
base = '909724e36d23b1683268c9e43d533f553c7dfe5f'

def git(*args, cwd=P):
    return subprocess.check_output(['git', *args], cwd=cwd)

def ref(value, cwd=P):
    return git('rev-parse', value, cwd=cwd).decode().strip()

assert ref('HEAD') == base
assert git('status', '--porcelain').decode().splitlines() == [' M docs/NEXT_CHAT_PROMPT.md']
assert ref('HEAD', W) == tested and not git('status', '--porcelain', cwd=W).strip()
git('fetch', 'origin', 'main')
assert ref('origin/main') == merged
assert ref(merged + '^{tree}') == ref(tested + '^{tree}')
assert not git('diff', '--name-only', base, merged, '--', 'GarimpoInvestimentos', 'charters', 'observation_plans', 'pyproject.toml', 'uv.lock').strip()
validation = json.loads((F / 'final02/validation.json').read_bytes())
assert validation.get('finished_at_utc') and all(x['exit_code'] == 0 for x in validation['checks'])
source_differences = [p for p, h in validation['source_hashes'].items()
                      if hashlib.sha256((W / p).read_bytes()).hexdigest() != h]
assert not source_differences
prompt = P / 'docs/NEXT_CHAT_PROMPT.md'
owner = prompt.read_bytes()
assert owner == (R / 'baseline/initial_next_chat_prompt.md').read_bytes()
incoming = git('show', merged + ':docs/NEXT_CHAT_PROMPT.md')
assert owner.replace(b'\r\n', b'\n') == incoming.replace(b'\r\n', b'\n')
with (F / 'owner_prompt_before_main_update.md').open('xb') as handle:
    handle.write(owner)
with (F / 'owner_diff_before_main_update.patch').open('xb') as handle:
    handle.write(git('diff', '--binary'))
git('restore', '--source=HEAD', '--worktree', '--', 'docs/NEXT_CHAT_PROMPT.md')
try:
    git('merge', '--ff-only', merged)
finally:
    prompt.write_bytes(owner)
assert ref('HEAD') == merged and prompt.read_bytes() == owner
record = {
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'head': ref('HEAD'), 'tree': ref('HEAD^{tree}'),
    'tested_head': tested, 'tree_matches_tested': True,
    'runtime_dependencies_and_charters_equal_PR111': True,
    'owner_prompt_preserved_byte_for_byte': True,
    'owner_prompt_text_is_now_also_in_git': True,
    'source_files_checked': len(validation['source_hashes']),
    'working_tree_status': git('status', '--short').decode().strip(),
    'local_final_suite_passed_before_merge': True,
}
(F / 'operational_update.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps(record))
