from pathlib import Path
import sys

runner = Path(r"C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\work\run_checks.py")
sys.argv = [str(runner), "manual_final02"]
source = runner.read_text(encoding="utf-8")
# The intermediate full run measures runtime coverage; final code differs only
# in the separate registration script. Run all final tests without instrumenting
# them again; CI all-extras still measures coverage on the final commit.
prefix = source.split('check("tests", [CMD, "python", "-u", "-m", "coverage"')[0]
exec(compile(prefix, str(runner), "exec"))
check("tests", [CMD, "python", "-u", "-m", "pytest", "-q", "-ra", "--basetemp", str(TEMP / "pytest"), "--junitxml", str(RUN / "tests.xml")])
check("windows_status", [CMD, "status"])
check("windows_help", [CMD, "pipeline", "--help"])
check("wheel_contract", [CMD, "python", str(REVIEW / "work/wheel_check.py"), PHASE])
contract = json.loads((RUN / "wheel_contract.json").read_bytes())
state["wheel_inner_checks_passed"] = all(c["exit_code"] == 0 for c in contract["checks"]) and not contract["prohibited_members"]
state["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
save()
raise SystemExit(any(c["exit_code"] != 0 for c in state["checks"]) or not state["wheel_inner_checks_passed"])
