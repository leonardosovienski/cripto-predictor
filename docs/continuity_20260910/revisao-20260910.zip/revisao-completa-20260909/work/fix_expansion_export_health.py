from pathlib import Path
P=Path(r'C:\Cripto\auditoria-ampliada-20260910')
def edit(name,old,new):
    p=P/name;s=p.read_text(encoding='utf-8');assert old in s,(name,old[:60]);p.write_text(s.replace(old,new),encoding='utf-8')
c='GarimpoInvestimentos/feature_store_health.py'
edit(c,'    if not path.exists():','    if max_age < timedelta(0):\n        raise ValueError("max_age must not be negative")\n    if not path.exists():')
edit(c,'sqlite3.connect(f"file:{path}?mode=ro", uri=True)', 'sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)')
edit(c,'    latest = datetime.fromisoformat(str(row[0]).replace("Z", "+00:00"))','    try:\n        latest = datetime.fromisoformat(str(row[0]).replace("Z", "+00:00"))\n    except ValueError:\n        return StoreHealth(StoreState.CORRUPT)')
edit(c,'    state = StoreState.STALE if now.astimezone(UTC) - latest > max_age else StoreState.READY','    if latest > now.astimezone(UTC):\n        return StoreHealth(StoreState.CORRUPT, latest)\n    state = StoreState.STALE if now.astimezone(UTC) - latest > max_age else StoreState.READY')
c='GarimpoInvestimentos/output/reporter.py'
edit(c,'import logging\n','import logging\nimport io\nimport uuid\n')
edit(c,'from GarimpoInvestimentos.core.paths import OUTPUT_DIR','from GarimpoInvestimentos.core.paths import OUTPUT_DIR\nfrom GarimpoInvestimentos.durable_io import atomic_write')
edit(c,'def export_results(resultados: list[dict]):','''def _literal(value: str) -> str:
    # CSV/XLSX viewers must treat provider/LLM text as text, never a formula.
    value = str(value)
    return "'" + value if value.lstrip().startswith(("=","+","-","@")) or value.startswith(("\\t","\\r","\\n")) else value


def export_results(resultados: list[dict]):''')
edit(c,'timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")','timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f") + "_" + uuid.uuid4().hex[:8]\n    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)')
# Keep existing DictWriter/worksheet logic; buffer writes until encoding succeeds.
edit(c,'    with open(csv_filename, mode="w", newline="", encoding="utf-8-sig") as csvfile:', '    with io.StringIO(newline="") as csvfile:')
edit(c,'    # XLSX\n','        csv_bytes = csvfile.getvalue().encode("utf-8-sig")\n\n    # XLSX\n')
for old in ('r.get("ativo", "").upper()','r.get("sentimento", "")','r.get("resumo", "")','r.get("data", "")'):
    edit(c,old,'_literal('+old+')')
edit(c,'    wb.save(xlsx_filename)','    stream = io.BytesIO()\n    wb.save(stream)\n    from pathlib import Path\n    atomic_write(Path(xlsx_filename), stream.getvalue())\n    atomic_write(Path(csv_filename), csv_bytes)')

# Clock/DB errors become FAILED health reports, not uncaught exceptions or writes.
for c in ('GarimpoInvestimentos/phase1_watchdog.py','GarimpoInvestimentos/observation_watchdog.py'):
    p=P/c;s=p.read_text(encoding='utf-8')
    if 'phase1_' in c:
        start=s.index('        with closing(sqlite3.connect')
        end=s.index('\n    if violations:',start)
        body=s[start:end]
        s=s[:start]+'        try:\n'+''.join('    '+line+'\n' if line else '\n' for line in body.splitlines()).rstrip('\n')+'\n        except (sqlite3.DatabaseError, ValueError, TypeError):\n            violations.append("feature_store_unreadable_or_invalid_timestamp")\n'+s[end:]
    else:
        start=s.index('        with closing(sqlite3.connect')
        end=s.index('\n    else:\n        violations.append("feature_store_missing")',start)
        body=s[start:end]
        s=s[:start]+'        try:\n'+''.join('    '+line+'\n' if line else '\n' for line in body.splitlines()).rstrip('\n')+'\n        except sqlite3.DatabaseError:\n            violations.append("feature_store_unreadable")\n'+s[end:]
        s=s.replace('    violations: list[str] = []', '    violations: list[str] = []\n    if state_root is None and not configured:\n        violations.append("state_root_not_configured")')
    p.write_text(s,encoding='utf-8')
