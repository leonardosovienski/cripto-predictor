import ast
import hashlib
import json
import re
import subprocess
from datetime import UTC, datetime
from pathlib import Path

from GarimpoInvestimentos.security.redaction import configured_secret_values
from GarimpoInvestimentos.dpl.snapshots import encode
import recover_operational_snapshot as snapshot

P = Path(r'C:\Cripto\publicacao-conferencia-20260910')
R = snapshot.R
E = P/'docs/evidence/remaining_dependencies_20260910'
L = R/'publication_chat_20260910'
manifest = json.loads((E/'manifest.json').read_bytes())
files = {p.relative_to(E).as_posix(): p for p in E.rglob('*') if p.is_file() and p.name != 'manifest.json'}
assert set(files) == set(manifest['files'])
for name, path in files.items():
    assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['files'][name], name
    assert not path.is_symlink()
    if path.suffix == '.json':
        json.loads(path.read_bytes())
    if path.suffix == '.source':
        ast.parse(path.read_text(encoding='utf-8'))
for name, local in manifest['copied_from_local'].items():
    assert files[name].read_bytes() == Path(local).read_bytes(), name
payload = json.loads((E/'snapshot/payload.json').read_bytes())
applied = json.loads((E/'snapshot/applied.json').read_bytes())
prepared = json.loads((E/'snapshot/prepared.json').read_bytes())
assert encode(payload)[0] == applied['snapshot_id'] == prepared['snapshot_id']
assert payload['offline_derivation']['source_sha256'] == hashlib.sha256((E/'original_receipts/sources/5714523b98c7451c92a841681049a657.json').read_bytes()).hexdigest()
assert payload['offline_derivation']['manifest_sha256'] == hashlib.sha256((E/'original_receipts/result.json').read_bytes()).hexdigest()
assert snapshot.state(snapshot.DB, applied['snapshot_id']) == prepared['before']
assert snapshot.state(snapshot.BUDGET) == prepared['budget_before']
runtime_diff = subprocess.check_output(['git', 'diff', 'origin/main', '--', 'GarimpoInvestimentos', 'scripts', 'tests', 'conftest.py', 'charters', 'pyproject.toml', 'uv.lock', '.github'], cwd=P)
assert not runtime_diff
assert snapshot.sha(snapshot.P/'docs/NEXT_CHAT_PROMPT.md') == '8969db38ef9a3ec29ee16a780b9572ec9f7d7808cabc9bac17a319616b47fe20'
raw = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'], cwd=P).decode('utf-8')
names = [n for n in raw.split('\0') if n]
changes = subprocess.check_output(['git','diff','--name-only','origin/main'], cwd=P).decode().splitlines()
changes += [n for n in names if n.startswith('docs/evidence/remaining_dependencies_20260910/') or n == 'docs/CONFERENCIA_CHAT_20260910.md']
changes = sorted(set(changes))
secrets = [s.encode() for s in configured_secret_values() if len(s) >= 8]
assert secrets
for name in changes:
    data = (P/name).read_bytes()
    assert not any(value in data for value in secrets), 'Configured secret found in publication: '+name
    assert not name.endswith(('.db','.sqlite','.db-wal','.db-shm','.env'))
docs = ['docs/CONFERENCIA_CHAT_20260910.md','docs/README.md','docs/REVISAO_COMPLETA_20260909.md',
        'docs/AUDITORIA_AMPLIADA_20260910.md','docs/manual_dependencies_20260910/EXECUCAO.md',
        'docs/evidence/remaining_dependencies_20260910/README.md']
links_checked = 0
for name in docs:
    p=P/name
    for link in re.findall(r'\[[^\]]+\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
        if link.startswith(('https://','http://','#')):
            continue
        target=link.split('#')[0]
        resolved = Path(target) if Path(target).is_absolute() else p.parent/target
        assert resolved.exists(), (name, target)
        links_checked += 1
record={'at':datetime.now(UTC).isoformat(),'status':'PASS','base':manifest['base_head'],
        'manifest_files_verified':len(files),'publishable_changed_files':len(changes),
        'configured_secret_matches':0,'local_document_links_verified':links_checked,
        'runtime_tests_dependencies_ci_unchanged':True,'budget_unchanged':True,'previous_database_rows_preserved':True,
        'owner_prompt_preserved':True,'network_calls':0}
(L/'artifact_validation.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(record))
