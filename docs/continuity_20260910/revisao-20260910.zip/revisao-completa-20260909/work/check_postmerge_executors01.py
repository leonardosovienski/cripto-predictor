from pathlib import Path
import sys
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
runner=R/'work/run_checks.py'
sys.argv=[str(runner),'postmerge_executors01']
source=runner.read_text(encoding='utf-8').split('if PHASE.startswith("postmerge"):')[0]
exec(compile(source,str(runner),'exec'))
ENV.update({key:'1' for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS')})
state['numerical_thread_limits']={key:ENV[key] for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS')}
save()
check('sync_all_extras',[CMD,'uv','sync','--frozen','--all-extras'])
check('tests',[CMD,'python','-u','-m','pytest','-q','-ra','--basetemp',str(TEMP/'pytest'),'--junitxml',str(RUN/'tests.xml')])
state['finished_at_utc']=datetime.now(timezone.utc).isoformat()
save()
raise SystemExit(any(c['exit_code'] for c in state['checks']))