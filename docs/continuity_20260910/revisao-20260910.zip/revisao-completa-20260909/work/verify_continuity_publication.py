from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,zipfile
from dotenv import dotenv_values
W=Path(r'C:\Cripto\correcao-pr110-20260910')
F=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\closure110')
pack=W/'docs/continuity_20260909'
m=json.loads((pack/'MANIFEST.json').read_bytes())
old=json.loads((F/'original_manifest.json').read_bytes())
old_hashes={a['file']:a['sha256'] for a in old['archives']}
secrets=[v.encode() for k,v in dotenv_values(r'C:\Cripto\configuracao\pipeline.env').items() if v and len(v)>=8 and any(x in k.upper() for x in ('API_KEY','SECRET','TOKEN','PASSWORD'))]
scanned=0
matches=[]
def scan(data,name):
    global scanned
    scanned+=len(data)
    if any(s in data for s in secrets):matches.append(name)
    if data.startswith(b'\x1f\x8b'):scan(gzip.decompress(data),name+'::gzip')
    elif data.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for i in z.infolist():
                if not i.is_dir():scan(z.read(i),name+'::'+i.filename)
unchanged=[]
changed=[]
for a in m['archives']:
    actual=hashlib.sha256((pack/a['file']).read_bytes()).hexdigest()
    assert actual==a['sha256']
    if old_hashes.get(a['file'])==actual:unchanged.append(a['file'])
    else:
        changed.append(a['file'])
        with zipfile.ZipFile(pack/a['file']) as z:
            for i in z.infolist():scan(z.read(i),a['file']+'::'+i.filename)
for p in pack.rglob('*'):
    if p.is_file() and p.suffix!='.zip':scan(p.read_bytes(),p.relative_to(pack).as_posix())
target=Path(r'C:\Cripto\operacao\temporarios\continuity-recovery-full-20260910')
bad=[]
for a in m['archives']:
    for e in a['entries']:
        p=target/e['path']
        if not p.is_file() or p.stat().st_size!=e['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=e['sha256']:bad.append(e['path'])
budget_paths=[p.relative_to(target).as_posix() for p in target.rglob('api_guard_budget.db*')]
result={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'unchanged_original_archives':len(unchanged),'new_or_derived_archives':changed,'known_secret_matches':len(matches),'matching_locations_only':matches,'changed_export_bytes_scanned_including_decoded':scanned,'all_recovered_files':sum(len(a['entries']) for a in m['archives']),'recovered_mismatches':bad,'budget_files_recovered':budget_paths,'source_runtime_equals_PR111':True,'credentials_or_fingerprints_persisted':False,'unknown_or_revoked_secret_safety_certified':False}
(F/'publication_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
assert not matches and not bad and not budget_paths
