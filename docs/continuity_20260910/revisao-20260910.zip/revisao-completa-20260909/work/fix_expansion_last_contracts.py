from pathlib import Path
P=Path(r'C:\Cripto\auditoria-ampliada-20260910')
def edit(name,old,new):
    p=P/name;s=p.read_text(encoding='utf-8');assert old in s,(name,old[:60]);p.write_text(s.replace(old,new),encoding='utf-8')
edit('tests/test_api_guard.py','    provider._cache[30] = points','    provider._cache[30] = (__import__("time").monotonic(), tuple(points))')
edit('tests/test_trading_signal_adapter.py','    return to_trade_intent(sinal or FakeSignal(), **kw)','''    # Synthetic calibration only for testing the adapter's contract wiring.
    # The real default is covered separately and must refuse uncalibrated costs.
    from unittest.mock import patch
    with patch("GarimpoInvestimentos.trading.cost_policy.CALIBRATED_FOR_VERDICT", {"crypto_perp"}):
        return to_trade_intent(sinal or FakeSignal(), **kw)''')
p=P/'tests/test_trading_signal_adapter.py'
s=p.read_text(encoding='utf-8')+'''

def test_real_adapter_default_rejects_uncalibrated_execution():
    from GarimpoInvestimentos.trading.cost_policy import UncalibratedCostModel
    with pytest.raises(UncalibratedCostModel):
        to_trade_intent(FakeSignal(), family="synthetic-open-family", trial_id="synthetic", pipeline_fingerprint="synthetic", instrument=INSTRUMENTO, holding_period_hours=24)
'''
p.write_text(s,encoding='utf-8')
c='GarimpoInvestimentos/trading/signal_adapter.py'
block='''    # Uma intenção executável só nasce de modelo calibrado para veredito. Isso
    # torna impossível esquecer o guard e carregar custo apenas "por convenção".
    cost_model = cost_model_for(instrument, for_verdict=True)

'''
edit(c,block,'')
edit(c,'    gerado_em = datetime.fromtimestamp',block+'    gerado_em = datetime.fromtimestamp')
edit('GarimpoInvestimentos/config.py','        extra="ignore",','        extra="ignore",\n        allow_inf_nan=False,')
edit('GarimpoInvestimentos/config.py','        if self.LLM_ENSEMBLE_N < 1:', '        if self.LLM_PACING_SECONDS < 0 or self.CACHE_TTL_HOURS <= 0 or self.SCORE_HORIZON_DAYS <= 0:\n            raise ValueError("pacing must be nonnegative; TTL/horizon must be positive")\n        if self.LLM_ENSEMBLE_N < 1:')
edit('GarimpoInvestimentos/dpl/feature_engineering.py','DAILY_FEATURE_VERSION = "daily-v3-contiguous"','DAILY_FEATURE_VERSION = "daily-v4-audited"')

c='GarimpoInvestimentos/analyzers/ai_insights.py'
edit(c,'def _retry_delay_for_error(','''def _bounded_retry_delay(value: float) -> float | None:
    # A malformed or very long server delay must not hang a bounded API call.
    # Decline the retry rather than ignore a long Retry-After and call too soon.
    return max(0.0,value) if math.isfinite(value) and value <= 300 else None


def _retry_delay_for_error(''')
edit(c,'return float(retry_after)','return _bounded_retry_delay(float(retry_after))')
edit(c,'return max(0.0, float(retry_delay))','return _bounded_retry_delay(float(retry_delay))')
edit(c,'return max(0.0, float(value[:-1]))','return _bounded_retry_delay(float(value[:-1]))')
edit(c,'return max(0.0, float(value[:-1]) * 60.0)','return _bounded_retry_delay(float(value[:-1]) * 60.0)')

c='GarimpoInvestimentos/plugin.py'
edit(c,'from GarimpoInvestimentos.core.paths import FEATURE_STORE_DB','from GarimpoInvestimentos.core.paths import FEATURE_STORE_DB\nfrom GarimpoInvestimentos.governance import load_scientific_state')
edit(c,'        return {\n            "domain": "crypto",','''        state = load_scientific_state()
        active = sorted(name for name,status in state.hypotheses.items() if str(status) == "COLLECTION_ONLY_IMMATURE")
        return {
            "domain": "crypto",''')
edit(c,'"scientific_status": "ACTIVE_HYPOTHESIS"','"scientific_status": "ACTIVE_HYPOTHESIS" if active else "NO_ACTIVE_HYPOTHESIS"')
edit(c,'"mode": "PROSPECTIVE_OBSERVATION",\n                "active_hypothesis": "H6",','"mode": "RESEARCH_ONLY",\n                "active_hypothesis": active[0] if len(active) == 1 else None,\n                "hypotheses": {name: str(status) for name,status in state.hypotheses.items()},')
edit(c,'"source_of_scientific_truth": "README.md"','"source_of_scientific_truth": "charters/scientific_state.json"')

(P/'tests/test_audit_persistence_safety.py').write_bytes(Path(__file__).with_name('test_expansion_persistence_safety.py').read_bytes())
