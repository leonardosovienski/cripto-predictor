from pathlib import Path
P=Path(r'C:\Cripto\auditoria-ampliada-20260910')
p=P/'GarimpoInvestimentos/observation_quality.py'
s=p.read_text(encoding='utf-8').replace('    source_quality_scorecard,\n','').replace('from predictor_core.obs import emit_event','from predictor_core.obs import emit_event\nfrom GarimpoInvestimentos.quality_scorecard import audited_source_quality_scorecard\nfrom GarimpoInvestimentos.durable_io import atomic_write, file_lock')
s=s.replace('instrument: source_quality_scorecard(', 'instrument: audited_source_quality_scorecard(')
s=s.replace('(point.ingested_at - point.published_at).total_seconds() * 1000', '(point.ingested_at - (point.event_at if "available_at_receipt" in point.quality_flags else point.published_at)).total_seconds() * 1000')
s=s.replace('        "divergence": 0.0,', '        "divergence": None,  # No independent reference observations were supplied.')
start=s.index('    if path.exists():\n',s.index('def _append_audit'))
end=s.index('\n\ndef _json_safe',start)
s=s[:start]+'''    with file_lock(path):
        history = path.read_text(encoding="utf-8") if path.exists() else ""
        found = False
        for line in history.splitlines():
            existing = json.loads(line)
            actual = hashlib.sha256(json.dumps(existing["payload"], ensure_ascii=False, sort_keys=True, allow_nan=False).encode("utf-8")).hexdigest()
            if existing["payload_hash"] != actual:
                raise ValueError("corrupt JSONL scorecard hash")
            if existing["audit_key"] == payload["audit_key"]:
                if existing["payload_hash"] != digest:
                    raise ValueError("immutable JSONL scorecard exists with other content")
                found = True
        if found:
            return False
        record = {"audit_key": payload["audit_key"], "payload_hash": digest, "payload": payload}
        atomic_write(path, (history.rstrip("\\n") + ("\\n" if history else "") + json.dumps(record, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\\n").encode("utf-8"))
    return True
'''+s[end:]
p.write_text(s,encoding='utf-8')
p=P/'tests/test_paper_idempotency.py'
s=p.read_text(encoding='utf-8').replace('        assert paper_trader._already_recorded("BTCUSDT", 500) is True','        with pytest.raises(ValueError):\n            paper_trader._already_recorded("BTCUSDT", 500)')
p.write_text(s,encoding='utf-8')
p=P/'tests/test_dpl_stocks.py'
s=p.read_text(encoding='utf-8').replace('datetime(2026, 4, 11, tzinfo=UTC)  # ref + 11 dias', 'datetime(2026, 4, 12, tzinfo=UTC)  # observed vintage, not assumed lag')
p.write_text(s,encoding='utf-8')
p=P/'tests/test_dpl_macro_calendar.py'
s=p.read_text(encoding='utf-8').replace('test_published_at_equals_timestamp_conservatively','test_published_at_equals_observed_vintage').replace('all(p.published_at == p.timestamp for p in points)','all(p.published_at == ingested_at for p in points)')
p.write_text(s,encoding='utf-8')
