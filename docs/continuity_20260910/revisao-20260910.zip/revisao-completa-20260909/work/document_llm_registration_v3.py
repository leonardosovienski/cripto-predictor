from pathlib import Path
import json
import hashlib

P=Path(r'C:\Cripto\auditoria-ampliada-20260910')
D=Path(r'C:\Cripto\operacao\dados')
old=D/'llm-paired-manual-20260912-v2'
new=D/'llm-paired-manual-20260912-v3'
assert (old/'protocol.json').read_bytes()==(new/'protocol.json').read_bytes()
assert not list(old.glob('*.jsonl')) and not list(new.glob('*.jsonl'))
before=json.loads((old/'registration.json').read_bytes())
after=json.loads((new/'registration.json').read_bytes())
changed=[p for p,h in before['files'].items() if after['files'][p]!=h]
assert set(changed)=={'GarimpoInvestimentos/config.py','GarimpoInvestimentos/core/api_guard.py','GarimpoInvestimentos/local_runtime.py'}
assert (P/'GarimpoInvestimentos/local_runtime.py').read_bytes().replace(b'\r\n',b'\n')==Path(r'C:\Cripto\pesquisa-20260909\GarimpoInvestimentos\local_runtime.py').read_bytes().replace(b'\r\n',b'\n')
assert before['environment']==after['environment']
target=P/'docs/manual_dependencies_20260910/llm_audit_registration_v3.json'
with target.open('xb') as stream:
    stream.write((new/'registration.json').read_bytes())
doc=P/'docs/manual_dependencies_20260910/EXECUCAO.md'
text=doc.read_text(encoding='utf-8').replace('llm-paired-manual-20260912-v2','llm-paired-manual-20260912-v3')
text=text.replace('C:\\Cripto\\CRIPTO.cmd python -m scripts.paired_llm',r'C:\Cripto\CRIPTO.cmd python C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\work\isolated_python.py -m scripts.paired_llm')
text=text.replace('[congelamento](../evidence/dependency_execution_20260910/llm_registration.json)','[congelamento atual](llm_audit_registration_v3.json)')
lines=text.splitlines()
lines[1:1]=['','**Errata da auditoria ampliada de 10/09:** o registro LLM atual é `llm-paired-manual-20260912-v3`. A versão v2 ficou preservada, sem observações, e recusa corretamente as mudanças em `config.py` e `core/api_guard.py`. O novo registro mantém protocolo, datas e ambiente, vincula o código corrigido antes da coleta e passou no status offline com 84 horários futuros. Os registros antigos não tiveram hashes alterados. Carry permanece no registro v2.','',r'**Executor vinculado ao registro:** os comandos LLM abaixo usam explicitamente `C:\Cripto\auditoria-ampliada-20260910` por meio do lançador `work\isolated_python.py` do relatório. Preserve essa área e seus bytes. `local_runtime.py` também difere no hash por LF/CRLF, embora seu conteúdo lógico seja igual; usar o checkout operacional diretamente não satisfaz esse congelamento. O ambiente Python continua em `C:\Cripto\pesquisa-20260909\.venv`. O carregador verifica código e ambiente antes de qualquer coleta.']
doc.write_text('\n'.join(lines)+'\n',encoding='utf-8')
doc=P/'docs/AUDITORIA_AMPLIADA_20260910.md'
text=doc.read_text(encoding='utf-8')
text=text.replace('## Dependências restantes e critério de encerramento','## Registros futuros conferidos após a correção\n\nO status offline do carry confirmou `WAITING`, zero linhas e nenhuma entrada. O registro LLM v2 recusou corretamente as mudanças em configuração e guarda de API. Foi preparado `C:\\Cripto\\operacao\\dados\\llm-paired-manual-20260912-v3`, preservando v2 sem observações. Protocolo, datas e ambiente são iguais. Mudam os hashes dos dois arquivos corrigidos, a data de registro e o hash de `local_runtime.py` por LF/CRLF, sem mudança lógica nesse último. O executor está vinculado aos bytes de `C:\\Cripto\\auditoria-ampliada-20260910`; preserve essa área e use o lançador explícito documentado, não o checkout operacional diretamente. O status v3 confirmou 84 horários futuros, sem diário, rede ou ativação. O [registro público novo](manual_dependencies_20260910/llm_audit_registration_v3.json) e os [comandos atualizados](manual_dependencies_20260910/EXECUCAO.md) são a referência de retomada.\n\n## Dependências restantes e critério de encerramento')
doc.write_text(text,encoding='utf-8')
print(json.dumps({'changed_registered_files':changed,'same_protocol':True,'same_environment':True,'old_preserved':True,'new_registration_sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
