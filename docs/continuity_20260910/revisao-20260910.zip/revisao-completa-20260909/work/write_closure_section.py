from datetime import UTC, datetime
import json
from pathlib import Path
import re

R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
report = R / 'REVISAO.md'
original = report.read_text(encoding='utf-8')
backup = R / 'closure_audit/report_before_closure.md'
if not backup.exists():
    backup.write_bytes(report.read_bytes())
integration_path = R / 'closure_audit/integration.json'
integration = json.loads(integration_path.read_bytes()) if integration_path.exists() else {}
status = integration.get('summary', 'PR #116 integrado em ac4184e; 1.505 testes Windows aprovados antes e após o merge, com um skip e zero falhas. CI do PR aprovado; job de container do main ainda pendente, demais jobs aprovados.')
text = original.split('\n## 17. ')[0].rstrip()
text = re.sub(r'Atualização: [^.]+(?:\.\d+)?\+00:00\.', 'Atualização: ' + datetime.now(UTC).isoformat() + '.', text, count=1)
text = re.sub(r'\*\*Integração: \[PR #114\].*?\*\* Engenharia', '**Integração atual: ver seção 17; #110–#115 permanecem documentados como etapas datadas.** Engenharia', text, count=1)
text = re.sub(r'\*\*Etapa atual:.*?\*\* As seções anteriores', '**Etapa atual: conferência de encerramento na seção 17. ' + status + '** As seções anteriores', text, count=1)
text = text.replace('As seções anteriores preservam resultados datados das etapas #110–#114;', 'As seções anteriores preservam resultados datados das etapas #110–#115;')
text = text.replace('| Aave | RPC público Arbitrum, USDC nativo e reserva fixos | Sem liquidityIndex histórico e liquidez nas 13 fronteiras; nenhuma estimativa | aave_1rpc/ e sondas anteriores → H1 da rodada econômica (não H1/V3) |', '| Aave | RPC público Arbitrum, USDC nativo e reserva fixos | 13 fronteiras originais e 25 fronteiras da extensão recuperadas; índices/liquidez/identidade conferidos. Fonte RPC única, custos de cenário; seções 14–15 | Novas evidências Aave vinculadas nas seções 14–15; aave_1rpc/ preserva a tentativa anterior malsucedida |')
for before, after in (
    ('| corrigida a promoção indevida |', '| contradita |'),
    ('| explicadas no escopo auditado |', '| parcialmente comprovada |'),
    ('| dados recuperados e contas reconciliadas |', '| desatualizada |'),
    ('| estado original desatualizado |', '| desatualizada |'),
    ('| lucro realizado não demonstrado |', '| não verificada |'),
):
    text = text.replace(before, after)
text = '\n'.join(
    line.replace('| comprovada no escopo testado |', '| contradita |') if line.startswith('| C11 |')
    else line.replace('Aave sem dados = ruim/bom', 'Estado histórico Aave ausente, repasse 09/09') if line.startswith('| C17 |')
    else line for line in text.splitlines()
)
section = r'''

## 17. Conferência do pedido inteiro e encerramento verificável

STATUS_REPLACE

**Resposta ao pedido:** a revisão e as correções demonstradas têm evidência, mas o objetivo total não está certificado. A ausência de toda falha possível, leitura manual universal, completude de todo histórico e lucro executável validado não foram demonstrados. Isso não deve ser confundido com os testes técnicos aprovados. Esta conferência encontrou e corrigiu uma pendência adicional de isolamento dos testes; não se limitou a repetir a conclusão anterior.

Foram relidos AGENTS, os 16 itens de NEXT_CHAT_PROMPT, o mandato original, a configuração local, a política de merge, os registros canônicos e as mensagens desta conversa. A recuperação do histórico local identificou os 13 pedidos/respostas textuais do dono até este pedido, os pareceres finais e as mensagens de andamento desde 09/09 21:45 UTC. O export da ferramenta de tarefas omitia mensagens de etapas compactadas; a conferência foi completada pelo registro local da mesma conversa. Não se confundiu uma lista de arquivos com leitura de código, nem testes com prova científica.

**Lacuna confirmada F11/P1 — isolamento dos testes.** Os runners completos anteriores removiam credenciais e redirecionavam saídas; `tests/conftest.py`, porém, usava `setdefault` e não isolava configuração, dados, cache e estado em uma chamada direta. Um subprocesso com sentinelas sintéticas demonstrou herança da credencial e escrita no diretório fictício do operador. Solução: diretório exclusivo antes dos imports, dotenv sintético, substituição das credenciais obrigatórias e remoção de credenciais opcionais herdadas. Aceite: a mesma escrita deve ocorrer fora do diretório do operador, que permanece intacto. [Reprodução anterior](closure_before01/status.json), [resultado anterior](closure_before01/tests.log), [regressões direcionadas](closure_after01/status.json): uma falha antes; 24 aprovações e um skip Windows depois. Os logs registram a árvore modificada; a suíte completa e a integração têm comprovantes próprios. A mudança afeta a infraestrutura de testes, sem reabrir protocolos ou alterar o runtime congelado.

**Lacuna documental F12/P2 — estado atual contraditório.** O cabeçalho ainda nomeava #114 como integração atual e uma linha de inventário dizia que os 13 pontos Aave estavam ausentes, apesar das seções 14–16 documentarem recuperação e #115. Essas linhas foram corrigidas. A matriz de afirmações voltou a usar os estados exigidos pelo repasse. A prontidão do código foi separada da disponibilidade do snapshot operacional atual. Critério de aceite: cabeçalho, inventário, matriz e seção de fechamento não contradizem seus comprovantes; versões históricas anteriores permanecem preservadas.

| Item do primeiro repasse | Verificação e cumprimento | Limite restante |
|---|---|---|
| 1. Objetivo e escopo | Fluxos, afirmações e economia confrontados; seções 1, 5–9, 14–16 | Lucro pessoal/futuro validado não atingido |
| 2. Local e preservação | Trabalho individual em C:\Cripto; prompt, congelados e capital=false preservados | Proteção administrativa da branch excluída pelo dono |
| 3. Estado real e baseline | Baselines anteriores às alterações, hashes e validação pós-merge registrados; remoto a917927 confirmado nesta retomada | Baseline não prova validade econômica |
| 4. Fontes e quotas | Configuração, endpoints exercitados, falhas 402 e incidente de quota discriminados | Reserva do dia 10/09 UTC; consumo anterior exato não recuperado |
| 5. Dados alegados | Reconstruções, gaps, pilotos, H5 e Aave confrontados; estado antigo corrigido | H5 original e snapshot atual pendentes |
| 6. Cobertura | Leitura direta/amostragem/inventário separados nas seções 4 e 16 | Nem cada documento/modelo histórico nem bibliotecas externas foram lidos integralmente |
| 7. Afirmações e premissas | Matrizes nas seções 6–7; causalidade, custos, ausência de trades e score tratados | Afirmações sem evidência não recebem aprovação |
| 8. Arquitetura | Ramos e consumidores reais mapeados; manter/simplificar/retirar justificados na seção 5; contratos corrigidos na 16 | Trading continua simulação; HMM/LLM sem contribuição financeira independente comprovada |
| 9. Fontes, datas e recuperação | Brutos/derivados, identidade, unidades, publicação/recebimento, exclusões e recuperação documentados | Vintages macro/notícias, H5 e segunda fonte Aave ausentes; recortes externos não certificados |
| 10. Modelos e LLM | Leakage, treino/cache, score e executor/avaliador pareados corrigidos | Amostra prospectiva e ablação econômica ainda não formadas |
| 11. Backtests e contas | Contas separadas, zeros explicados, execução/funding/retornos/custos corrigidos | Fills, margem e slippage pessoais não comprovados; WFA=UNVALIDATED |
| 12. Pesquisa econômica | Cenários independentes, perdas e tentativas preservados; Aave histórico condicional positivo | Não confundir pesquisa adaptativa com confirmação independente |
| 13. Técnica e segurança | Suítes/extras/estilo/tipos/build/pacote/container/Windows; F11 corrigido nesta conferência | Revogação histórica não observada; escopo da revisão não cobre toda infraestrutura externa |
| 14. Registro e execução | Registro vivo único; F01–F12, D01–D10 e condições complementares explícitas | Resumo de testes não fecha dependência de evidência |
| 15. Integração | #110–#115 concluídos e preservados; #116 com seu estado no início desta seção | Nenhum check pendente é considerado aprovado |
| 16. Entrega por finalidade | Classificação abaixo e explicação ao dono/investidor | Objetivo amplo continua parcialmente concluído |

**Arquitetura reavaliada.** O mapa da seção 5 continua representando os fluxos: DPL/store/main não formam uma cadeia de execução financeira com V3, trading e observadores. SQLite e snapshots continuam adequados ao diagnóstico local. Serviços de compatibilidade não são servidores; não se criou frontend, scheduler ou exchange autenticada para preencher checklist. O isolamento precisava estar também na entrada dos testes, e foi simplificado nesse ponto. O executor LLM v3 exige os bytes de `C:\Cripto\auditoria-ampliada-20260910` e o lançador explícito já documentado; isso é dependência concreta de reprodução, verificada offline, não portabilidade universal. Não se removeu essa área nem se reescreveu freeze por estética. Ganho global de desempenho e escala de produção não foram medidos.

| Dependência ainda aberta | Finalidade afetada/prioridade | Condição concreta de fechamento |
|---|---|---|
| Snapshot diário atual | Diagnóstico conectado agora, P1 operacional | Após 11/09 00:00 UTC (10/09 21h Brasília), ingestão normal dentro da guarda; confirmar snapshot `daily-v4-audited`, 200 barras fechadas/contínuas e frescor. O banco conserva 3 previsões/1 input/1 snapshot v3; não renomear o antigo |
| Inputs H5 originais | Reprodução exata histórica, D02/P1 | Backup autêntico de previsões, prompts, notícias/respostas e inputs. Buscas local/Git/artefatos examinadas não o encontraram; não é impossibilidade universal nem dado recriável por preço público |
| Disponibilidade histórica macro/notícias | Backtest causal confirmatório, P1 nesse uso | Valor e versão com prova de publicação/disponibilidade até cada decisão. Timestamp de observação ou recebimento atual não basta |
| Amostra futura carry/LLM | Validação independente, D04–D05/P1 | Janelas manuais registradas a partir de 12/09 e respectivos desfechos; 84 dias não existem antecipadamente. Executores e avaliadores prontos; nenhum agendamento ativo |
| Custos e execução aplicáveis | Lucro líquido pessoal executável, D06/P1 | Especificação efetiva de conta/tamanho/fees/impostos/conversão e fills/caixa/margem reconciliados sob mandato de execução próprio. Cenários com custos e equilíbrio já funcionam sem esses dados |
| Aave por fonte independente | Confirmação externa do histórico, P1 para alegação independente | Estado dos mesmos blocos/reserva/índices por outra fonte confiável; operação pública de terceiro não é ciclo pessoal pareado |
| Contabilidade antiga de chamadas e revogações | Auditoria histórica de uso, P2 | Logs/painéis autênticos dos provedores. Reserva conservadora não é consumo medido; chave nova funcionando não prova revogação da antiga |
| Cobertura fora dos recortes examinados | Nova alegação sobre esses componentes/dados, não bloqueio automático do diagnóstico | Definir componente/uso e examinar evidência correspondente; não declarar todos os anos/arquivos corretos por amostragem |

Proteções da branch permanecem fora por decisão expressa do dono. Não há pacote Python faltando demonstrado na instalação com todos os extras. Autorização ampla para pesquisar não produz acesso autenticado inexistente, dados privados desconhecidos ou observações futuras.

| Finalidade | Estado ao fechamento desta conferência |
|---|---|
| Engenharia dos caminhos examinados | Correções demonstradas e seus testes; aprovação final específica conforme estado no início desta seção |
| Diagnóstico conectado atual | Bloqueado temporariamente pela renovação do snapshot dentro da próxima quota; código testado não significa dado atual |
| Reprodução dos cenários históricos especificados | Pronta com limitações de fonte/custos/execução explicitadas; H5 exata excluída por ausência de inputs |
| Lucro futuro/pessoal ou operação financeira | Bloqueado pelas dependências de evidência acima; não autorizado para execução financeira |
| Reprodução futura manual | Preparada, com executor fixo, protocolo e janelas; observação ainda não iniciada |

Retomada da ingestão, somente na próxima quota normal: `C:\Cripto\CRIPTO.cmd pipeline --ingest --assets bitcoin`. Conferir o resultado antes de qualquer análise; a recusa por dado incompatível/antigo é esperada enquanto não houver snapshot novo. Para carry/LLM, usar os comandos de `docs/manual_dependencies_20260910/EXECUCAO.md`, preservando o executor registrado. Esses comandos são preparação manual, não tarefa em segundo plano.

[Estado real e preservação durante a conferência](closure_audit/during_validation.json). [Validação completa desta correção](closure_full01/validation.json). Os comprovantes finais do PR/main e pós-merge serão vinculados apenas quando concluídos.
'''
section = section.replace('STATUS_REPLACE', status)
if integration:
    section = section.replace('Os comprovantes finais do PR/main e pós-merge serão vinculados apenas quando concluídos.', 'Comprovações finais: [CI do PR](closure_audit/ci_pr_final.json), [CI do main](closure_audit/ci_main.json), [suíte final anterior ao merge](closure_final02/status.json), [validação local após merge](postmerge_closure01/validation.json), [comparação dos arquivos e checks finais](closure_audit/premerge.json), [wheel instalado fora do checkout](closure_full01/wheel_contract.json). A rodada closure_full01 teve 1.505 testes aprovados e um skip, mas o scanner sinalizou três valores sintéticos. Somente esses valores da fixture foram ajustados; o scanner passou sem achados e a suíte completa foi repetida no commit final, com 1.505 aprovações e um skip. Não se declarou a primeira rodada inteiramente aprovada.')
    section += '\n[Integração e comprovações finais](closure_audit/integration.json). [Estado após validação](closure_audit/after_validation.json).\n'
report.write_text(text + section, encoding='utf-8')
print(json.dumps({'sections': len(re.findall(r'^## ', text + section, re.M)), 'status': status}, ensure_ascii=False))
