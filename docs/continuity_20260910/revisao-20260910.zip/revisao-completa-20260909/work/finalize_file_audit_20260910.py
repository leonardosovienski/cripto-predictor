import hashlib
import json
import re
import sqlite3
import subprocess
import xml.etree.ElementTree as ET
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(r'C:\Cripto')
P = ROOT / 'pesquisa-20260909'
N = ROOT / 'revisao-arquivos-20260910'
R = ROOT / 'operacao/relatorios/REVISAO_COMPLETA_20260909'
F = R / 'organization_20260910'

def read(path):
    return json.loads(path.read_bytes())

def git(where, *args):
    return subprocess.check_output(['git', *args], cwd=where, text=True).strip()

pr, main = read(F / 'ci_pr.json'), read(F / 'ci_main.json')
post = read(R / 'postmerge_files01/validation.json')
assert pr['four_jobs_passed'] and main['four_jobs_passed']
head = main['head']
assert git(P, 'rev-parse', 'HEAD') == post['head'] == head == git(P, 'ls-remote', 'origin', 'refs/heads/main').split()[0]
assert git(P, 'rev-parse', 'HEAD^{tree}') == git(N, 'rev-parse', 'HEAD^{tree}')
assert post.get('finished_at_utc') and all(x['exit_code'] == 0 for x in post['checks'])
cases = ET.parse(R / 'postmerge_files01/tests.xml').getroot().findall('.//testcase')
skips = sum(c.find('skipped') is not None for c in cases)
failed = sum(c.find('failure') is not None or c.find('error') is not None for c in cases)
passed = len(cases) - skips - failed
assert (passed, skips, failed) == (1505, 1, 0)
assert read(F / 'original_files_verification.private.json')['status'] == 'PASS'
assert read(F / 'migration_archive_verification.json')['status'] == 'PASS'
assert read(F / 'frozen_runtime_validation.json')['status'] == 'PASS'
assert hashlib.sha256((P / 'docs/NEXT_CHAT_PROMPT.md').read_bytes()).hexdigest() == '8969db38ef9a3ec29ee16a780b9572ec9f7d7808cabc9bac17a319616b47fe20'
W = ROOT / 'auditoria-ampliada-20260910'
assert git(W, 'rev-parse', 'HEAD') == '595f1203475d04b01966ac3471bbafd6770dbb4d' and not git(W, 'status', '--porcelain')
E = P / 'docs/evidence/file_document_audit_20260910'
manifest = read(E / 'manifest.json')
for name, digest in manifest['files'].items():
    relative = (E / name).relative_to(P).as_posix()
    assert hashlib.sha256((E / name).read_bytes()).hexdigest() == digest
    assert hashlib.sha256(subprocess.check_output(['git', 'show', 'HEAD:' + relative], cwd=P)).hexdigest() == digest
back = read(ROOT / 'backups/operational-20260910-files-audit/MANIFEST.json')
for label, path in [('feature_store', ROOT / 'operacao/saidas/feature_store.db'), ('api_budget', ROOT / 'operacao/dados/api_guard_budget.db')]:
    with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as conn:
        assert conn.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
        for table, expected in back[label]['tables'].items():
            ident = '"' + table.replace('"', '""') + '"'
            rows = conn.execute('SELECT * FROM ' + ident).fetchall()
            assert len(rows) == expected['rows']
            assert hashlib.sha256('\n'.join(sorted(map(repr, rows))).encode()).hexdigest() == expected['content_sha256']
record = {'status': 'PASS', 'at_utc': datetime.now(UTC).isoformat(), 'pr': pr['pr'], 'head': pr['head'], 'merge': head,
          'tree': git(P, 'rev-parse', 'HEAD^{tree}'), 'ci_pr_run': pr['run'], 'ci_main_run': main['run'],
          'four_pr_and_four_main_jobs_passed': True, 'local_passed': passed, 'local_skipped': skips, 'local_failed': failed,
          'manifest_files_verified_in_git_and_checkout': len(manifest['files']), 'live_databases_and_budget_unchanged': True,
          'frozen_executor_and_original_prompt_preserved': True, 'private_chat_backup_preserved': True,
          'scope': 'Files, local backups, documentation and selected public evidence; research dependencies remain documented.'}
(F / 'integration.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')

report = R / 'REVISAO.md'
before = report.read_bytes()
assert b'## 20.' not in before
(F / 'canonical_before_files_audit.md').write_bytes(before)
(F / 'report_verification_before.json').write_bytes((R / 'report_verification.json').read_bytes())
section = f'''
## 20. Conferência dos arquivos, documentação e recuperação em 10/09

O pedido posterior conferiu a raiz `C:\\Cripto` e os Markdown do Git. O [inventário inicial](organization_20260910/root_inventory.json) registrou 186.120 arquivos e 15.712.251.255 bytes, sem diretórios ilegíveis; um link foi identificado e não seguido. O inventário individual fica em `organization_20260910/file_inventory.private.jsonl`, fora do Git. Esses números são anteriores aos artefatos criados nesta etapa.

A [comparação do pacote restaurado](organization_20260910/original_files_verification.private.json) conferiu os 63.632 arquivos originais e os 2.728 arquivos de runtime, além da cópia de 2.728 arquivos de runtime do pacote. Todos coincidem com os hashes, aceitando somente as quatro relocações registradas em `RESTAURACAO.json`. O [ZIP original](organization_20260910/migration_archive_verification.json) teve seus 22.817 objetos verificados por SHA-256. A [validação do ambiente e observadores](organization_20260910/frozen_runtime_validation.json) aprovou 3.785 arquivos de runtime, 616 arquivos brutos de altcoins, o snapshot e seis fontes de carry; diários intactos e nenhuma requisição.

Os [114 Markdown anteriores](organization_20260910/normalized_baseline_markdown_summary.json) passaram em UTF-8 e tiveram 424 destinos locais conferidos. A versão atual tem 116 Markdown. Os 103 caminhos relativos de duas reproduções históricas precisam da pasta original; todos os destinos existem e estão no [mapa de referências](organization_20260910/normalized_baseline_markdown_historical_links.json). Os bytes congelados permanecem intactos. Os índices, README e guias operacionais foram corrigidos para separar os cortes históricos da operação atual, usar o perfil local e explicar quotas, dados e recuperação. A verificação não certifica todos os sites externos ou todas as âncoras internas.

O [backup atual](organization_20260910/backup_verification.json), em `C:\\Cripto\\backups\\operational-20260910-files-audit`, passou por criação, verificação e restauração em destino novo. Tabelas, conteúdo e esquema coincidem; três previsões, dois snapshots, um registro de inputs e 200 barras de mercado. O banco de quotas também foi copiado de forma consistente. Os dois bancos ativos permaneceram inalterados inclusive após os testes finais. A ferramenta não cobre toda a raiz nem perda física do disco.

A [limpeza dos caches](organization_20260910/cleanup.json) retirou 195.848 bytes, preservados em ZIP de 51.981 bytes. A [cópia de publicação redundante](organization_20260910/redundant_worktree.json) foi retirada sem força, após confirmar árvore idêntica ao código integrado, 2.920 arquivos versionados limpos e nenhum extra. Commit, branch e comando de recriação foram preservados. Os snapshots, ambientes congelados, dados, diários, código exclusivo, configuração privada, relatórios e backup do chat foram mantidos.

O [PR #{pr['pr']}](https://github.com/leonardosovienski/cripto-predictor/pull/{pr['pr']}) publicou a conferência e as correções documentais. Commit `{pr['head']}`, integração `{head}`; árvore resultante idêntica à revisada. Os quatro jobs passaram no [PR](https://github.com/leonardosovienski/cripto-predictor/actions/runs/{pr['run']}) e no [main](https://github.com/leonardosovienski/cripto-predictor/actions/runs/{main['run']}). A [validação pós-merge Windows](postmerge_files01/validation.json) aprovou todos os extras, build, status, ajuda e **1.505 testes, um skip de symlink, zero falhas**. A [conferência dos artefatos](organization_20260910/artifact_validation.json) verificou os hashes no índice, ausência de valores das chaves configuradas e preservação do código, testes, locks, charters, CI, executor congelado e backup privado do chat. [Integração final](organization_20260910/integration.json).

Leia `C:\\Cripto\\LEIA_PRIMEIRO.md` e [CONFERENCIA_ARQUIVOS_20260910.md](C:/Cripto/pesquisa-20260909/docs/CONFERENCIA_ARQUIVOS_20260910.md) para retomar. `RETOMADA_APOS_CHAT_20260910.md` continua vinculado ao backup privado anterior; o novo índice o complementa. Permanecem as dependências de dados/fontes originais H5 e macro, segunda fonte Aave, janelas futuras carry/LLM e extratos pessoais. A organização não certifica lucro futuro, não renova a validade do snapshot v4 e não ativa agendamentos, pagamentos, ordens ou capital. Chaves atuais mantidas; segurança da branch excluída.
'''
(R / 'work/files_audit_report_section.md').write_text(section, encoding='utf-8')
text = before.decode('utf-8') + section
links = re.findall(r'\[[^\]]+\]\(([^)]+)\)', text)
local = [x for x in links if not x.startswith(('https:', 'http:', '#'))]
missing = [x for x in local if not (Path(x) if Path(x).is_absolute() else R / x).exists()]
assert not missing, missing
assert len(re.findall(r'^## \d+\.', text, re.M)) == 20
report.write_text(text, encoding='utf-8')
verification = {'checked_at': record['at_utc'], 'status': 'PASS', 'report_sha256': hashlib.sha256(report.read_bytes()).hexdigest(),
                'sections': 20, 'local_links_checked': len(local), 'missing_links': [], 'head': head,
                'validation_scope': 'File inventory, original hashes, ZIP objects, frozen runtime, backup/restore, documentary cleanup and integrated CI plus full Windows suite.',
                'integration_evidence': 'organization_20260910/integration.json',
                'economic_conclusion': 'Personal and prospective profit not validated; remaining dependencies documented.'}
(R / 'report_verification.json').write_text(json.dumps(verification, indent=2), encoding='utf-8')
writer = R / 'work/write_report.py'
hook = "\nif (R/'work/files_audit_report_section.md').exists():\n    with (R/'REVISAO.md').open('a', encoding='utf-8') as stream:\n        stream.write((R/'work/files_audit_report_section.md').read_text(encoding='utf-8'))\n"
if 'files_audit_report_section.md' not in writer.read_text(encoding='utf-8'):
    with writer.open('a', encoding='utf-8') as stream:
        stream.write(hook)
print(json.dumps(record, ensure_ascii=False))
