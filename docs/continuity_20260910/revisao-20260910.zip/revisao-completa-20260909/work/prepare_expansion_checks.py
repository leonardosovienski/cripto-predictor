from pathlib import Path
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\work')
s=(R/'run_checks.py').read_text(encoding='utf-8')
s=s.replace('PROJECT = Path(r"C:\\Cripto\\pesquisa-20260909")','PROJECT = Path(r"C:\\Cripto\\auditoria-ampliada-20260910")')
s=s.replace('"PYTHONIOENCODING": "utf-8",', '"OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1", "UV_PROJECT_ENVIRONMENT": r"C:\\Cripto\\pesquisa-20260909\\.venv", "PYTHONIOENCODING": "utf-8",')
s=s.replace('    result = subprocess.run(args, cwd=cwd, env=ENV,', '''    if len(args) >= 2 and args[1] == "python":
        args = args[:2] + [str(REVIEW / "work" / "isolated_python.py")] + args[2:]
        if "-u" in args:
            args.remove("-u")
    elif len(args) >= 3 and args[1] == "uv":
        args = args[:3] + ["--project", str(PROJECT)] + args[3:]
    result = subprocess.run(args, cwd=cwd, env=ENV,''')
s=s.replace('check("pyright", [CMD, "uv", "run", "--no-sync", "pyright"])','check("pyright", [CMD, "python", "-m", "pyright", "--pythonpath", r"C:\\Cripto\\pesquisa-20260909\\.venv\\Scripts\\python.exe"])')
s=s.replace('if build.returncode == 0:\n    state', 'if build.returncode == 0:\n    (PROJECT / "dist").mkdir(exist_ok=True)\n    state')
(R/'run_expansion_checks.py').write_text(s,encoding='utf-8')
