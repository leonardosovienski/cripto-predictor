from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
f=p/'GarimpoInvestimentos/v3/macro_features.py';s=f.read_text(encoding='utf-8');a=s.index('"""',3)+3
s='''"""Macro covariates with explicit observed publication timestamps.

Daily observations are not daily releases. A business-day lag is available only
as an explicitly named historical assumption and cannot prove causal availability.
Missing values require a measured coverage check before any model fit.
"""'''+s[a:]
s=s.replace('import csv\n','import csv\nimport math\nfrom bisect import insort\n')
s=s.replace('from GarimpoInvestimentos.v3.feature_builder import FeatureVector','from GarimpoInvestimentos.v3.feature_builder import FeatureVector\nfrom GarimpoInvestimentos.trading.contracts import ensure_utc')
a=s.index('def build_dxy_return(')
s=s[:a]+'''def _aligned_dxy(
    feature_vectors: list[FeatureVector],
    closes: dict[date, float],
    *,
    available_at: dict[date, datetime] | None,
    publish_lag_days: int,
    assume_business_day_lag: bool,
) -> list[float | None]:
    if isinstance(publish_lag_days, bool) or not isinstance(publish_lag_days, int) or publish_lag_days < 0:
        raise ValueError("publish_lag_days nao pode ser negativo ou fracionario")
    if any(not math.isfinite(value) or value <= 0 for value in closes.values()):
        raise ValueError("DXY exige valores positivos finitos")
    if available_at is None:
        if not assume_business_day_lag:
            raise ValueError("DXY exige available_at documentado por vintage; lag presumido nao prova publicacao")
        available_at = {day: datetime.combine(published_at(day, publish_lag_days), datetime.min.time(), tzinfo=UTC) for day in closes}
    if set(closes) - set(available_at):
        raise ValueError("DXY sem data de disponibilidade para todas as observacoes")
    events = []
    for day in closes:
        stamp = ensure_utc(available_at[day], "available_at")
        if stamp.date() < day:
            raise ValueError("DXY publicado antes da referencia")
        events.append((int(stamp.timestamp() * 1000), day))
    events.sort()
    usable: list[date] = []
    cursor = 0
    out: list[float | None] = [None] * len(feature_vectors)
    for index, fv in sorted(enumerate(feature_vectors), key=lambda pair: pair[1].timestamp_exchange_ms):
        while cursor < len(events) and events[cursor][0] <= fv.timestamp_exchange_ms:
            insort(usable, events[cursor][1])
            cursor += 1
        if len(usable) >= 2:
            out[index] = (closes[usable[-1]] / closes[usable[-2]] - 1) * 100.0
    return out


def build_dxy_return(
    feature_vectors: list[FeatureVector], dxy_daily_closes: dict[date, float], *,
    available_at: dict[date, datetime] | None = None,
    publish_lag_days: int = 1, assume_business_day_lag: bool = False,
) -> list[float]:
    """As-of DXY return. Zero imputation is exposed separately by dxy_coverage.

    A supplied timestamp must describe the availability of that exact value/vintage.
    Explicit lag assumptions are for reproduction, not a historical availability claim.
    """
    values = _aligned_dxy(feature_vectors, dxy_daily_closes, available_at=available_at,
        publish_lag_days=publish_lag_days, assume_business_day_lag=assume_business_day_lag)
    return [0.0 if value is None else value for value in values]


def dxy_coverage(
    feature_vectors: list[FeatureVector], dxy_daily_closes: dict[date, float], *,
    available_at: dict[date, datetime] | None = None,
    publish_lag_days: int = 1, assume_business_day_lag: bool = False,
) -> tuple[int, int]:
    values = _aligned_dxy(feature_vectors, dxy_daily_closes, available_at=available_at,
        publish_lag_days=publish_lag_days, assume_business_day_lag=assume_business_day_lag)
    return sum(value is None for value in values), len(values)


def _load_dxy_csv(path: Path) -> tuple[dict[date, float], dict[date, datetime]]:
    closes: dict[date, float] = {}
    available: dict[date, datetime] = {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        fields = reader.fieldnames
        if fields not in (["date", "close"], ["date", "close", "published_at"], ["observation_date", "DTWEXBGS"]):
            raise ValueError(f"{path}: cabecalho invalido")
        for row in reader:
            if None in row or any(value is None for value in row.values()):
                raise ValueError(f"{path}: linha malformada")
            raw_close = row[fields[1]]
            if fields[0] == "observation_date" and raw_close == ".":
                continue
            try:
                day = date.fromisoformat(row[fields[0]])
                close = float(raw_close)
                if not math.isfinite(close) or close <= 0:
                    raise ValueError("close nao positivo/finito")
                stamp = ensure_utc(datetime.fromisoformat(row["published_at"]), "published_at") if "published_at" in row else None
            except ValueError as exc:
                raise ValueError(f"{path}: linha inválida") from exc
            if day in closes and (closes[day] != close or available.get(day) != stamp):
                raise ValueError(f"{path}: observacoes conflitantes; use uma tabela por vintage")
            closes[day] = close
            if stamp is not None:
                if stamp.date() < day:
                    raise ValueError("publicacao anterior a referencia")
                available[day] = stamp
    if not closes:
        raise ValueError(f"{path}: nenhum dado valido")
    return closes, available


def load_dxy_daily_closes(path: Path) -> dict[date, float]:
    return _load_dxy_csv(path)[0]


def load_dxy_availability(path: Path) -> dict[date, datetime]:
    closes, available = _load_dxy_csv(path)
    if closes.keys() != available.keys():
        raise ValueError("Historico DXY exige coluna published_at documentada para cada vintage")
    return available


__all__ = ["build_dxy_return", "dxy_coverage", "build_macro_event_dummy", "load_dxy_daily_closes", "load_dxy_availability"]
'''
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/v3/backtest_v3.py';s=f.read_text(encoding='utf-8').replace('    load_dxy_daily_closes,','    load_dxy_daily_closes,\n    load_dxy_availability,\n    dxy_coverage,');s=s.replace('        dxy_all = build_dxy_return(all_features, dxy_closes)','        dxy_available = load_dxy_availability(dxy_closes_path)\n        missing, _ = dxy_coverage(all_features, dxy_closes, available_at=dxy_available)\n        if missing:\n            raise ValueError(f"DXY indisponivel em {missing} pontos; completar vintages antes do treino")\n        dxy_all = build_dxy_return(all_features, dxy_closes, available_at=dxy_available)');f.write_text(s,encoding='utf-8')
# These old tests now explicitly exercise a hypothetical lag, not real Fed releases.
f=p/'tests/test_v3_macro_features.py';s=f.read_text(encoding='utf-8').replace('publish_lag_days=', 'assume_business_day_lag=True, publish_lag_days=');s=s.replace('"""H7 (macro/DXY): build_macro_event_dummy / build_dxy_return — puras, sem rede."""','"""Legacy synthetic business-day assumption tests, NOT actual Fed availability.\nThe real publication/vintage cases are covered by test_audit_source_integrity.py.\n"""');f.write_text(s,encoding='utf-8')
# Actual timestamp cadence must be represented by the synthetic H8 fixture.
f=p/'tests/test_hypothesis_loop_runner.py';s=f.read_text(encoding='utf-8').replace('timestamp_exchange_ms=ts_ms,','timestamp_exchange_ms=ts_ms * 28_800_000,');s=s.replace('    _, retornos = _build_dados_e_retornos(fvs, horizon_days=0)\n    # horizon_days=0 -> passos=0 -> j==i sempre; close[1]<=0 deve dar None no índice 1\n    assert retornos[1] is None','    with pytest.raises(ValueError, match="horizon_days"):\n        _build_dados_e_retornos(fvs, horizon_days=0)');f.write_text(s,encoding='utf-8')
