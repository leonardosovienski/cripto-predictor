from pathlib import Path
import sys
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
runner=R/'work/run_checks.py'
sys.argv=[str(runner),'executors_target01']
source=runner.read_text(encoding='utf-8').split('if PHASE.startswith("postmerge"):')[0]
exec(compile(source,str(runner),'exec'))
result=check('targeted',[CMD,'python',str(R/'work/test_executor_bootstrap.py'),'-q','-ra','--basetemp',str(TEMP/'pytest'),'--junitxml',str(RUN/'tests.xml')])
raise SystemExit(result.returncode)
