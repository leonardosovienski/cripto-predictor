import hashlib
import io
import json
import re
import subprocess
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
P = Path(r'C:\Cripto\pesquisa-20260909')
S = Path(r'C:\Users\leona\.codex\sessions\2026\09\09\rollout-2026-09-09T18-45-21-01a08821-f27f-7970-a87f-f37b1e249910.jsonl')
D = R / 'chat_closure_20260910'
HANDOFF = Path(r'C:\Cripto\RETOMADA_APOS_CHAT_20260910.md')
D.mkdir(exist_ok=False)
assert not HANDOFF.exists()
captured_at = datetime.now(UTC).isoformat()
raw = S.read_bytes()
raw = raw[:raw.rfind(b'\n') + 1]
assert raw
messages = []
records = 0
for line in io.BytesIO(raw):
    record = json.loads(line)
    records += 1
    payload = record.get('payload', {})
    msg = None
    if record.get('type') == 'response_item' and payload.get('type') == 'message':
        role = payload.get('role')
        channel = payload.get('channel') or payload.get('phase')
        if role == 'user' or (role == 'assistant' and channel in ('commentary', 'final')):
            body = '\n'.join(c.get('text', '') for c in payload.get('content', []) if c.get('type') in ('input_text', 'output_text'))
            if not body.startswith(('<environment_context>', '<recommended_plugins>', '<permissions instructions>')):
                msg = {'at': record.get('timestamp'), 'role': role, 'channel': channel, 'text': body}
    elif record.get('type') == 'event_msg' and payload.get('type') == 'agent_message':
        msg = {'at': record.get('timestamp'), 'role': 'assistant', 'channel': payload.get('phase'), 'text': payload.get('message', '')}
    elif record.get('type') == 'event_msg' and payload.get('type') == 'item_completed':
        item = payload.get('item', {})
        if item.get('type') in ('agentMessage', 'agent_message', 'AgentMessage'):
            msg = {'at': record.get('timestamp'), 'role': 'assistant', 'channel': item.get('phase'),
                   'text': '\n'.join(c.get('text', '') for c in item.get('content', []) if c.get('type') == 'Text')}
    if msg and msg['text']:
        if msg['role'] == 'assistant' and any(x['text'] == msg['text'] and x['role'] == 'assistant' for x in messages[-3:]):
            continue
        messages.append(msg)
assert any(m['role'] == 'user' and 'confere se posso apagar o chat' in m['text'] for m in messages)
assert any(m['role'] == 'assistant' and 'Feito. Reli o histórico' in m['text'] and '94fc9e7' in m['text'] for m in messages)
(D / 'session.private.jsonl').write_bytes(raw)
assert (D / 'session.private.jsonl').read_bytes() == raw
with S.open('rb') as stream:
    assert stream.read(len(raw)) == raw
(D / 'conversation.private.json').write_text(json.dumps(messages, ensure_ascii=False, indent=2), encoding='utf-8')
assert json.loads((D / 'conversation.private.json').read_bytes()) == messages

verification = json.loads((R / 'report_verification.json').read_bytes())
integration = json.loads((R / 'publication_chat_20260910/integration.json').read_bytes())
assert hashlib.sha256((R / 'REVISAO.md').read_bytes()).hexdigest() == verification['report_sha256']
assert verification['status'] == 'PASS' and verification['sections'] == 19
assert integration['postmerge_passed'] == 1505 and integration['postmerge_failed'] == 0
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=P, text=True).strip()
remote = subprocess.check_output(['git', 'ls-remote', 'origin', 'refs/heads/main'], cwd=P, text=True).split()[0]
assert head == remote == integration['merge'] == '94fc9e769fe6aaf16439e845ca29378701d34886'
assert hashlib.sha256((P / 'docs/NEXT_CHAT_PROMPT.md').read_bytes()).hexdigest() == '8969db38ef9a3ec29ee16a780b9572ec9f7d7808cabc9bac17a319616b47fe20'
evidence = P / 'docs/evidence/remaining_dependencies_20260910'
manifest = json.loads((evidence / 'manifest.json').read_bytes())
for name, digest in manifest['files'].items():
    assert hashlib.sha256((evidence / name).read_bytes()).hexdigest() == digest, name

handoff = '''# Retomada do projeto após esta conversa

Este arquivo é um índice de continuidade, conferido em 10/09/2026. O registro vivo único continua sendo o relatório indicado abaixo. Verifique novamente data, Git e quota antes de executar ações dependentes deles.

## Leitura inicial

1. [Regras do dono](C:/Cripto/AGENTS.md).
2. [Configuração local](C:/Cripto/pesquisa-20260909/docs/CONFIGURACAO_LOCAL.md) e [mandato original preservado](C:/Cripto/pesquisa-20260909/docs/NEXT_CHAT_PROMPT.md).
3. [Relatório canônico, incluindo seções 18 e 19](C:/Cripto/operacao/relatorios/REVISAO_COMPLETA_20260909/REVISAO.md).
4. [Conferência publicada](C:/Cripto/pesquisa-20260909/docs/CONFERENCIA_CHAT_20260910.md) e [comprovante final de integração](C:/Cripto/operacao/relatorios/REVISAO_COMPLETA_20260909/publication_chat_20260910/integration.json).

O PR #117 está integrado em `94fc9e769fe6aaf16439e845ca29378701d34886`. Quatro jobs aprovados no PR e no main; suíte Windows pós-merge com 1.505 aprovados, um skip de symlink e zero falhas. Esses resultados pertencem à versão/datagem registrada, não substituem a conferência do estado futuro.

O snapshot v4 foi recuperado offline; a janela de frescor termina em 11/09/2026 02:00 UTC. H5/vintages históricos, confirmação Aave por segunda fonte, observações futuras e custos pessoais continuam dependências explícitas nas seções 18–19. Não há lucro pessoal/prospectivo validado. Preserve as chaves atuais; não exigir revogação como condição para a pesquisa. Segurança administrativa da branch foi excluída pelo dono.

Trabalhar sozinho, dentro de `C:\\Cripto`, usando `C:\\Cripto\\CRIPTO.cmd` para Python/uv. Preservar dados, pacote restaurado e o executor congelado em `C:\\Cripto\\auditoria-ampliada-20260910`. Sem agendamentos, ordens, assinaturas, movimentação de fundos ou credenciais financeiras. Não contornar a guarda de API; recalcular disponibilidade pela data UTC atual. O repasse original não deve ter seus bytes reescritos.

## Histórico preservado localmente

A [pasta de preservação do chat](C:/Cripto/operacao/relatorios/REVISAO_COMPLETA_20260909/chat_closure_20260910/README.md) contém a cópia local do registro e das mensagens, com manifesto de integridade. Inclui o fechamento do PR #117 e o pedido de conferência antes de apagar o chat. Não foi publicada no GitHub. Não há promessa de reimportação automática desse arquivo na interface do aplicativo.

Para continuar em outra conversa: “Leia C:\\Cripto\\RETOMADA_APOS_CHAT_20260910.md, confira o estado real e continue a partir das pendências documentadas, preservando as restrições do dono.”

Excluir o histórico da interface não é autorização para apagar `C:\\Cripto`: essa pasta mantém os dados operacionais e privados necessários, além do material já publicado.
'''
HANDOFF.write_text(handoff, encoding='utf-8')
readme = f'''# Preservação local antes de apagar o chat

Captura: {captured_at}. Arquivos privados, fora do repositório publicado.

- `session.private.jsonl`: cópia dos registros completos disponíveis até a captura ({records} registros). Inclui metadados e resultados de ferramentas; não publicar.
- `conversation.private.json`: mensagens naturais extraídas ({len(messages)} mensagens), incluindo o fechamento da publicação e a pergunta sobre apagar o chat.
- `manifest.json`: hashes dos arquivos desta pasta (exceto o próprio manifesto) e do índice de retomada.
- `verification.json`: verificações atuais de Git, relatório, repasse e evidências.

A captura não inclui mensagens escritas depois do horário indicado e não promete restaurar a conversa na interface. Para retomar o trabalho, leia [o índice de continuidade](C:/Cripto/RETOMADA_APOS_CHAT_20260910.md). Este índice e o relatório canônico são suficientes para iniciar uma nova conversa no projeto.
'''
(D / 'README.md').write_text(readme, encoding='utf-8')
links = re.findall(r'\[[^\]]+\]\(([^)]+)\)', handoff + readme)
for link in links:
    assert Path(link).exists(), link
record = {'at_utc': captured_at, 'status': 'PASS', 'head_and_remote_main': head,
          'report_hash_matches_final_verification': True, 'report_sections': 19,
          'evidence_files_verified': len(manifest['files']), 'owner_prompt_preserved': True,
          'conversation_messages': len(messages), 'roles': dict(Counter(m['role'] for m in messages)),
          'raw_session_records': records, 'raw_session_bytes': len(raw),
          'last_message_at_capture': messages[-1]['at'], 'raw_backup_matches_source_prefix': True,
          'handoff_links_verified': len(links), 'copied_outside_codex_managed_task': True,
          'chat_deleted_or_archived_by_this_action': False, 'scope': 'Preserves continuity; remaining research dependencies are still open'}
(D / 'verification.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
files = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in D.iterdir() if p.is_file()}
(D / 'manifest.json').write_text(json.dumps({'at_utc': captured_at, 'files': files,
    'handoff_path': str(HANDOFF), 'handoff_sha256': hashlib.sha256(HANDOFF.read_bytes()).hexdigest(),
    'private_local_only': True}, ensure_ascii=False, indent=2), encoding='utf-8')
for name, digest in files.items():
    assert hashlib.sha256((D / name).read_bytes()).hexdigest() == digest
print(json.dumps(record, ensure_ascii=False))
