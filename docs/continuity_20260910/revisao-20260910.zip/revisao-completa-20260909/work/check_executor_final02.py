from pathlib import Path
import sys
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
runner=R/'work/run_checks.py'
sys.argv=[str(runner),'executors_final02']
source=runner.read_text(encoding='utf-8').split('if PHASE.startswith("postmerge"):')[0]
exec(compile(source,str(runner),'exec'))

def streamed_check(name,args):
    started=datetime.now(timezone.utc)
    log=RUN/(name+'.log')
    with log.open('w',encoding='utf-8') as stream:
        result=subprocess.run(args,cwd=PROJECT,env=ENV,stdout=stream,stderr=subprocess.STDOUT)
    item={'name':name,'command':args,'exit_code':result.returncode,'log':log.name,
          'started_at_utc':started.isoformat(),'finished_at_utc':datetime.now(timezone.utc).isoformat()}
    state['checks'].append(item)
    save()
    print(json.dumps(item),flush=True)
    return result.returncode

for name,args in [
    ('sync_all_extras',[CMD,'uv','sync','--locked','--all-extras']),
    ('ruff',[CMD,'python','-m','ruff','check','.']),
    ('format',[CMD,'python','-m','ruff','format','--check','--diff','.']),
    ('pyright',[CMD,'uv','run','--no-sync','pyright']),
    ('secrets',[CMD,'python','scripts/scan_secrets.py','.']),
    ('build',[CMD,'uv','build','--out-dir',str(RUN/'dist')]),
]:
    if streamed_check(name,args):
        raise SystemExit(1)
for p in (RUN/'dist').iterdir():
    shutil.copy2(p,PROJECT/'dist'/p.name)
state['packages']={d.metadata['Name']:d.version for d in importlib.metadata.distributions()}
streamed_check('tests',[CMD,'python','-u','-m','pytest','-v','-ra','-o','faulthandler_timeout=120','--basetemp',str(TEMP/'pytest'),'--junitxml',str(RUN/'tests.xml')])
streamed_check('windows_status',[CMD,'status'])
streamed_check('windows_help',[CMD,'pipeline','--help'])
streamed_check('wheel_contract',[CMD,'python',str(R/'work/wheel_check.py'),PHASE])
contract=json.loads((RUN/'wheel_contract.json').read_bytes())
state['wheel_inner_checks_passed']=all(c['exit_code']==0 for c in contract['checks']) and not contract['prohibited_members']
state['finished_at_utc']=datetime.now(timezone.utc).isoformat()
save()
raise SystemExit(any(c['exit_code'] for c in state['checks']) or not state['wheel_inner_checks_passed'])
