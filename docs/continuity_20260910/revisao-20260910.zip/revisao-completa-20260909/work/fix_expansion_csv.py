from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
for name,cls,stamp,values in [('funding','FundingRecord','funding_time_ms',['funding_rate','mark_price']),('oi','OIRecord','timestamp_ms',['oi_contracts','oi_notional_usd']),('spot','KlineRecord','open_ms',['close','volume'])]:
    path=p/f'GarimpoInvestimentos/v3/collectors/{name}_collector.py'
    s=path.read_text(encoding='utf-8').replace('import csv\n','')
    s=s.replace('from GarimpoInvestimentos.v3.circuit_breaker import CircuitBreaker','from GarimpoInvestimentos.v3.circuit_breaker import CircuitBreaker\nfrom GarimpoInvestimentos.v3.collectors.record_io import load_records, save_records, validate_observation, validate_page')
    pos=s.index('\n\n# ------------------------------------------------------------------ #\n# Coletor')
    checks=''
    if name=='spot': checks='        if self.close <= 0 or self.volume < 0:\n            raise ValueError("close deve ser positivo e volume nao negativo")\n'
    if name=='oi': checks='        if self.oi_contracts < 0 or self.oi_notional_usd < 0:\n            raise ValueError("OI nao pode ser negativo")\n'
    if name=='funding': checks='        if self.mark_price < 0:\n            raise ValueError("mark_price nao pode ser negativo; zero significa ausente no arquivo Vision")\n'
    body='\n    def __post_init__(self) -> None:\n        validate_observation(self.symbol, self.'+stamp+', {'+', '.join(f'"{v}": self.{v}' for v in values)+'})\n'+checks
    s=s[:pos]+body+s[pos:]
    start=s.index(f'def save_{name}_csv(')
    fields=['symbol',stamp,*values]
    conversions=['row["symbol"]',f'int(row["{stamp}"])',*[f'float(row["{v}"])' for v in values]]
    s=s[:start]+f'''def save_{name}_csv(records: list[{cls}], path: Path) -> int:
    """Add unique observations atomically; reject changed values for existing keys."""
    return save_records(records, path, _FIELDNAMES, load_{name}_csv, "{stamp}")


def load_{name}_csv(path: Path) -> list[{cls}]:
    return load_records(path, _FIELDNAMES, lambda row: {cls}({', '.join(conversions)}), "{stamp}")
'''
    s=s.replace('        records: list[', '        if start_ms > end_ms or start_ms < 0:\n            raise ValueError("intervalo invalido")\n        records: list[',1)
    s=s.replace('while cursor < end_ms:', 'while cursor <= end_ms:')
    s=s.replace('page = await self._fetch_page(client, cursor, end_ms)',f'page = await self._fetch_page(client, cursor, end_ms)\n                    validate_page(page, self.symbol, "{stamp}", cursor, end_ms)')
    if name=='spot':
        s=s.replace('import logging\n','import logging\nimport time\n')
        s=s.replace('        cursor = start_ms','        # Freeze availability at request start. Never cache an unfinished candle.\n        available_at_ms = min(end_ms, int(time.time() * 1000))\n        cursor = start_ms')
        s=s.replace('        return records\n','        return [r for r in records if r.open_ms + 3_600_000 <= available_at_ms]\n',1)
    if name=='oi':
        s=s.replace('granularidade 8h','granularidade 1h').replace('início do período 8h','instante da observacao horaria').replace('Histórico de OI mais antigo exige feed pago.','Histórico mais antigo exige outra fonte, como arquivos publicos Binance Vision.')
    path.write_text(s,encoding='utf-8')
