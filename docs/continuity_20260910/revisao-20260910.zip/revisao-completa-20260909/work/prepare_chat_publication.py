import hashlib
import json
import shutil
import subprocess
import sys
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')
R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
P = Path(r'C:\Cripto\publicacao-conferencia-20260910')
E = P/'docs/evidence/remaining_dependencies_20260910'
L = R/'publication_chat_20260910'
E.mkdir(parents=True, exist_ok=False)
copied = {}


def copy(relative, target=None):
    src = R/relative
    dst = E/(target or relative)
    assert src.is_file() and src.suffix not in {'.db', '.sqlite', '.coverage'}
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(src.read_bytes())
    copied[dst.relative_to(E).as_posix()] = str(src)


for name in ('snapshot/prepared.json', 'snapshot/applied.json', 'snapshot/payload.json',
             'aave_second_source/protocol.json', 'aave_second_source/offline_validation.json',
             'aave_status.json', 'carry_status.json', 'llm_status.json', 'access_check.json',
             'historical_recovery_routes.json', 'verification.json'):
    copy('remaining_six_20260910/'+name, name)
copy('executor_preflight02/result.json', 'original_receipts/result.json')
for name in ('5714523b98c7451c92a841681049a657.json', '8b0c5589c2aa4e6e8353b221877c3aa8.json'):
    copy('executor_preflight02/sources/'+name, 'original_receipts/sources/'+name)
for name in ('inspect_existing_receipts', 'recover_operational_snapshot', 'compare_aave_second_source',
             'finish_remaining_six', 'write_remaining_six_section', 'verify_remaining_six'):
    copy('work/'+name+'.py', 'executed_sources/'+name+'.source')
copy('REVISAO.md', 'review_snapshot.md')
for relative in ('integration.json', 'closure110/integration.json', 'manual_dependencies/integration.json',
                 'executor_dependencies/integration.json', 'profit_search/integration.json',
                 'expansion_integration.json', 'closure_audit/integration.json',
                 'closure_audit/remaining_six_after.json'):
    copy(relative, 'prior_integrations/'+relative)

messages = json.loads((L/'conversation_messages.json').read_bytes())
summary = {'checked_at': datetime.now(UTC).isoformat(), 'conversation_start': messages[0]['at'],
           'conversation_cutoff': messages[-1]['at'], 'messages_read': len(messages),
           'roles': dict(Counter(m['role'] for m in messages)),
           'scope': 'All natural-language requests, replies, final answers and progress messages recovered in this conversation through the cutoff; claims checked against versioned code, source receipts, test/CI records and operational state. Does not mean every historic file or external service audited.',
           'private_transcript_published': False,
           'owner_prompt': 'Byte-identical to Git HEAD before this publication; no uncommitted content delta',
           'decisions': [
               {'claim': 'Engineering fixes PR110-116', 'decision': 'Keep within tested scope; integration receipts included', 'evidence': 'prior_integrations/'},
               {'claim': 'Snapshot must wait for next API day', 'decision': 'Corrected: existing Sep10 receipt supported offline recovery', 'evidence': 'snapshot/applied.json'},
               {'claim': 'All history, architecture and profit validated', 'decision': 'Not supported; retain bounded coverage and explicit missing evidence', 'evidence': 'review_snapshot.md'},
               {'claim': 'Aave original history unavailable', 'decision': 'Superseded by 13 weekly and 25 monthly recovered boundaries; different-source confirmation still absent', 'evidence': '../../AAVE_VALIDACAO_20260910.md'},
               {'claim': 'Annual Aave result with total 5000 USDC', 'decision': 'Use funded-cost results 232.413985 and 110.170571; earlier 235.61/112.01 used different principal/cost allocation', 'evidence': '../../AAVE_VALIDACAO_20260910.md'},
               {'claim': 'LLM executor unimplemented or PR113 still draft', 'decision': 'Historical states superseded; executor merged and v3 registration prepared; sample not collected', 'evidence': '../../manual_dependencies_20260910/EXECUCAO.md'},
               {'claim': '542 missing trading days', 'decision': 'Explained in 12 instrument episodes; no candles fabricated or universal history certification', 'evidence': '../../manual_dependencies_20260910/RETOMADA.md'},
               {'claim': 'Revocation of current working keys required', 'decision': 'Not required by this task; current keys retained, historical logs unverified and nonblocking', 'evidence': 'access_check.json'},
               {'claim': 'Main branch administrative protection', 'decision': 'Excluded by owner; no administrative change', 'evidence': 'review_snapshot.md'},
           ]}
(E/'conversation_reconciliation.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
(E/'README.md').write_text('''# Evidência datada da conferência e recuperação — 10/09/2026

Esta é uma captura pública da etapa posterior ao PR #116 (`ac4184e`), não um segundo registro vivo. O registro canônico permanece em `C:\\Cripto\\operacao\\relatorios\\REVISAO_COMPLETA_20260909\\REVISAO.md`. O [snapshot desse relatório](review_snapshot.md) conserva seu texto e os caminhos locais exatamente como estavam; links relativos dele exigem a árvore local da revisão. Para navegar na publicação, use este índice e a [conferência resumida](../../CONFERENCIA_CHAT_20260910.md).

- [Conferência das afirmações](conversation_reconciliation.json): recorte de mensagens efetivamente relido, decisões e referências. A conversa privada não está publicada.
- [Snapshot aplicado](snapshot/applied.json), [controles e backup lógico](snapshot/prepared.json), [payload reproduzível](snapshot/payload.json): 200 barras fechadas e features v4, recebimento original de 10/09 02:12 UTC e processamento separado. Nenhum SQLite operacional foi publicado.
- [Manifesto original dos recibos](original_receipts/result.json): incluídos apenas os dois recibos públicos Binance de mercado/relógio; textos de notícias e respostas LLM permanecem locais. Os hashes dos demais recibos são referências históricas, não arquivos omitidos silenciosamente do manifesto desta publicação.
- [Comparação Aave preparada](aave_second_source/protocol.json), [replay offline](aave_second_source/offline_validation.json), [status](aave_status.json): 38 pontos, no máximo 350 RPCs, uma unidade de ingestão, sem retries. Nenhuma resposta da segunda fonte foi obtida nesta etapa.
- [Carry](carry_status.json), [LLM](llm_status.json), [limites de acesso](access_check.json) e [rotas históricas/custos](historical_recovery_routes.json).
- [Verificação operacional](verification.json) e [comprovantes anteriores de integração](prior_integrations/): resultados pertencem às versões/datas declaradas, não ao futuro.

`executed_sources/*.source` preserva os programas locais exatos usados ou preparados, com seus caminhos originais. Eles são evidência de execução e não novas entradas do pacote instalado. A reprodução depende da árvore original indicada e dos recibos/históricos anteriores; não copiar scripts de escrita sobre bases existentes nem alterar seus protocolos para contornar a guarda. O [protocolo Aave](aave_second_source/protocol.json) vincula os hashes dos inputs e código originais.

`manifest.json` cobre todos os arquivos desta pasta, exceto ele próprio. Configuração privada, chaves, bancos operacionais/de orçamento, caches, logs brutos, textos de notícias/respostas LLM e transcript do chat não fazem parte da publicação. A fonte é pública, mas o segundo operador pode compartilhar infraestrutura: resultado igual não comprovará automaticamente independência dos nós.

O frescor do snapshot encerra em 11/09/2026 02:00 UTC. Horários futuros exigem execução manual dentro do protocolo; nada foi agendado. Lucro pessoal ou prospectivo continua não validado.
''', encoding='utf-8')
attrs = P/'.gitattributes'
with attrs.open('a', encoding='utf-8', newline='\n') as stream:
    stream.write('\n# Exact receipts, executed local sources and dated reconciliation evidence.\n/docs/evidence/remaining_dependencies_20260910/** -text\n')

doc = P/'docs/REVISAO_COMPLETA_20260909.md'
t = doc.read_text(encoding='utf-8')
t = t.replace('## Contrato para novos diagnósticos', '**Conferência de 10/09 após #116:** [estado reconciliado com o chat e evidências publicadas](CONFERENCIA_CHAT_20260910.md). O snapshot v4 foi derivado offline de recibo preservado; a disponibilidade é datada e não significa diagnóstico conectado permanente.\n\n## Contrato para novos diagnósticos', 1)
t = t.replace('materializa `daily-v3-contiguous`', 'materializa `daily-v4-audited` (o contrato v3 pertence à etapa anterior)')
t = t.replace('Rodar `--ingest` é necessário após atualizar o código; features `v1` antigas não são promovidas automaticamente.', 'Após mudança do contrato, é necessária ingestão compatível ou nova derivação validada de recibos suficientes, preservando seu recebimento original; features antigas não são promovidas por renomeação.')
t = t.replace('seu P&L usa proxies, funding constante aproximado e hipóteses de custo.', 'seu P&L usa proxies e hipóteses de custo. A auditoria ampliada corrigiu funding por evento, retorno aritmético e barreiras a preço observado; o veredito final permanece `UNVALIDATED`.')
t = t.replace('`trading.cost_policy.CALIBRATED_FOR_VERDICT` é um nome legado para aceitação da referência histórica de custos de perpétuos.', '`trading.cost_policy.CALIBRATED_FOR_VERDICT` agora fica vazio: a auditoria ampliada removeu a aceitação indevida da referência histórica de perpétuos como calibrada.')
t = t.replace('Permanecem 326/542 dias ausentes somados entre pares e 83/200 fechamentos não padrão;', 'As aquisições registravam 326/542 dias ausentes somados entre pares e 83/200 fechamentos não padrão. Os 542 dias da retrospectiva foram posteriormente explicados por interrupções/identidade de negociação na retomada manual, sem fabricar candles;')
t = t.replace('A nova consulta pública 1RPC confirmou a rede Arbitrum e falhou no estado histórico solicitado; Aave segue sem índice/liquidez nos 13 limites necessários.', 'A consulta 1RPC desta primeira etapa falhou. Depois, Alchemy forneceu os 13 limites originais e 25 limites mensais adicionais de Aave, com índice, identidade e liquidez conferidos. Falta a confirmação histórica por fonte independente; os resultados estão em AAVE_VALIDACAO_20260910.md.')
t = t.replace('Não houve aumento de lucro demonstrado.', 'Não houve lucro realizado pelo dono. A etapa Aave posterior acrescentou resultado histórico positivo condicional após custos modelados, sem validar lucro pessoal ou futuro.')
doc.write_text(t, encoding='utf-8')
doc = P/'docs/AUDITORIA_AMPLIADA_20260910.md'
t = doc.read_text(encoding='utf-8')
t = t.replace('O pipeline operacional conserva um snapshot `daily-v3-contiguous`; o contrato atual exige `daily-v4-audited`, além de frescor. A ingestão do próximo dia UTC é uma pendência operacional executável quando a quota normal permitir, e não foi tratada como coleta já realizada.', 'Na conferência posterior, o snapshot `daily-v4-audited` foi recuperado offline de um recibo Binance preservado, mantendo o v3 e as previsões originais. Recebimento: 10/09 02:12 UTC; última barra fechada: 10/09 00UTC; frescor até 11/09 02UTC. A dependência do snapshot foi resolvida nessa janela, sem consumir quota; novas chamadas seguem limitadas. Consulte CONFERENCIA_CHAT_20260910.md.')
t = t.replace('| Revogação de chaves antigas | Rotação confirmada pelo dono e redação de logs já corrigida | Evidência dos painéis sobre revogação/uso anterior; não é suprida por geração bem-sucedida com chave nova |', '| Histórico de chaves | Chaves atuais mantidas por orientação do dono; redação de logs corrigida | Revogação antiga/uso anterior não comprovados, P2 histórico sem bloquear a pesquisa. Nenhuma revogação atual exigida ou executada |')
doc.write_text(t, encoding='utf-8')
doc = P/'docs/README.md'
t = doc.read_text(encoding='utf-8').replace('## Estado vigente e continuidade\n', '## Estado vigente e continuidade\n\n- [Conferência do chat e publicação de 10/09](CONFERENCIA_CHAT_20260910.md): correções documentais, snapshot recuperado e estado dos seis itens após #116.\n', 1)
doc.write_text(t, encoding='utf-8')
doc = P/'docs/manual_dependencies_20260910/EXECUCAO.md'
t = doc.read_text(encoding='utf-8')
t = t.replace('# Dependências implementadas e recuperadas em 10/09/2026\n', '# Dependências implementadas e recuperadas em 10/09/2026\n\n**Atualização após #116:** [conferência do chat e seis itens](../CONFERENCIA_CHAT_20260910.md). Snapshot v4 recuperado offline; segunda fonte Aave preparada, ainda sem consulta por quota. Chaves atuais mantidas; fatos históricos de uso/revogação não bloqueiam a pesquisa. As seções abaixo preservam as datas e resultados de cada etapa.\n', 1)
doc.write_text(t, encoding='utf-8')

manifest = {'created_at': datetime.now(UTC).isoformat(), 'base_head': 'ac4184e7d3377a8f14aeebac5016c3e18f82cfcf',
    'files': {p.relative_to(E).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(E.rglob('*')) if p.is_file()},
    'copied_from_local': copied,
    'excluded': ['private configuration and keys', 'SQLite databases and quota state', 'news and LLM texts', 'private conversation transcript', 'caches, environments and transient files'],
    'note': 'A dated publication of retained evidence; not full environment backup or validated future profit'}
(E/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
(L/'prepared_publication.json').write_text(json.dumps({'file_count': len(manifest['files']), 'bytes': sum(p.stat().st_size for p in E.rglob('*') if p.is_file()), 'worktree': str(P), 'base': manifest['base_head']}, indent=2), encoding='utf-8')
print(json.dumps({'files': len(manifest['files']), 'destination': str(E), 'messages_read': len(messages)}))
