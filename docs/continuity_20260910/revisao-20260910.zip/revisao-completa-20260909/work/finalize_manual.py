from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

P=Path(r'C:\Cripto\pesquisa-20260909')
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
M=R/'manual_dependencies'
HEAD='b44f29c57b101c18cc45bd7eed6e019a5d5aa9d5'
BASE='9b8de9802c61570610bc0b212bdb0bb4c4e1d643'
def read(p): return json.loads(p.read_bytes())
def git(*args): return subprocess.check_output(['git',*args],cwd=P,text=True).strip()
def save(name,value): (M/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def validated(phase):
    value=read(R/phase/'validation.json')
    assert value.get('finished_at_utc') and all(c['exit_code']==0 for c in value['checks'])
    for name,digest in value['source_hashes'].items():
        assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest, name
    log=(R/phase/'tests.log').read_text(encoding='utf-8').splitlines()
    return value,next(x for x in reversed(log) if 'passed' in x and ' in ' in x)
def jobs(name):
    result=read(M/name)
    assert {j['name'] for j in result['jobs']}=={'quality','all-extras','container','python-314-experimental'}
    assert all(j['status']=='completed' and j['conclusion']=='success' for j in result['jobs'])
    return result

record=read(M/'integration.json')
assert (P/'docs/NEXT_CHAT_PROMPT.md').read_bytes()==(R/'manual_target01/initial_next_chat_prompt.md').read_bytes()
stage=sys.argv[1]
if stage=='premerge':
    value,summary=validated('manual_final02')
    assert value['head']==HEAD and value['wheel_inner_checks_passed']
    jobs('ci_pr.json')
    assert git('rev-parse','HEAD')==HEAD and git('rev-parse','origin/main')==BASE
    record.update(status='VALIDADO_AGUARDANDO_MERGE',local_final_checks_passed=True,
                  local_final_tests=summary,pr_four_checks_passed=True,
                  tested_tree=git('rev-parse',HEAD+'^{tree}'),
                  summary=f'PR #112 validado: {summary}; quatro jobs aprovados; base atual conferida. Integração ainda não executada.')
elif stage=='update_checkout':
    merge=read(M/'merge_result.json')
    assert merge['merged'] is True
    merged=merge['sha']
    assert git('rev-parse','origin/main')==merged
    assert git('rev-parse',merged+'^{tree}')==git('rev-parse',HEAD+'^{tree}')
    assert git('merge-base','--is-ancestor',HEAD,merged)==''
    before=(P/'docs/NEXT_CHAT_PROMPT.md').read_bytes()
    subprocess.run(['git','merge','--ff-only','origin/main'],cwd=P,check=True)
    assert before==(P/'docs/NEXT_CHAT_PROMPT.md').read_bytes()
    assert git('rev-parse','HEAD')==merged
    record.update(status='INTEGRADO_EM_VALIDACAO_DO_MAIN',merge_sha=merged,
                  merged_tree_equals_tested_tree=True,owner_prompt_preserved=True,
                  summary=f'PR #112 integrado em {merged}; árvore idêntica à validada. Checks do main e suíte local pós-merge em andamento.')
elif stage=='finish':
    value,summary=validated('postmerge_manual03')
    ci=jobs('ci_main.json')
    assert value['head']==record['merge_sha']==git('rev-parse','HEAD')==git('rev-parse','origin/main')
    assert git('rev-parse','HEAD^{tree}')==record['tested_tree']
    record.update(status='INTEGRADO_E_VALIDADO_NO_MAIN',main_four_checks_passed=True,
                  postmerge_local_passed=True,postmerge_tests=summary,main_run_id=ci['run_id'],
                  summary=f"PR #112 integrado em {record['merge_sha']}; árvore idêntica à validada. Quatro jobs aprovados no PR e no main; pós-merge local: {summary}. Segurança da branch excluída; nenhuma observação ou automação ativada.")
    progress=read(M/'result.json')
    progress.update(head=record['merge_sha'],validation=record['summary'],integration=record)
    save('result.json',progress)
else:
    raise ValueError('Unknown stage')
record['updated_at_utc']=datetime.now(timezone.utc).isoformat()
save('integration.json',record)
print(json.dumps(record,ensure_ascii=False))
