from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
sys.stdout.reconfigure(encoding='utf-8')
P=Path(r'C:\Cripto\fechamento-revisao-20260910')
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')/sys.argv[1]
R.mkdir(exist_ok=False)
T=Path(r'C:\Cripto\operacao\temporarios')/('revisao-'+sys.argv[1])
T.mkdir(exist_ok=False)
env=os.environ.copy()
for k in list(env):
    if any(s in k for s in ('API_KEY','AUTH_TOKEN','API_SECRET','SECRET_KEY')):env.pop(k,None)
env.update(CRIPTO_ENV_FILE=str(T/'empty.env'),GEMINI_API_KEY='test-gemini-key-for-unit-tests-only',SERP_API_KEY='test-serp-key-for-unit-tests-only',PREDICTOR_EVENTS_PATH=str(T/'events.jsonl'),PYTHONIOENCODING='utf-8')
env['PREDICTOR_OPS_STATE_DIR']=str(T/'state')
for k in ('DATA','OUTPUT','CACHE','LOGS'):env[k+'_DIR']=env['GARIMPO_'+k+'_DIR']=str(T/k.lower())
args=[r'C:\Cripto\CRIPTO.cmd','python',str(Path(__file__).with_name('closure_python.py')),'-m','pytest','-q','-ra','--basetemp',str(T/'pytest'),*sys.argv[2:]]
started=datetime.now(timezone.utc).isoformat()
diff=subprocess.check_output(['git','diff','--binary'],cwd=P,stderr=subprocess.DEVNULL)
(R/'working.diff').write_bytes(diff)
proc=subprocess.run(args,cwd=P,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
(R/'tests.log').write_text(proc.stdout+proc.stderr,encoding='utf-8')
status={'started_at_utc':started,'finished_at_utc':datetime.now(timezone.utc).isoformat(),'exit_code':proc.returncode,'command':args,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip(),'diff_sha256':hashlib.sha256(diff).hexdigest(),'real_credentials_available':False}
(R/'status.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
print((proc.stdout+proc.stderr)[-6000:])
print(json.dumps(status))
raise SystemExit(proc.returncode)
