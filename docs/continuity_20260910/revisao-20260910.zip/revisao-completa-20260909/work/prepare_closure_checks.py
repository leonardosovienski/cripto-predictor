from pathlib import Path

work = Path(__file__).resolve().parent
old = r'C:\Cripto\auditoria-ampliada-20260910'
new = r'C:\Cripto\fechamento-revisao-20260910'
for source, target in (
    ('isolated_python.py', 'closure_python.py'),
    ('run_expansion_checks.py', 'run_closure_checks.py'),
):
    text = (work / source).read_text(encoding='utf-8').replace(old, new)
    text = text.replace('isolated_python.py', 'closure_python.py')
    (work / target).write_text(text, encoding='utf-8')
print('closure launchers prepared; frozen launchers unchanged')
text = (work / 'targeted.py').read_text(encoding='utf-8')
text = text.replace(r'C:\Cripto\pesquisa-20260909', new)
text = text.replace("'python','-m'", "'python',str(Path(__file__).with_name('closure_python.py')),'-m'")
text = text.replace("for k in ('DATA'", "env['PREDICTOR_OPS_STATE_DIR']=str(T/'state')\nfor k in ('DATA'")
(work / 'closure_targeted.py').write_text(text, encoding='utf-8')
