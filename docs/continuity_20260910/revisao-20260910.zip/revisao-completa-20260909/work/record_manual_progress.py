from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

P = Path(r'C:\Cripto\pesquisa-20260909')
R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
M = R / 'manual_dependencies'
D = P / 'docs/manual_dependencies_20260910'
sys.path.insert(0, str(P))
from scripts.carry_forward_registration import inspect, load
from scripts.audit_market_calendar import classify
from scripts.research_io import strict_json

def read(path):
    return json.loads(path.read_bytes())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

calendar = classify(read(D/'gap_input.json'), read(D/'market_events.json'))
assert calendar['explained_nontrading_days'] == 542 and calendar['unexplained_days'] == 0
assert digest(D/'gap_input.json') == digest(Path(r'C:\Cripto\operacao\relatorios\FECHAMENTO_PENDENCIAS_20260909\altcoin_gap_probe_results.json'))
bundle = Path(r'C:\Cripto\operacao\dados\carry-manual-20260912-v2')
status = inspect(bundle)
assert status['phase'] == 'WAITING' and status['ledger_rows'] == 0
assert not (bundle/'observations').exists()
assert (bundle/'registration.json').read_bytes() == (D/'carry_registration.json').read_bytes()
assert (bundle/'protocol.json').read_bytes() == (D/'carry_protocol.json').read_bytes()
owner = P/'docs/NEXT_CHAT_PROMPT.md'
assert owner.read_bytes() == (R/'manual_target01/initial_next_chat_prompt.md').read_bytes()
for file in D.glob('*.json'):
    strict_json(file.read_bytes())
summary = {
    'updated_at_utc': datetime.now(timezone.utc).isoformat(),
    'base_sha': '9b8de9802c61570610bc0b212bdb0bb4c4e1d643',
    'head': subprocess.check_output(['git','rev-parse','HEAD'], cwd=P, text=True).strip(),
    'excluded_by_owner': 'branch security and protection settings',
    'calendar': {k:v for k,v in calendar.items() if k != 'results'},
    'coingecko_fix': 'OHLCV intraday rejected before network; daily adapter preserved',
    'carry_status': status,
    'carry_directory': str(bundle),
    'original_window': 'MISSED_ENTRY; preserved original ledger contains only PREFLIGHT',
    'earlier_preparation_preserved': {'directory': r'C:\Cripto\operacao\dados\carry-manual-20260912', 'reason': 'Superseded before any observation to add raw-source and clock integrity checks to read-only status; original registration bytes preserved'},
    'llm_evaluation': 'Draft design only, not activated; executor freeze and future sample still required',
    'aave': read(M/'aave_onfinality.json'),
    'h5': read(M/'h5_git_history.json'),
    'github_releases': {'queried_at_utc': '2026-09-10', 'count': 0},
    'github_artifacts': {'examined': False, 'reason': 'Connector endpoint unsupported (HTTP 400); not a finding that no artifacts exist'},
    'owner_prompt_preserved': True,
    'frozen_carry_code_and_runtime_verified': True,
    'observations_collected': 0,
    'financial_orders': 0,
    'schedulers_activated': 0,
    'new_ingestion_budget_units_consumed': 1,
    'economic_improvement_demonstrated': False,
    'documentation_hashes': {x.name:digest(x) for x in D.iterdir() if x.is_file()},
    'validation': 'Pending final code validation and integration',
    'intermediate_validation_note': 'manual_final01 began before read-only carry status hardening; never attribute that run to final source hashes. manual_final02 validates the final source.',
}
(M/'result.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
(M/'carry_status.json').write_text(json.dumps(status, indent=2)+'\n',encoding='utf-8')
print(json.dumps({'calendar_explained':542,'carry':status['phase'],'owner_prompt_preserved':True}))
