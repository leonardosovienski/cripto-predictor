import hashlib
import json
import shutil
import sqlite3
import subprocess
import zipfile
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(r'C:\Cripto')
P = ROOT / 'pesquisa-20260909'
F = ROOT / 'operacao/relatorios/REVISAO_COMPLETA_20260909/organization_20260910'
B = ROOT / 'backups/operational-20260910-files-audit'
B.mkdir(exist_ok=False)
CMD = str(ROOT / 'CRIPTO.cmd')
DB = ROOT / 'operacao/saidas/feature_store.db'
QUOTA = ROOT / 'operacao/dados/api_guard_budget.db'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def state(path):
    with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as conn:
        integrity = conn.execute('PRAGMA integrity_check').fetchall()
        assert integrity == [('ok',)]
        tables = [x[0] for x in conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        result = {}
        for table in tables:
            identifier = '"' + table.replace('"', '""') + '"'
            rows = conn.execute('SELECT * FROM ' + identifier).fetchall()
            digest = hashlib.sha256('\n'.join(sorted(map(repr, rows))).encode()).hexdigest()
            result[table] = {'rows': len(rows), 'content_sha256': digest}
        schema = conn.execute('SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name').fetchall()
        return {'tables': result, 'schema_sha256': hashlib.sha256(repr(schema).encode()).hexdigest(), 'integrity': 'ok'}

before = {'feature_store': state(DB), 'api_budget': state(QUOTA)}
checks = []
restore = ROOT / 'operacao/temporarios/restore-feature-store-20260910-files-audit'
commands = [
    ['create', '--database', str(DB), '--output', str(B / 'feature_store')],
    ['verify', '--backup', str(B / 'feature_store')],
    ['restore', '--backup', str(B / 'feature_store'), '--destination', str(restore)],
]
for args in commands:
    proc = subprocess.run([CMD, 'python', '-m', 'scripts.feature_store_backup', *args], cwd=P, capture_output=True, text=True, encoding='utf-8')
    (F / f'backup_{args[0]}.log').write_text(proc.stdout + proc.stderr, encoding='utf-8')
    checks.append({'command': args, 'exit_code': proc.returncode})
    assert proc.returncode == 0, args[0]
    print(json.dumps(checks[-1]), flush=True)
assert state(B / 'feature_store/feature_store.db') == before['feature_store']
assert state(restore / 'output/feature_store.db') == before['feature_store']
assert sha(B / 'feature_store/feature_store.db') == sha(restore / 'output/feature_store.db')
with sqlite3.connect(QUOTA.as_uri() + '?mode=ro', uri=True) as source:
    with sqlite3.connect(B / 'api_guard_budget.db') as target:
        source.backup(target)
assert state(B / 'api_guard_budget.db') == before['api_budget']
assert {'feature_store': state(DB), 'api_budget': state(QUOTA)} == before
manifest = {'at_utc': datetime.now(UTC).isoformat(), 'feature_store': before['feature_store'], 'api_budget': before['api_budget'],
            'files': {str(x.relative_to(B)): {'bytes': x.stat().st_size, 'sha256': sha(x)} for x in B.rglob('*') if x.is_file()},
            'quota_restore_warning': 'Preserve current day consumption; never restore an earlier budget to bypass quotas.',
            'scope': 'Feature Store and API budget only, local same-disk backup; private config and full research data remain in original locations.'}
(B / 'MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
result = {'status': 'PASS', 'at_utc': manifest['at_utc'], 'backup': str(B), 'restore_test': str(restore), 'checks': checks,
          'all_table_contents_and_schema_match': True, 'live_databases_unchanged': True, 'network_calls': 0,
          'counts': {t: v['rows'] for t, v in before['feature_store']['tables'].items()}, 'manifest_sha256': sha(B / 'MANIFEST.json')}
(F / 'backup_verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result), flush=True)

# Restrict removal to explicit regenerable cache roots. No frozen worktree,
# observer, private configuration, raw data, report or migration file is removed.
targets = [ROOT / '.pytest_cache', P / '.pytest_cache', P / '.ruff_cache']
archive = B / 'removed-caches.zip'
entries, roots = [], []
for target in targets:
    if not target.exists():
        continue
    resolved = target.resolve(strict=True)
    assert resolved == target and resolved.is_relative_to(ROOT)
    assert target.name in ('.pytest_cache', '.ruff_cache')
    assert target.parent in (ROOT, P)
    for path in [target, *target.rglob('*')]:
        assert not path.is_symlink() and not path.is_junction(), str(path)
        assert path.resolve().is_relative_to(resolved), str(path)
        if path.is_file():
            entries.append({'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size, 'sha256': sha(path)})
    roots.append(str(target))
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for entry in entries:
        output.write(ROOT / entry['path'], entry['path'].replace('\\', '/'))
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    for entry in entries:
        assert hashlib.sha256(saved.read(entry['path'].replace('\\', '/'))).hexdigest() == entry['sha256']
for name in roots:
    target = Path(name)
    assert target.resolve(strict=True) == target and target.parent in (ROOT, P)
    shutil.rmtree(target)
cleanup = {'at_utc': datetime.now(UTC).isoformat(), 'removed_roots': roots, 'files': entries, 'bytes_removed': sum(x['bytes'] for x in entries),
           'archive': str(archive), 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size, 'restorable': True,
           'preserved': ['original migration package', 'restaurado-20260908', 'all worktree code and environments', 'frozen LLM executor', 'raw data and ledgers', 'private configuration', 'chat backup', 'reports'],
           'note': 'Only transient tool caches were removed. Later tools may recreate empty/new caches.'}
(F / 'cleanup.json').write_text(json.dumps(cleanup, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in cleanup.items() if k != 'files'}), flush=True)
