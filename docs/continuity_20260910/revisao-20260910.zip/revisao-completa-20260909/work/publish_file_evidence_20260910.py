import hashlib
import json
from pathlib import Path

R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
F = R / 'organization_20260910'
P = Path(r'C:\Cripto\revisao-arquivos-20260910')
E = P / 'docs/evidence/file_document_audit_20260910'
E.mkdir(exist_ok=True)

def write(name, value):
    (E / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

for src, dest in [('root_inventory.json', 'root_inventory.json'), ('normalized_baseline_markdown_summary.json', 'markdown_baseline.json'), ('normalized_baseline_markdown_historical_links.json', 'historical_links.json'), ('backup_verification.json', 'backup_verification.json')]:
    write(dest, json.loads((F / src).read_bytes()))
for name in ('migration_archive_verification.json', 'frozen_runtime_validation.json', 'redundant_worktree.json', 'original_serial_prefix.json'):
    source = F / name
    if source.exists() and source.stat().st_size:
        write(name, json.loads(source.read_bytes()))
cleanup = json.loads((F / 'cleanup.json').read_bytes())
cleanup['files_removed'] = len(cleanup.pop('files'))
cleanup['scope'] = 'Cache removal only; the subsequent redundant worktree removal is recorded separately.'
cleanup['preserved'] = ['all unique source code', 'original migration package', 'restaurado-20260908', 'frozen LLM executor and environments', 'raw data and ledgers', 'private configuration', 'chat backup', 'reports']
write('cleanup.json', cleanup)
original = F / 'original_files_verification.private.json'
if original.exists():
    value = json.loads(original.read_bytes())
    assert value['status'] == 'PASS', 'Original file verification must pass before publication.'
    write('original_files_verification.json', value)
for name in ('verify_original_files_20260910.py', 'finish_original_verification_20260910.py', 'verify_migration_archive_20260910.py'):
    (E / (name + '.source')).write_bytes((R / 'work' / name).read_bytes())
(E / 'README.md').write_text('''# Evidências da conferência de arquivos de 10/09/2026

Leia [a conferência e seus limites](../../CONFERENCIA_ARQUIVOS_20260910.md). Os JSONs registram o inventário agregado, verificação do pacote original, destinos históricos, backup testado e caches retirados. O inventário individual completo, o backup dos bancos e a cópia privada do chat permanecem em `C:\\Cripto`, fora do Git.

`historical_links.json` explica as 103 referências cujos destinos dependem da pasta de origem. Seus arquivos existem localmente, mas não estão todos hospedados junto da cópia Markdown no Git. Não reescrevemos os bytes das evidências congeladas para alterar sua base.

O manifesto desta pasta vincula somente os arquivos aqui listados. A validação de CI e a integração final são registradas no PR e no relatório vivo; não se presume que resultados de um commit validem outro.
''', encoding='utf-8')
manifest = {'format_version': 1, 'scope': 'Selected public audit evidence; full filesystem inventory, data and private chat remain local.',
            'files': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(E.iterdir()) if p.is_file() and p.name != 'manifest.json'}}
write('manifest.json', manifest)
attributes = P / '.gitattributes'
line = '/docs/evidence/file_document_audit_20260910/** -text\n'
body = attributes.read_text(encoding='utf-8')
if line.strip() not in body:
    attributes.write_text(body.rstrip() + '\n' + line, encoding='utf-8')
print(json.dumps({'files': len(manifest['files']), 'original_verification_available': original.exists()}))
