from datetime import UTC, datetime
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import subprocess

P=Path(r'C:\Cripto\pesquisa-20260909')
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
E=P/'docs/evidence/dependency_execution_20260910'
F=Path(r'C:\Cripto\operacao\dados\llm-paired-manual-20260912-v2')
def read(p):return json.loads(p.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
manifest=read(E/'manifest.json')
names=[(E/name).relative_to(P).as_posix() for name in manifest['files']]
raw=subprocess.check_output(['git','cat-file','--batch'],input=''.join('HEAD:'+n+'\n' for n in names).encode(),cwd=P)
blobs={}
offset=0
for name in names:
    stop=raw.index(b'\n',offset)
    size=int(raw[offset:stop].split()[2])
    blobs[name]=raw[stop+1:stop+1+size]
    offset=stop+1+size+1
for name,digest in manifest['files'].items():
    path=E/name
    assert sha(path.read_bytes())==digest,name
    relative=path.relative_to(P).as_posix()
    blob=blobs[relative]
    assert sha(blob)==digest,relative
for name in ('protocol.json','registration.json'):
    assert (F/name).read_bytes()==(E/('llm_'+name)).read_bytes()
assert (P/'docs/NEXT_CHAT_PROMPT.md').read_bytes()==(R/'executors_baseline01/initial_next_chat_prompt.md').read_bytes()
rows=read(E/'aave/history.json')
original=read(E/'aave/calculation.json')
for case in original['cases']:
    ideal=Fraction(case['capital_usdc'])*(Fraction(int(rows[-1]['normalized_income_ray']),int(rows[0]['normalized_income_ray']))-1)
    assert 0 <= float(ideal)-float(case['gross_interest_usdc']) < 0.000003
    assert abs(float(case['partial_remainder_usdc'])-float(case['gross_interest_usdc'])+case['entry_exit_cost_scenario_usdc']) < 1e-9
checks=[]
for row in rows:
    stamp=int(datetime.fromisoformat(row['boundary_utc']).timestamp())
    assert row['timestamp'] <= stamp < row['successor']['timestamp']
    assert row['number']+1==row['successor']['number']
    assert row['hash']==row['successor']['parent_hash']
    checks.append(row['number'])
result={'checked_at':datetime.now(UTC).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip(),
        'manifest_files_verified_in_worktree_and_commit':len(manifest['files']),
        'owner_prompt_preserved':True,'llm_registration_matches_local':True,
        'aave_original_cases_independent_fraction_check':len(original['cases']),
        'weekly_boundaries_verified':len(checks)}
(R/'executor_dependencies/publication_verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
