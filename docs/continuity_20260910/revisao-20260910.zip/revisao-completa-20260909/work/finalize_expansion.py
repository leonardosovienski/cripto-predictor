from pathlib import Path
from datetime import UTC, datetime
import hashlib
import importlib.metadata
import json
import sqlite3
import subprocess
import xml.etree.ElementTree as ET

R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
P=Path(r'C:\Cripto\pesquisa-20260909')
W=Path(r'C:\Cripto\auditoria-ampliada-20260910')
def read(p):return json.loads((R/p).read_bytes())
def git(*args,cwd=P):return subprocess.check_output(['git',*args],cwd=cwd).decode().strip()
def write(p,obj):(R/p).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
ci=read('expansion_ci_main.json')
assert ci['four_jobs_passed'] and ci['head']=='a9179270a55a31caa0f9bfc251d373c53034ebb1'
post=read('postmerge_expansion01/validation.json')
assert post.get('finished_at_utc') and all(c['exit_code']==0 for c in post['checks'])
cases=ET.parse(R/'postmerge_expansion01/tests.xml').getroot().findall('.//testcase')
failed=sum(c.find('failure') is not None or c.find('error') is not None for c in cases)
skips=sum(c.find('skipped') is not None for c in cases)
passed=len(cases)-failed-skips
assert passed==1504 and failed==0 and skips==1
assert git('rev-parse','HEAD')==ci['head']
assert git('ls-remote','origin','refs/heads/main').split()[0]==ci['head']
assert git('status','--porcelain')=='M docs/NEXT_CHAT_PROMPT.md'
assert hashlib.sha256((P/'docs/NEXT_CHAT_PROMPT.md').read_bytes()).hexdigest()=='8969db38ef9a3ec29ee16a780b9572ec9f7d7808cabc9bac17a319616b47fe20'
assert git('rev-parse','HEAD^{tree}')==git('rev-parse','HEAD^{tree}',cwd=W)
from GarimpoInvestimentos.core.api_guard import _BUDGET_DB
from GarimpoInvestimentos.dpl.feature_engineering import DAILY_FEATURE_VERSION
from GarimpoInvestimentos.plugin import PLUGIN
with sqlite3.connect(f'{_BUDGET_DB.as_uri()}?mode=ro',uri=True) as conn:
    budget=conn.execute('SELECT bucket,stage,guard_key,used FROM api_budget').fetchall()
expected=read('expansion_budget_incident/result.json')['after']
assert sorted(map(tuple,budget))==sorted(map(tuple,expected))
with sqlite3.connect('file:C:/Cripto/operacao/saidas/feature_store.db?mode=ro',uri=True) as conn:
    versions=conn.execute('SELECT feature_version,COUNT(*) FROM market_snapshots GROUP BY feature_version').fetchall()
direct=json.loads(importlib.metadata.distribution('cripto-predictor').read_text('direct_url.json'))
assert 'pesquisa-20260909' in direct['url'] and direct['dir_info']['editable']
operational=read('expansion_operational.json')
operational.update(at_utc=datetime.now(UTC).isoformat(),postmerge_local_checks='passed',postmerge_passed=passed,postmerge_skipped=skips,editable_installation=direct['url'],api_budget_preserved_by_final_tests=True,feature_version=DAILY_FEATURE_VERSION,market_snapshot_versions=versions,live_snapshot_refresh='requires next normal ingestion after current UTC reservation expires; no stale data promoted',plugin={k:v for k,v in PLUGIN.capabilities().items() if k in ('scientific_status','capital_permission')},manual_llm_status=read('expansion_llm_status_v3_after_sync.json')['counts'],manual_carry_phase=read('expansion_carry_status_after_merge.json')['phase'])
write('expansion_operational.json',operational)
integration=read('expansion_integration.json')
integration.update(summary='PR #115 integrado em a917927 e conferido no main: quatro jobs aprovados antes e depois do merge; 1.504 testes locais aprovados, um skip Windows e zero falhas antes e após integração. Prompt do dono e evidências congeladas preservados. Código integrado e validação de engenharia concluídos; dependências de evidência e renovação normal da quota permanecem explícitas.',main_four_jobs_passed=True,postmerge_local=f'{passed} passed, {skips} skipped, {failed} failed',completed_at_utc=datetime.now(UTC).isoformat())
write('expansion_integration.json',integration)
print(json.dumps({'integration':integration,'operational':operational},ensure_ascii=False))
