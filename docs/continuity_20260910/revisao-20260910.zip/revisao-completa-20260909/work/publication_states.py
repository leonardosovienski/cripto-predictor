import hashlib
import json
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

import recover_operational_snapshot as snap

R = snap.R
L = R / 'publication_chat_20260910'
P = snap.P
W = Path(r'C:\Cripto\auditoria-ampliada-20260910')

def git(path, *args):
    return subprocess.check_output(['git', *args], cwd=path, text=True).strip()

def status(name, command):
    result = subprocess.run(command, cwd=P, capture_output=True, text=True, encoding='utf-8')
    assert result.returncode == 0, name
    value = json.loads(result.stdout)
    with (L / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
    return value

prepared = json.loads((R / 'remaining_six_20260910/snapshot/prepared.json').read_bytes())
applied = json.loads((R / 'remaining_six_20260910/snapshot/applied.json').read_bytes())
assert snap.state(snap.DB, applied['snapshot_id']) == prepared['before']
assert snap.state(snap.BUDGET) == prepared['budget_before']
assert snap.sha(P / 'docs/NEXT_CHAT_PROMPT.md') == '8969db38ef9a3ec29ee16a780b9572ec9f7d7808cabc9bac17a319616b47fe20'
assert git(W, 'rev-parse', 'HEAD') == '595f1203475d04b01966ac3471bbafd6770dbb4d'
assert not git(W, 'status', '--porcelain')
carry = status('carry_status_after.json', [sys.executable, '-m', 'scripts.carry_forward_registration', '--directory',
    r'C:\Cripto\operacao\dados\carry-manual-20260912-v2'])
llm = status('llm_status_after.json', [sys.executable, str(R / 'work/isolated_python.py'), '-m', 'scripts.paired_llm', '--directory',
    r'C:\Cripto\operacao\dados\llm-paired-manual-20260912-v3'])
aave = status('aave_status_after.json', [sys.executable, str(R / 'work/compare_aave_second_source.py')])
assert carry['phase'] == 'WAITING' and carry['ledger_rows'] == carry['orders_sent'] == 0
assert llm['counts'] == {'FUTURE': 84}
E = P / 'docs/evidence/remaining_dependencies_20260910'
manifest = json.loads((E / 'manifest.json').read_bytes())
for name, digest in manifest['files'].items():
    relative = (E / name).relative_to(P).as_posix()
    assert hashlib.sha256((E / name).read_bytes()).hexdigest() == digest, name
    assert hashlib.sha256(subprocess.check_output(['git', 'show', 'HEAD:' + relative], cwd=P)).hexdigest() == digest, name
record = {'at': datetime.now(UTC).isoformat(), 'status': 'PASS', 'head': git(P, 'rev-parse', 'HEAD'),
          'operational_status': git(P, 'status', '--porcelain'), 'owner_prompt_preserved': True,
          'frozen_llm_checkout_preserved': True, 'old_database_rows_preserved': True, 'budget_preserved': True,
          'manifest_files_verified_in_checkout_and_git': len(manifest['files']),
          'llm_future_slots': 84, 'carry_phase': carry['phase'], 'network_calls': 0}
with (L / 'state_after.json').open('x', encoding='utf-8') as stream:
    json.dump(record, stream, ensure_ascii=False, indent=2)
print(json.dumps(record))
