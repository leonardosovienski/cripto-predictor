from pathlib import Path
P=Path(r'C:\Cripto\auditoria-ampliada-20260910')
def edit(name,old,new):
    p=P/name;s=p.read_text(encoding='utf-8');assert old in s,(name,old[:60]);p.write_text(s.replace(old,new),encoding='utf-8')

edit('GarimpoInvestimentos/observation_quality.py','if point.ingested_at is not None\n','if point.ingested_at is not None and point.event_at is not None\n')
edit('GarimpoInvestimentos/trading/store.py','from datetime import UTC, datetime','from datetime import UTC, datetime, timedelta')
edit('GarimpoInvestimentos/trading/store.py','    return int(ensure_utc(value, "timestamp").timestamp() * 1_000_000)','    delta = ensure_utc(value, "timestamp") - datetime(1970,1,1,tzinfo=UTC)\n    return (delta.days * 86400 + delta.seconds) * 1_000_000 + delta.microseconds')
edit('GarimpoInvestimentos/trading/store.py','datetime.fromtimestamp(value / 1_000_000, tz=UTC).isoformat() if value is not None else None','(datetime(1970,1,1,tzinfo=UTC) + timedelta(microseconds=value)).isoformat() if value is not None else None')
edit('GarimpoInvestimentos/analyzers/score_engine.py','def calculate_final_score','import math\n\ndef calculate_final_score')
edit('GarimpoInvestimentos/analyzers/score_engine.py','    return round(min(max(score, 0), 100), 2)','    if not math.isfinite(score):\n        raise ValueError("score deve ser finito")\n    return round(min(max(score, 0), 100), 2)')
edit('GarimpoInvestimentos/analyzers/score_engine.py','    has_trend =','    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for k,v in indicadores.items() if k in {"preco_vs_sma200_pct","macd_histogram","rsi_14"}):\n        return None\n    has_trend =')
edit('GarimpoInvestimentos/analyzers/score_engine.py','votes += 1 if indicadores["preco_vs_sma200_pct"] > 0 else -1','votes += (indicadores["preco_vs_sma200_pct"] > 0) - (indicadores["preco_vs_sma200_pct"] < 0)')
edit('GarimpoInvestimentos/analyzers/score_engine.py','votes += 1 if indicadores["macd_histogram"] > 0 else -1','votes += (indicadores["macd_histogram"] > 0) - (indicadores["macd_histogram"] < 0)')
edit('GarimpoInvestimentos/analyzers/prefilter.py','from dataclasses import dataclass','from dataclasses import dataclass\nimport math')
edit('GarimpoInvestimentos/analyzers/prefilter.py','if not isinstance(volume, (int, float)) or volume <','if isinstance(volume,bool) or not isinstance(volume, (int, float)) or not math.isfinite(volume) or volume <')
edit('GarimpoInvestimentos/analyzers/prefilter.py','if not isinstance(change_7d, (int, float)):','if isinstance(change_7d,bool) or not isinstance(change_7d, (int, float)) or not math.isfinite(change_7d):')
i='GarimpoInvestimentos/analyzers/indicators.py'
edit(i,'    if avg_loss == 0:\n        return 100.0','    if avg_loss == 0:\n        return 50.0 if avg_gain == 0 else 100.0')
edit(i,'def sma(','''def _validate(prices: list[float], *periods: int) -> None:
    if any(isinstance(p,bool) or not isinstance(p,int) or p < 1 for p in periods):
        raise ValueError("period must be a positive integer")
    if any(isinstance(p,bool) or not isinstance(p,(int,float)) or not math.isfinite(p) for p in prices):
        raise ValueError("prices must be finite")


def sma(''')
edit(i,'    if len(prices) < period:', '    _validate(prices, period)\n    if len(prices) < period:')
edit(i,'    if len(prices) < period + 1:','    _validate(prices, period)\n    if len(prices) < period + 1:')
edit(i,'    e_fast = _ema_series(prices, fast)','    _validate(prices,fast,slow,signal)\n    if fast >= slow:\n        raise ValueError("MACD requires fast < slow")\n    e_fast = _ema_series(prices, fast)')
edit(i,'    window = prices[-period:]','    if not math.isfinite(mult) or mult <= 0:\n        raise ValueError("bollinger mult must be positive and finite")\n    window = prices[-period:]')

c='GarimpoInvestimentos/core/cache.py'
edit(c,'from typing import Any','from typing import Any\nfrom pathlib import Path\nfrom GarimpoInvestimentos.durable_io import atomic_write, file_lock, strict_json_loads')
p=P/c;s=p.read_text(encoding='utf-8');a=s.index('    now_utc =',s.index('def save_cache'));s=s[:a]+'''    path = Path(CACHE_PATH)
    with file_lock(path):
        if path.exists():
            original = strict_json_loads(path.read_text(encoding="utf-8"))
            if not isinstance(original,dict):
                raise ValueError("invalid cache root; preserve before recovery")
        # Merge concurrent writes under the lock. Expired entries are ephemeral.
        merged = load_cache()
        now_utc = datetime.now(UTC).isoformat()
        for key, entry in cache.items():
            if not isinstance(entry,dict):
                raise ValueError("invalid cache entry")
            merged[key] = {"cached_at": now_utc, **entry}
        atomic_write(path, (json.dumps(merged,ensure_ascii=False,indent=2,allow_nan=False)+"\\n").encode("utf-8"))
''';p.write_text(s,encoding='utf-8')

c='GarimpoInvestimentos/collectors/discovery.py'
edit(c,'from predictor_core.net import','import math\n\nfrom predictor_core.net import')
edit(c,'    trending = set(trending_ids)','''    if isinstance(top_n,bool) or not isinstance(top_n,int) or top_n < 0 or not math.isfinite(min_volume_usd) or min_volume_usd < 0:
        raise ValueError("invalid candidate count or minimum volume")
    trending = set(trending_ids)
    seen = set()''')
edit(c,'        if not coin_id:\n            continue','''        if not isinstance(coin_id,str) or not coin_id or coin_id in seen:
            continue
        values = [row.get(k) for k in ("current_price","total_volume","price_change_percentage_7d_in_currency","price_change_percentage_24h_in_currency")]
        if any(v is not None and (isinstance(v,bool) or not isinstance(v,(float,int)) or not math.isfinite(v)) for v in values):
            continue
        if values[0] is not None and values[0] <= 0:
            continue
        seen.add(coin_id)''')

c='GarimpoInvestimentos/dpl/providers/ccxt_base.py'
edit(c,'        self._symbol_map = symbol_map','        self._symbol_map = dict(symbol_map)')
edit(c,'        if limit < 1:','        if isinstance(limit,bool) or not isinstance(limit,int) or limit < 1:')
edit(c,'        points = []\n','        points = []\n        seen = set()\n')
edit(c,'            ts = datetime.fromtimestamp(ts_ms / 1000, tz=UTC)','''            if isinstance(ts_ms,bool) or not isinstance(ts_ms,int) or ts_ms < 0:
                raise ValueError("ccxt: invalid timestamp")
            if ts_ms in seen:
                raise ValueError("ccxt: duplicate timestamp")
            seen.add(ts_ms)
            ts = datetime.fromtimestamp(ts_ms / 1000, tz=UTC)''')
edit(c,'            points.append(\n','''            if min(kw["open"],kw["high"],kw["low"],kw["close"]) <= 0 or kw["volume"] < 0 or not kw["low"] <= min(kw["open"],kw["close"]) <= max(kw["open"],kw["close"]) <= kw["high"]:
                raise ValueError("ccxt: invalid OHLCV range")
            points.append(
''')
c='GarimpoInvestimentos/dpl/providers/coingecko.py'
edit(c,'        if limit < 1:','        if isinstance(limit,bool) or not isinstance(limit,int) or limit < 1:')
edit(c,'        volumes = {int(ts): v for ts, v in data.get("total_volumes", [])}','''        volumes = {}
        for ts, value in data.get("total_volumes", []):
            if ts in volumes and volumes[ts] != value:
                raise ValueError("coingecko: conflicting duplicate volume")
            volumes[ts] = value''')

c='GarimpoInvestimentos/dpl/alignment.py'
edit(c,'            s = sorted(series, key=_available_at)','''            # Prefix winners by observation time, then newest usable vintage.
            # A newly received revision of an OLD observation must not displace
            # a more recent observation from the as-of feature.
            ordered = sorted(series, key=lambda point: (_available_at(point), point.timestamp))
            s = []
            winner = None
            for point in ordered:
                if winner is None or (point.timestamp, _available_at(point)) >= (winner.timestamp, _available_at(winner)):
                    winner = point
                s.append(winner)''')
edit(c,'prepared[name] = (s, [_available_at(x) for x in s])','prepared[name] = (s, [_available_at(x) for x in ordered])')
edit(c,'        max_staleness = max_staleness or {}','''        max_staleness = max_staleness or {}
        if any(lag < timedelta(0) for lag in max_staleness.values()):
            raise ValueError("max_staleness must not be negative")''')

c='GarimpoInvestimentos/observation_reporting.py'
edit(c,'from GarimpoInvestimentos.core.paths import FEATURE_STORE_DB','from GarimpoInvestimentos.core.paths import FEATURE_STORE_DB\nfrom GarimpoInvestimentos.durable_io import atomic_write, file_lock')
edit(c,'json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False)','json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)')
edit(c,'''    if path.exists() and path.read_text(encoding="utf-8") != encoded:
        raise ValueError(f"immutable report already exists with other content: {path}")
    path.write_text(encoded, encoding="utf-8")''','''    with file_lock(path):
        if path.exists():
            if path.read_text(encoding="utf-8") != encoded:
                raise ValueError(f"immutable report already exists with other content: {path}")
            return
        atomic_write(path, encoded.encode("utf-8"))''')
edit(c,'        coverage = _coverages(cards)','''        coverage = _coverages(cards)
        expected_dates = {(start + timedelta(days=i)).date() for i in range(7)}
        observed_dates = {datetime.fromisoformat(card["window_start"]).date() for card in cards}
        complete = expected_dates == observed_dates and len(cards) == 7''')
edit(c,'            "weekly_coverage_passed": bool(coverage)','            "complete_daily_scorecards": complete,\n            "weekly_coverage_passed": complete and bool(coverage)')
edit(c,'            "duration": duration_days >= required_days,','''            "duration": duration_days >= required_days,
            "complete_daily_scorecards": len({datetime.fromisoformat(card["window_start"]).date() for card in cards}) >= int(duration_days),''')
edit(c,'        with FeatureStore', '        with FeatureStore') if False else None

c='GarimpoInvestimentos/watchdog.py'
edit(c,'(ROOT / "logs").glob','LOG.parent.glob')
edit(c,'hoje_iso = datetime.now().strftime','hoje_iso = datetime.now(UTC).strftime')
edit(c,'        ALERTA.write_text(texto, encoding="utf-8")','        ALERTA.parent.mkdir(parents=True, exist_ok=True)\n        ALERTA.write_text(texto, encoding="utf-8")')
edit(c,'log(f"AVISO: webhook de alerta falhou ({e}) — alerta segue no arquivo")','log(f"AVISO: webhook de alerta falhou ({type(e).__name__}) — alerta segue no arquivo")')
edit(c,'    except ValueError:\n        idade_dias = None','    except (ValueError, TypeError):\n        idade_dias = None')

c='GarimpoInvestimentos/phase1_watchdog.py'
edit(c,'import os\n','import os\nimport sqlite3\nfrom contextlib import closing\n')
edit(c,'from GarimpoInvestimentos.dpl.feature_store import FeatureStore','from GarimpoInvestimentos.health_io import read_heartbeat, age_seconds\nfrom GarimpoInvestimentos.trading.contracts import ensure_utc')
a='''    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None'''
edit(c,a,'    return read_heartbeat(path)')
edit(c,'    stamp = now or datetime.now(UTC)','    stamp = ensure_utc(now or datetime.now(UTC), "now")')
edit(c,'            age_hours = (stamp - datetime.fromisoformat(finished)).total_seconds() / 3600\n            if age_hours > STALE_AFTER_HOURS:','''            elapsed = age_seconds(finished, stamp)
            age_hours = elapsed / 3600 if elapsed is not None else -1
            if age_hours < 0:
                violations.append("phase1_heartbeat_invalid_time")
            elif age_hours > STALE_AFTER_HOURS:''')
edit(c,'        with FeatureStore(db_path) as store:\n            row = store._conn.execute(', '        with closing(sqlite3.connect(db_path.resolve().as_uri() + "?mode=ro", uri=True)) as connection:\n            row = connection.execute(')
edit(c,'            recent = store._conn.execute(', '            recent = connection.execute(')
edit(c,'            if age_hours > STALE_AFTER_HOURS:\n                violations.append(f"no_real_prediction_in_', '            if age_hours < 0:\n                violations.append("real_prediction_in_future")\n            elif age_hours > STALE_AFTER_HOURS:\n                violations.append(f"no_real_prediction_in_')

c='GarimpoInvestimentos/observation_watchdog.py'
edit(c,'import os\n','import os\nimport sqlite3\nfrom contextlib import closing\n')
edit(c,'from GarimpoInvestimentos.dpl.feature_store import FeatureStore','from GarimpoInvestimentos.health_io import read_heartbeat, age_seconds\nfrom GarimpoInvestimentos.trading.contracts import ensure_utc')
edit(c,'    stamp = now or datetime.now(UTC)','    stamp = ensure_utc(now or datetime.now(UTC), "now")')
edit(c,'    root = state_root or Path(os.environ["PREDICTOR_OPS_STATE_DIR"])','    configured = os.environ.get("PREDICTOR_OPS_STATE_DIR")\n    root = state_root or (Path(configured) if configured else FEATURE_STORE_DB.parent / "unconfigured-ops")')
edit(c,'    if heartbeat_path.exists():\n        heartbeat = json.loads(heartbeat_path.read_text(encoding="utf-8")))','') if False else None
edit(c,'    if heartbeat_path.exists():\n        heartbeat = json.loads(heartbeat_path.read_text(encoding="utf-8"))','    heartbeat = read_heartbeat(heartbeat_path)\n    if heartbeat is not None:')
edit(c,'if not finished or stamp - datetime.fromisoformat(finished) > timedelta(hours=36):','if (elapsed := age_seconds(finished, stamp)) is None or not 0 <= elapsed <= 36 * 3600:')
edit(c,'    if live_path.exists():\n        live = json.loads(live_path.read_text(encoding="utf-8"))','    live = read_heartbeat(live_path)\n    if live is not None:')
edit(c,'if not heartbeat_at or stamp - datetime.fromisoformat(heartbeat_at) > timedelta(minutes=10):','if (elapsed := age_seconds(heartbeat_at, stamp)) is None or not 0 <= elapsed <= 600:')
edit(c,'        with FeatureStore(db_path) as store:\n            rows = store._conn.execute(', '        with closing(sqlite3.connect(db_path.resolve().as_uri() + "?mode=ro", uri=True)) as connection:\n            connection.row_factory = sqlite3.Row\n            rows = connection.execute(')
edit(c,'        if "QUARANTINED" in states.values():\n            violations.append("source_quarantined")','        if "QUARANTINED" in states.values():\n            violations.append("source_quarantined")\n        elif any(state != "HEALTHY" for state in states.values()):\n            violations.append("source_degraded")')

(P/'GarimpoInvestimentos/health_io.py').write_text('''"""Read-only heartbeat decoding and strict clock validation for health reports."""
from datetime import datetime
from pathlib import Path
from GarimpoInvestimentos.durable_io import strict_json_loads
from GarimpoInvestimentos.trading.contracts import ensure_utc

def read_heartbeat(path: Path) -> dict | None:
    try:
        value = strict_json_loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value,dict) else None
    except (OSError,ValueError):
        return None

def age_seconds(value: object, now: datetime) -> float | None:
    if not isinstance(value,str):
        return None
    try:
        stamp=ensure_utc(datetime.fromisoformat(value),"heartbeat time")
        return (now-stamp).total_seconds()
    except (TypeError,ValueError):
        return None
''',encoding='utf-8')
(P/'tests/test_audit_final_boundaries.py').write_bytes(Path(__file__).with_name('test_expansion_final_boundaries.py').read_bytes())
