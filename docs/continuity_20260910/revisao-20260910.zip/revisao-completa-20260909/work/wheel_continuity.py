from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import zipfile

R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\closure110')
phase=sys.argv[1]
run=R/phase
target=Path(r'C:\Cripto\operacao\temporarios')/('continuity-wheel-'+phase)
target.mkdir(parents=True,exist_ok=False)
env=os.environ.copy()
for k in list(env):
    if any(s in k.upper() for s in ('API_KEY','API_SECRET','SECRET_KEY','AUTH_TOKEN')):env.pop(k,None)
for k in ('DATA','OUTPUT','CACHE','LOGS'):
    env[k+'_DIR']=env['GARIMPO_'+k+'_DIR']=str(target/k.lower())
env.update(CRIPTO_ENV_FILE=str(target/'empty.env'),GEMINI_API_KEY='test-gemini-key-for-unit-tests-only',SERP_API_KEY='test-serp-key-for-unit-tests-only',PREDICTOR_EVENTS_PATH=str(target/'events.jsonl'))
cmd=r'C:\Cripto\CRIPTO.cmd'
py=target/'env/Scripts/python.exe'
wheel=next(Path(r'C:\Cripto\correcao-pr110-20260910\dist').glob('*.whl'))
with zipfile.ZipFile(wheel) as z:
    members=z.namelist()
    prohibited=[n for n in members if n.endswith(('.env','.db','.jsonl')) or any(p in n.split('/') for p in ('.venv','work','logs','operacao'))]
report={'started_at_utc':datetime.now(timezone.utc).isoformat(),'phase':phase,'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'members':len(members),'prohibited_members':prohibited,'real_credentials_available':False,'checks':[]}
for name,args,cwd in [
 ('create',[cmd,'uv','venv','--python',sys.executable,str(target/'env')],target),
 ('install',[cmd,'uv','pip','install','--python',str(py),'predictor-core @ https://github.com/leonardosovienski/core-predictor/releases/download/v3.2.0/predictor_core-3.2.0-py3-none-any.whl','predictor-ops @ https://github.com/leonardosovienski/predictor-ops/releases/download/v4.1.0/predictor_ops-4.1.0-py3-none-any.whl',str(wheel)],target),
 ('contract',[str(py),'-B',r'C:\Cripto\correcao-pr110-20260910\scripts\verify_installed_wheels.py'],target),
]:
    result=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
    (run/('wheel_'+name+'.log')).write_text(result.stdout+result.stderr,encoding='utf-8')
    report['checks'].append({'name':name,'exit_code':result.returncode,'command':args,'cwd':str(cwd)})
    if result.returncode: break
report['finished_at_utc']=datetime.now(timezone.utc).isoformat()
(run/'wheel_contract.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
