"""Fast-forward only after verified CI; preserve owner edits and frozen evidence."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import sqlite3

P=Path(r'C:\Cripto\pesquisa-20260909')
W=Path(r'C:\Cripto\auditoria-ampliada-20260910')
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
base='ffd6c327e2d323758f6ab6abac4ab15ef5ca0881'
tested='595f1203475d04b01966ac3471bbafd6770dbb4d'
merged=sys.argv[1]
def git(*args,cwd=P):
    return subprocess.check_output(['git',*args],cwd=cwd).decode().strip()
assert git('rev-parse','HEAD')==base
assert git('status','--porcelain')=='M docs/NEXT_CHAT_PROMPT.md'
assert git('rev-parse','HEAD',cwd=W)==tested and not git('status','--porcelain',cwd=W)
v=json.loads((R/'expansion_full03/validation.json').read_bytes())
assert v.get('finished_at_utc') and all(c['exit_code']==0 for c in v['checks'])
assert all(hashlib.sha256((W/p).read_bytes()).hexdigest()==h for p,h in v['source_hashes'].items())
ci=json.loads((R/'expansion_ci_pr_final.json').read_bytes())
assert ci['head']==tested and ci['base']==base and ci['four_jobs_passed']
git('fetch','origin','main')
assert git('rev-parse','origin/main')==merged
assert git('rev-parse',merged+'^{tree}')==git('rev-parse',tested+'^{tree}')
protected=['docs/evidence','docs/session_archive_20260907','docs/session_archive_20260908','charters','observation_plans','CR_FREEZE_INDEX.md','CR_RESEARCH_FREEZE.md','trials.json','docs/NEXT_CHAT_PROMPT.md']
assert not git('diff','--name-only',base,merged,'--',*protected)
prompt=P/'docs/NEXT_CHAT_PROMPT.md'
owner=prompt.read_bytes()
assert hashlib.sha256(owner).hexdigest()=='8969db38ef9a3ec29ee16a780b9572ec9f7d7808cabc9bac17a319616b47fe20'
(R/'expansion_owner_prompt_before.md').write_bytes(owner)
(R/'expansion_owner_diff_before.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=P))
# The incoming version is unchanged; Git can preserve the unrelated owner diff directly.
git('merge','--ff-only',merged)
assert prompt.read_bytes()==owner
assert git('status','--porcelain')=='M docs/NEXT_CHAT_PROMPT.md'
db=Path(r'C:\Cripto\operacao\saidas\feature_store.db')
with sqlite3.connect(f'{db.as_uri()}?mode=ro',uri=True) as conn:
    tables={row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    counts={name:conn.execute('SELECT COUNT(*) FROM '+name).fetchone()[0] for name in ('predictions','prediction_inputs','market_snapshots') if name in tables}
    check=conn.execute('PRAGMA quick_check').fetchone()[0]
record={'at_utc':datetime.now(timezone.utc).isoformat(),'head':merged,'tested_head':tested,'tree':git('rev-parse','HEAD^{tree}'),'tree_matches_tested':True,'owner_prompt_preserved_byte_for_byte':True,'protected_tracked_paths_unchanged':True,'source_files_matched':len(v['source_hashes']),'working_tree_status':git('status','--short'),'operational_database_quick_check':check,'operational_tables':counts,'operational_refresh':'await normal next UTC ingestion budget; no historical snapshot rewritten','postmerge_local_checks':'pending'}
(R/'expansion_operational.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
