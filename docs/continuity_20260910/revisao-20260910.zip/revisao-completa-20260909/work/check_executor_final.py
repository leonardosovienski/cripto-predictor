from pathlib import Path
template=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\work\check_manual_final.py')
source=template.read_text(encoding='utf-8').replace('manual_final02','executors_final01')
exec(compile(source,str(template),'exec'))
