from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910/GarimpoInvestimentos/trading/store.py')
s=p.read_text(encoding='utf-8')
s=s.replace('sort_keys=True, separators=(",", ":")','sort_keys=True, separators=(",", ":"), allow_nan=False')
s=s.replace(']\n\n\ndef _canonical','    ("0006_dense_provenance", """\n        ALTER TABLE microstructure_events_v3 ADD COLUMN session_text TEXT;\n        ALTER TABLE microstructure_events_v3 ADD COLUMN collector_version TEXT NOT NULL\n            DEFAULT \'binance_spot_microstructure_v1\';\n    """),\n]\n\n\ndef _canonical',1)
s=s.replace('SELECT payload_hash FROM trading_events WHERE event_id=?','SELECT payload_hash,event_at FROM trading_events WHERE event_id=?')
s=s.replace('if existing["payload_hash"] != digest:\n                raise ValueError("event_id','if existing["payload_hash"] != digest or existing["event_at"] != event_iso:\n                raise ValueError("event_id',1)
s=s.replace('        received = ensure_utc(received_at, "received_at")','        if venue != "binance_spot" or symbol not in _SYMBOL_CODES or kind not in _KIND_CODES:\n            raise ValueError("dense store suporta apenas BTC/ETH Binance Spot")\n        if not session_id:\n            raise ValueError("session_id vazio")\n        received = ensure_utc(received_at, "received_at")',1)
s=s.replace('WHERE venue=? AND symbol=? AND kind=? AND observation_id=? LIMIT 1','WHERE venue=? AND symbol=? AND kind=? AND observation_id=?')
s=s.replace('(*dense_key, *key, *key),\n            ).fetchone()','(*dense_key, *key, *key),\n            ).fetchall()')
s=s.replace('if existing["payload_hash"].lower() != digest:','if any(row["payload_hash"].lower() != digest for row in existing):')
s=s.replace('ingested_us,session_blob,payload_hash_blob,payload_zlib,quality_flags)\n                VALUES (?,?,?,?,?,?,?,?,?,?,?)','ingested_us,session_blob,payload_hash_blob,payload_zlib,quality_flags,session_text)\n                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',1)
s=s.replace('bytes.fromhex(session_id) if len(session_id) == 32 else session_id.encode(),','session_id.encode("utf-8"),',1)
s=s.replace('json.dumps(sorted(quality_flags)),\n                ),','json.dumps(sorted(quality_flags)),\n                    session_id,\n                ),',1)
s=s.replace('datetime.now().astimezone().isoformat(),','datetime.now(UTC).isoformat(),')
s=s.replace('rows = self._decoded_rows()','rows = self._decoded_rows(latest_only=True)',1)
s=s.replace('dict[tuple[str, str], dict[str, Any]]','dict[tuple[str, str, str], dict[str, Any]]')
s=s.replace('key = (row["symbol"], row["kind"])','key = (row["venue"], row["symbol"], row["kind"])')
s=s.replace('def _decoded_rows(self, where: str = "", params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:','def _decoded_rows(self, where: str = "", params: tuple[Any, ...] = (), *, latest_only: bool = False) -> list[dict[str, Any]]:')
s=s.replace('        result: list[dict[str, Any]] = []\n        for row','        if latest_only:\n            where = "WHERE (venue,symbol,kind,observation_id) IN (SELECT venue,symbol,kind,observation_id FROM (SELECT venue,symbol,kind,observation_id,ROW_NUMBER() OVER (PARTITION BY venue,symbol,kind ORDER BY received_at DESC,observation_id DESC) AS rn FROM {table}) WHERE rn=1)"\n        result: list[dict[str, Any]] = []\n        for row',1)
s=s.replace('microstructure_events {where}",','microstructure_events {where.format(table=\'microstructure_events\')}",')
s=s.replace('microstructure_events_v2 {where}",','microstructure_events_v2 {where.format(table=\'microstructure_events_v2\')}",')
s=s.replace('        if where:\n            start, end = params','        if latest_only:\n            dense_where = "WHERE (symbol_code,kind_code,observation_id) IN (SELECT symbol_code,kind_code,observation_id FROM (SELECT symbol_code,kind_code,observation_id,ROW_NUMBER() OVER (PARTITION BY symbol_code,kind_code ORDER BY received_us DESC,observation_id DESC) AS rn FROM microstructure_events_v3) WHERE rn=1)"\n        elif where:\n            start, end = params')
s=s.replace('"session_id": item["session_blob"].hex(),','"session_id": item["session_text"] if item["session_text"] is not None else (item["session_blob"].hex() if len(item["session_blob"]) == 16 else item["session_blob"].decode("utf-8")),')
s=s.replace('"collector_version": "binance_spot_microstructure_v1",','"collector_version": item["collector_version"],')
start=s.index('    def compact_microstructure_v1(')
s=s[:start]+'''    def compact_microstructure_v1(self, *, batch_size: int = 10_000) -> dict[str, int]:
        """Verify every field and payload before deleting each copied row.

        Offline maintenance only; preserve a backup before calling.
        """
        return self._compact(1, batch_size)

    def compact_microstructure_v2(self, *, batch_size: int = 10_000) -> dict[str, int]:
        """Copy v2 to dense storage without losing session/version provenance."""
        return self._compact(2, batch_size)

    def _compact(self, version: int, batch_size: int) -> dict[str, int]:
        if batch_size <= 0:
            raise ValueError("batch_size precisa ser positivo")
        source = "microstructure_events" if version == 1 else "microstructure_events_v2"
        target = "microstructure_events_v2" if version == 1 else "microstructure_events_v3"
        before = self._conn.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0]
        processed = 0
        while True:
            rows = self._conn.execute(f"SELECT * FROM {source} ORDER BY rowid LIMIT ?", (batch_size,)).fetchall()
            if not rows:
                break
            with self._conn:
                for raw in rows:
                    row = dict(raw)
                    content = row["payload_json"].encode("utf-8") if version == 1 else zlib.decompress(row["payload_zlib"])
                    if hashlib.sha256(content).hexdigest() != row["payload_hash"]:
                        raise ValueError("compactacao: hash original nao corresponde ao payload")
                    source_key = (row["venue"], row["symbol"], row["kind"], row["observation_id"])
                    if version == 1:
                        copied = {key: value for key, value in row.items() if key != "payload_json"}
                        copied["payload_zlib"] = zlib.compress(content, 6)
                        predicate = "venue=? AND symbol=? AND kind=? AND observation_id=?"
                        key = source_key
                    else:
                        if row["venue"] != "binance_spot" or row["symbol"] not in _SYMBOL_CODES or row["kind"] not in _KIND_CODES or row["scientific_state"] != SCIENTIFIC_STATE:
                            raise ValueError("compactacao: proveniencia nao representavel no layout denso")
                        copied = {
                            "kind_code": _KIND_CODES[row["kind"]], "symbol_code": _SYMBOL_CODES[row["symbol"]],
                            "observation_id": row["observation_id"], "sequence_id": row["sequence_id"],
                            "event_us": _micros(datetime.fromisoformat(row["event_at"])) if row["event_at"] else None,
                            "received_us": _micros(datetime.fromisoformat(row["received_at"])),
                            "ingested_us": _micros(datetime.fromisoformat(row["ingested_at"])),
                            "session_blob": row["session_id"].encode("utf-8"), "session_text": row["session_id"],
                            "collector_version": row["collector_version"],
                            "payload_hash_blob": bytes.fromhex(row["payload_hash"]),
                            "payload_zlib": row["payload_zlib"], "quality_flags": row["quality_flags"],
                        }
                        predicate = "symbol_code=? AND kind_code=? AND observation_id=?"
                        key = (copied["symbol_code"], copied["kind_code"], copied["observation_id"])
                    existing = self._conn.execute(f"SELECT * FROM {target} WHERE {predicate}", key).fetchone()
                    if existing is not None:
                        target_row = dict(existing)
                        if zlib.decompress(target_row["payload_zlib"]) != content:
                            raise ValueError("compactacao: payload conflitante no destino")
                        if version == 2 and target_row["session_text"] is None:
                            blob = target_row["session_blob"]
                            target_row["session_text"] = blob.hex() if len(blob) == 16 else blob.decode("utf-8")
                        if any(target_row[k] != v for k, v in copied.items() if k not in {"payload_zlib", "session_blob"}):
                            raise ValueError("compactacao: metadados conflitantes no destino")
                    else:
                        self._conn.execute(f"INSERT INTO {target} ({','.join(copied)}) VALUES ({','.join('?' for _ in copied)})", tuple(copied.values()))
                    self._conn.execute(f"DELETE FROM {source} WHERE venue=? AND symbol=? AND kind=? AND observation_id=?", source_key)
            processed += len(rows)
        return {f"v{version}_before": before, "processed": processed, f"v{version}_after": 0}
'''
p.write_text(s,encoding='utf-8')
