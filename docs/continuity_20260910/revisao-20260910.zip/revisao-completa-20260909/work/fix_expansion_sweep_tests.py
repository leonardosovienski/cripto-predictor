from pathlib import Path
P=Path(r'C:\Cripto\auditoria-ampliada-20260910')
p=P/'tests/test_kelly_sweep_cli.py'
s=p.read_text(encoding='utf-8').replace('        mock.patch.object(backtest_v3, "emit_event"),','        mock.patch.object(backtest_v3, "emit_event"),\n        mock.patch.object(backtest_v3, "_require_open_sweep", return_value="synthetic"),\n        mock.patch.object(backtest_v3, "register_trial"),')
p.write_text(s,encoding='utf-8')
p=P/'tests/test_threshold_grid_registry.py'
s=p.read_text(encoding='utf-8').replace('    calls = []','    monkeypatch.setattr(backtest_v3, "load_scientific_state", lambda: SimpleNamespace(frozen_families=()))\n    calls = []').replace('{call[0] for call in calls[:4]}','{"-".join(call[0].split("-")[:-1]) for call in calls[:4]}')
p.write_text(s,encoding='utf-8')
