"""One real paired integration diagnostic, excluded from future pilot observations."""
from datetime import UTC, datetime, timedelta
import importlib.util
from pathlib import Path
import sys
import scripts
from scripts.research_io import encoded, sha

HERE=Path(__file__).resolve().parent
for name in ('paired_llm','paired_llm_source'):
    spec=importlib.util.spec_from_file_location('scripts.'+name,HERE/(name+'.py'))
    module=importlib.util.module_from_spec(spec)
    sys.modules['scripts.'+name]=module
    setattr(scripts,name,module)
    spec.loader.exec_module(module)
from scripts import paired_llm as paired
from scripts.paired_llm_source import Source

R=HERE.parent/'executor_preflight02'
R.mkdir(exist_ok=False)
def save(name,value):
    with (R/name).open('xb') as stream:
        stream.write(encoded(value)+b'\n')
now=lambda:datetime.now(UTC)
save('scope.json',{'registered_at':now().isoformat(),'purpose':'Connected integration diagnostic only; never a registered prospective observation, hypothesis activation or H6 reopening',
    'maximum_physical_requests':5,'maximum_logical_llm_calls':2,'news_attempts':1,'ingestion_units':1,
    'retries':0,'capital_permission':False,'scheduler_enabled':False,
    'source_code_sha256':sha((HERE/'paired_llm_source.py').read_bytes()),
    'executor_code_sha256':sha((HERE/'paired_llm.py').read_bytes())})
result={'state':'STARTED','arms':{}}
with Source(R/'sources') as source:
    try:
        market=paired.market_context(source.market(),now())
        news=paired.news_context(source.news(),now())
        save('inputs.json',{'market':market,'news':news,'known_at':now().isoformat()})
        p=paired.protocol((now()+timedelta(days=2)).replace(hour=12,minute=0,second=0,microsecond=0))
        for arm in paired.ARMS:
            prompt=paired.PROMPT+encoded({'market':market,'news':news if arm=='llm_news' else []}).decode()
            save('request-'+arm+'.json',{'prompt':prompt,'model':p['model'],'at':now().isoformat()})
            try:
                raw=source.generate(prompt,p)
                row={'score':paired.score(raw),'response':raw,'state':'VALID','received_at':now().isoformat()}
            except Exception as exc:
                row={'state':'FAILED','error_type':type(exc).__name__}
            save('response-'+arm+'.json',row)
            result['arms'][arm]={k:v for k,v in row.items() if k!='response'}
        result.update(state='COMPLETE',market_bars=len(market['bars']),dated_news=len(news))
    except Exception as exc:
        result.update(state='FAILED',error_type=type(exc).__name__)
    finally:
        result.update(physical_calls=source.calls,sources=source.records,counts_as_pilot_observation=False)
        save('result.json',result)
print(encoded({k:v for k,v in result.items() if k!='sources'}).decode())

