import json
import sys
from collections import Counter
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')

source = Path(r'C:\Users\leona\.codex\sessions\2026\09\09\rollout-2026-09-09T18-45-21-01a08821-f27f-7970-a87f-f37b1e249910.jsonl')
target = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\publication_chat_20260910')
target.mkdir(exist_ok=True)
messages = []
for line in source.open(encoding='utf-8'):
    record = json.loads(line)
    p = record.get('payload', {})
    msg = None
    if record.get('type') == 'response_item' and p.get('type') == 'message':
        role, channel = p.get('role'), p.get('channel') or p.get('phase')
        if role == 'user' or (role == 'assistant' and channel in ('commentary', 'final')):
            body = '\n'.join(c.get('text', '') for c in p.get('content', []) if c.get('type') in ('input_text', 'output_text'))
            if not body.startswith(('<environment_context>', '<recommended_plugins>', '<permissions instructions>')):
                msg = {'at': record.get('timestamp'), 'role': role, 'channel': channel, 'text': body}
    elif record.get('type') == 'event_msg' and p.get('type') == 'agent_message':
        msg = {'at': record.get('timestamp'), 'role': 'assistant', 'channel': p.get('phase'), 'text': p.get('message', '')}
    elif record.get('type') == 'event_msg' and p.get('type') == 'item_completed':
        item = p.get('item', {})
        if item.get('type') in ('agentMessage', 'agent_message', 'AgentMessage'):
            msg = {'at': record.get('timestamp'), 'role': 'assistant', 'channel': item.get('phase'),
                   'text': '\n'.join(c.get('text', '') for c in item.get('content', []) if c.get('type') == 'Text')}
    if msg and msg['text']:
        if msg['role'] == 'assistant' and any(x['text'] == msg['text'] and x['role'] == 'assistant' for x in messages[-3:]):
            continue
        messages.append(msg)
out = target/'conversation_messages.json'
if not out.exists():
    out.write_text(json.dumps(messages, ensure_ascii=False, indent=2), encoding='utf-8')
else:
    messages = json.loads(out.read_bytes())
start, count = int(sys.argv[1]) if len(sys.argv)>1 else 0, int(sys.argv[2]) if len(sys.argv)>2 else 35
print(json.dumps({'total': len(messages), 'roles': dict(Counter(m['role'] for m in messages)), 'characters': sum(len(m['text']) for m in messages), 'range': [start, min(start+count, len(messages))]}, ensure_ascii=False))
for i, msg in enumerate(messages[start:start+count], start):
    print(json.dumps({'i': i, **msg}, ensure_ascii=False))
