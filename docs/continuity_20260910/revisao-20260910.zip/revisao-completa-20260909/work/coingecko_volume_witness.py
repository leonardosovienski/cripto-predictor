"""Offline witness: public OHLC payload has no volume."""
import asyncio
import json
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, r"C:\Cripto\pesquisa-20260909")
from GarimpoInvestimentos.dpl.providers import coingecko

class Response:
    def raise_for_status(self):
        pass
    def json(self):
        return [[1767312000000, 100, 110, 90, 105]]

class Client:
    async def __aenter__(self):
        return self
    async def __aexit__(self, *args):
        pass
    async def get(self, *args, **kwargs):
        return Response()

with patch.object(coingecko, "get_http_client", Client):
    rows = asyncio.run(coingecko.CoinGeckoProvider(api_key="").fetch_ohlcv("bitcoin", "4h", 1))
assert rows[0].volume == 0.0
target = Path(r"C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\manual_dependencies\coingecko_before.json")
with target.open("x", encoding="utf-8") as f:
    json.dump({"synthetic": True, "network_calls": 0, "source_fields": ["timestamp", "open", "high", "low", "close"], "returned_volume": rows[0].volume, "defect": "missing volume represented as measured zero"}, f, indent=2)
print("Offline witness confirmed: missing volume became zero")
