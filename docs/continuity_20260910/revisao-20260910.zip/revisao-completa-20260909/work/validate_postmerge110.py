"""Run the mandated complete post-merge suite with bounded BLAS concurrency."""
import os
import runpy
import sys

for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
runner = r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\work\run_checks.py'
sys.argv = [runner, 'postmerge02']
runpy.run_path(runner, run_name='__main__')
