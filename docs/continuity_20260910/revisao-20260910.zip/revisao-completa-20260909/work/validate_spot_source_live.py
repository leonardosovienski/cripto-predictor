"""Bounded public source validation, two assets, six HTTP requests maximum."""
from pathlib import Path
from datetime import UTC, datetime
import hashlib
import json
import sqlite3
import httpx
from GarimpoInvestimentos.config import settings
from GarimpoInvestimentos.core.api_guard import allow, _BUDGET_DB
from GarimpoInvestimentos.v3.collectors import binance_vision as vision
from GarimpoInvestimentos.v3.collectors.spot_collector import save_spot_csv, load_spot_csv

ROOT = Path(r'C:\Cripto\operacao\dados\spot-source-audit-20260910')
ROOT.mkdir(parents=True, exist_ok=False)
vision._CACHE_DIR = ROOT / 'raw'
assert settings.API_GUARD_ENABLED and settings.API_GUARD_MAX_INGEST_ASSETS == 28
start = int(datetime(2026, 8, 1, tzinfo=UTC).timestamp() * 1000)
end = int(datetime(2026, 9, 1, tzinfo=UTC).timestamp() * 1000) - 1
result = {'scope': 'Binance spot 1h BTCUSDT/ETHUSDT August 2026; full archive and first 24h REST comparison', 'max_http_requests': 6, 'historical_vintage_verified': False, 'capital_authorized': False, 'assets': [], 'at': datetime.now(UTC).isoformat()}
with sqlite3.connect(f'{_BUDGET_DB.as_uri()}?mode=ro', uri=True) as conn:
    result['budget_before'] = conn.execute('SELECT bucket, stage, guard_key, used FROM api_budget').fetchall()
for symbol in ('BTCUSDT', 'ETHUSDT'):
    record = {'symbol': symbol}
    result['assets'].append(record)
    if not allow('ingest', 'assets', 28).allowed:
        record['status'] = 'BUDGET_EXHAUSTED'
        continue
    try:
        records = vision.load_klines_vision(symbol, start, end)
        # end_ms denotes availability; 23:00 Aug 31 closes at Sep 1 00:00.
        assert len(records) == 743 and records[0].open_ms == start
        assert all(b.open_ms-a.open_ms == 3_600_000 for a,b in zip(records,records[1:]))
        target = ROOT / symbol / 'spot_binance_1h.csv'
        save_spot_csv(records, target)
        assert load_spot_csv(target) == records
        record.update(rows=len(records), first=records[0].open_ms, last=records[-1].open_ms, csv_sha256=hashlib.sha256(target.read_bytes()).hexdigest())
        with httpx.Client(timeout=30) as client:
            response = client.get('https://api.binance.com/api/v3/klines', params={'symbol':symbol,'interval':'1h','startTime':start,'endTime':start+24*3_600_000-1,'limit':24})
            (ROOT / (symbol + '-rest.json')).write_bytes(response.content)
            response.raise_for_status()
            rows = response.json()
        assert len(rows) == 24
        assert all(int(row[0])==saved.open_ms and float(row[4])==saved.close and float(row[5])==saved.volume for row,saved in zip(rows,records[:24]))
        record.update(status='VERIFIED_ARCHIVE_AND_REST_SAMPLE', rest_comparisons=24)
    except Exception as exc:
        record.update(status='FAILED', error_type=type(exc).__name__)
    (ROOT/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
with sqlite3.connect(f'{_BUDGET_DB.as_uri()}?mode=ro', uri=True) as conn:
    result['budget_after'] = conn.execute('SELECT bucket, stage, guard_key, used FROM api_budget').fetchall()
(ROOT/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
