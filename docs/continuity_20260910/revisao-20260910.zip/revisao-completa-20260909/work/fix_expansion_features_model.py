from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
f=p/'GarimpoInvestimentos/v3/timeindex.py';s=f.read_text(encoding='utf-8').replace('self._index = index','self._index = dict(index)');s=s.replace('        if not self._keys:\n','        if tolerance_ms < 0:\n            raise ValueError("tolerance_ms nao pode ser negativo")\n        if not self._keys:\n');f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/v3/feature_builder.py';s=f.read_text(encoding='utf-8').replace('import bisect\n','')
s=s.replace('from dataclasses import dataclass','from dataclasses import dataclass\nfrom GarimpoInvestimentos.v3.timeindex import SortedTimeIndex\nfrom GarimpoInvestimentos.v3.collectors.record_io import unique_records, validate_observation')
s=s.replace('24 closes 1h para vol realizada','24 retornos 1h (25 closes) para vol realizada')
s=s.replace('    data_quality_score: float  # 1.0 = todos os dados presentes; 0.0 = inválido','''    data_quality_score: float  # 1.0 = todos os dados presentes; 0.0 = inválido

    def __post_init__(self) -> None:
        values = {name: getattr(self, name) for name in (
            "funding_rate_raw", "oi_notional_usd", "spot_close", "funding_zscore",
            "oi_log_delta", "leverage_pressure", "log_return_8h", "realized_vol_24h", "data_quality_score")}
        validate_observation(self.asset, self.timestamp_exchange_ms, values)
        if not 0 <= self.data_quality_score <= 1 or self.realized_vol_24h < 0:
            raise ValueError("qualidade/volatilidade invalida")''')
s=s.replace('    if prev <= 0.0 or curr <= 0.0:','    if not math.isfinite(prev) or not math.isfinite(curr) or prev <= 0.0 or curr <= 0.0:')
s=s.replace('return math.log(curr / prev)','return math.log(curr) - math.log(prev)')
s=s.replace('    n = len(funding_times_ms)','''    if isinstance(fr_window, bool) or not isinstance(fr_window, int) or fr_window < 2:
        raise ValueError("fr_window deve ser inteiro >= 2")
    if isinstance(vol_window_hours, bool) or not isinstance(vol_window_hours, int) or vol_window_hours < 2 or join_tolerance_ms < 0:
        raise ValueError("janela/tolerancia invalida")
    if any(a >= b for a, b in zip(funding_times_ms, funding_times_ms[1:])):
        raise ValueError("funding timestamps devem ser unicos crescentes")
    if any(not math.isfinite(value) for value in [*funding_rates, *oi_index.values(), *spot_index.values()]):
        raise ValueError("dados de entrada devem ser finitos")
    n = len(funding_times_ms)''',1)
a=s.index('    # Pré-ordena os closes');b=s.index('    ms_per_hour =',a)
s=s[:a]+'    oi_ti = SortedTimeIndex(oi_index)\n    spot_ti = SortedTimeIndex(spot_index)\n'+s[b:]
s=s.replace('        if i < fr_window:','        if i < fr_window - 1:')
s=s.replace('        fr_window_slice = funding_rates','        # Require the declared 8h cadence across the funding window.\n        if funding_times_ms[i] - funding_times_ms[i - fr_window + 1] != (fr_window - 1) * 8 * ms_per_hour or any(b - a != 8 * ms_per_hour for a, b in zip(funding_times_ms[i - fr_window + 1:i], funding_times_ms[i - fr_window + 2:i + 1])):\n            skipped += 1\n            continue\n        fr_window_slice = funding_rates',1)
s=s.replace('_find_asof(ts, oi_index, join_tolerance_ms)','oi_ti.as_of(ts, join_tolerance_ms)').replace('_find_asof(oi_prev_ts, oi_index, join_tolerance_ms) if oi_prev_ts else None','oi_ti.as_of(oi_prev_ts, join_tolerance_ms) if oi_prev_ts is not None else None')
s=s.replace('_find_asof(ts - ms_per_hour, spot_index, join_tolerance_ms)','spot_ti.as_of(ts - ms_per_hour, join_tolerance_ms)')
s=s.replace('        spot_prev_ts = funding_times_ms[i - 1]','        spot_prev_ts = ts - 8 * ms_per_hour')
s=s.replace('_find_asof(spot_prev_ts - ms_per_hour, spot_index, join_tolerance_ms)','spot_ti.as_of(spot_prev_ts - ms_per_hour, join_tolerance_ms)')
a=s.index('        # Janela [ts - 24h, ts]');b=s.index('        realized_vol_24h =',a)
s=s[:a]+'''        # 24 hourly returns need 25 consecutive closed candles, with no gap bridging.
        vol_closes = [spot_index.get(ts - (offset + 1) * ms_per_hour) for offset in range(vol_window_hours, -1, -1)]
        if any(value is None or value <= 0 for value in vol_closes):
            skipped += 1
            continue
        vol_log_returns = [math.log(current) - math.log(previous) for previous, current in zip(vol_closes, vol_closes[1:])]
''' + s[b:]
s=s.replace('for r in oi_records}', 'for r in unique_records(list(oi_records), "timestamp_ms")}')
s=s.replace('for r in kline_records}', 'for r in unique_records(list(kline_records), "open_ms")}')
s=s.replace('    Spot closes : 1h → selecionamos o close do mesmo open_ms do funding','    Spot closes : 1h → apenas candles fechados ate o timestamp do funding')
s=s.replace('O join é feito por timestamp_ms com tolerância de ±5min','O join e feito somente para tras por timestamp_ms com tolerancia de 5min')
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/v3/crowding_features.py';s=f.read_text(encoding='utf-8')
s=s.replace('FeatureVector, _find_asof','FeatureVector\nfrom GarimpoInvestimentos.v3.timeindex import SortedTimeIndex')
s=s.replace('    out = []','    time_index = SortedTimeIndex(volume_index)\n    if any(not math.isfinite(value) for value in volume_index.values()):\n        raise ValueError("volume deve ser finito")\n    out = []',1)
s=s.replace('_find_asof(fv.timestamp_exchange_ms, volume_index, join_tolerance_ms)','time_index.as_of(fv.timestamp_exchange_ms - 3_600_000, join_tolerance_ms)')
s=s.replace('return math.log(numerator / denominator)','return math.log(numerator) - math.log(denominator)')
s=s.replace('sem\nlookahead, é o candle do próprio ponto','candle fechado uma hora antes do ponto')
s=s.replace('decisão CONSERVADORA (covariável neutra),','imputacao que exige medir a cobertura,')
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/v3/regime_engine.py';s=f.read_text(encoding='utf-8').replace('import logging\n','import logging\nimport hashlib\nimport json\n')
s=s.replace('from typing import cast','from typing import cast\nfrom GarimpoInvestimentos.durable_io import atomic_write')
s=s.replace('MODEL_SCHEMA_VERSION = 1','MODEL_SCHEMA_VERSION = 2')
a=s.index('def _emission_probs(');b=s.index('def _forward_causal(',a)
s=s[:a]+'''def _emission_matrix(X: "np.ndarray", means: "np.ndarray", covars: "np.ndarray") -> "np.ndarray":
    """Compute each covariance inverse once per series, retaining per-row normalization."""
    n_states, n_features = means.shape
    log_probs = np.full((len(X), n_states), -1e300)
    for i in range(n_states):
        try:
            sign, log_det = np.linalg.slogdet(covars[i])
            if sign <= 0:
                continue
            inverse = np.linalg.inv(covars[i])
            diff = X - means[i]
            mahal = np.einsum("ti,ij,tj->t", diff, inverse, diff)
            log_probs[:, i] = -0.5 * (n_features * math.log(2 * math.pi) + log_det + mahal)
        except np.linalg.LinAlgError:
            continue
    log_probs -= log_probs.max(axis=1, keepdims=True)
    return np.exp(log_probs)


def _emission_probs(x: "np.ndarray", means: "np.ndarray", covars: "np.ndarray") -> "np.ndarray":
    return _emission_matrix(x[None, :], means, covars)[0]


''' + s[b:]
s=s.replace('    # Inicialização\n    B0 = _emission_probs(X_scaled[0], means, covars)','    if T == 0:\n        return alpha\n    emissions = _emission_matrix(X_scaled, means, covars)\n    # Inicialização\n    B0 = emissions[0]')
s=s.replace('        Bt = _emission_probs(X_scaled[t], means, covars)','        Bt = emissions[t]')
s=s.replace('        self._extra_features = tuple(extra_features)','        if len(set(extra_features)) != len(extra_features):\n            raise ValueError("extra_features duplicadas")\n        self._extra_features = tuple(extra_features)')
s=s.replace('        self._model = None','        self.training_data_hash: str | None = None\n        self._model = None',1)
s=s.replace('        self._scaler = StandardScaler()\n        X_scaled = self._scaler.fit_transform(X)','        if not np.isfinite(X).all():\n            raise ValueError("HMM exige valores finitos")\n        scaler = StandardScaler()\n        X_scaled = scaler.fit_transform(X)')
s=s.replace('        self._model = model\n\n        # Rotular','        # Rotular')
s=s.replace('        self._state_map = {s: label_order[rank] for rank, s in enumerate(sorted_states)}','        state_map = {s: label_order[rank] for rank, s in enumerate(sorted_states)}\n        self._model, self._scaler, self._state_map = model, scaler, state_map\n        self.training_data_hash = hashlib.sha256(json.dumps(columns, allow_nan=False).encode()).hexdigest()')
s=s.replace('        columns = [log_returns, realized_vols]\n        columns.extend(self._validate_extra_covariates(extra_covariates, len(log_returns)))\n        X = np.column_stack(columns)','        if len(log_returns) != len(realized_vols):\n            raise ValueError("log_returns e realized_vols devem ter o mesmo tamanho")\n        columns = [log_returns, realized_vols]\n        columns.extend(self._validate_extra_covariates(extra_covariates, len(log_returns)))\n        if not log_returns:\n            return []\n        X = np.column_stack(columns)\n        if not np.isfinite(X).all():\n            raise ValueError("HMM exige valores finitos")',1)
s=s.replace('signal_weights=_REGIME_WEIGHTS.get(label, {}),','signal_weights=dict(_REGIME_WEIGHTS.get(label, {})),')
a=s.index('        path.parent.mkdir(parents=True, exist_ok=True)');b=s.index('        logger.info("RegimeEngine salvo',a)
s=s[:a]+'''        atomic_write(path, pickle.dumps({
            "model": self._model, "scaler": self._scaler, "state_map": self._state_map,
            "fingerprint": _model_fingerprint(self._extra_features),
            "training_data_hash": self.training_data_hash,
        }))
''' + s[b:]
a=s.index('        if saved_fp is None:');b=s.index('            raise StaleRegimeModelError(',s.index('        elif saved_fp',a))
s=s[:a]+'''        if saved_fp is None:
            raise StaleRegimeModelError("Modelo sem fingerprint: preservar arquivo e retreinar")
        if saved_fp != current_fp:
''' + s[b:]
s=s.replace('        self._model = data["model"]','        self.training_data_hash = data.get("training_data_hash")\n        self._model = data["model"]')
s=s.replace('- fingerprint ausente  → modelo legado (salvo antes do guard): avisa e segue\n          (compatibilidade de migração; o próximo save carimba).','- fingerprint ausente → recusa; preserve o arquivo e retreine.\n        Carregue apenas pickles locais confiaveis: fingerprint nao torna pickle seguro.')
f.write_text(s,encoding='utf-8')
