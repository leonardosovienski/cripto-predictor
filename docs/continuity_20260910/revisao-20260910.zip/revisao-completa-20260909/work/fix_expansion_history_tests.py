from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
f=p/'tests/test_hypothesis_loop.py';s=f.read_text(encoding='utf-8').replace('def test_arquivo_corrompido_nao_derruba_a_leitura','def test_arquivo_corrompido_e_erro_sem_alterar_o_historico').replace('    assert load_proposals(destino) == []','    with pytest.raises(ValueError):\n        load_proposals(destino)\n    assert destino.read_text(encoding="utf-8") == "{lixo"');f.write_text(s,encoding='utf-8')
f=p/'tests/test_v3_regime_staleness.py';s=f.read_text(encoding='utf-8').replace('def test_load_warns_on_legacy_without_fingerprint(tmp_path, caplog):','def test_load_rejects_legacy_without_fingerprint_and_preserves_it(tmp_path):');a=s.index('    with caplog.at_level("WARNING"):');s=s[:a]+'''    before = p.read_bytes()
    with pytest.raises(StaleRegimeModelError, match="sem fingerprint"):
        eng.load(p)
    assert not eng.is_trained
    assert p.read_bytes() == before
''';f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/v3/collectors/record_io.py';s=f.read_text(encoding='utf-8').replace('from typing import Any, TypeVar','from typing import Any').replace('T = TypeVar("T")\n\n\n','').replace('def unique_records(', 'def unique_records[T](').replace('def load_records(', 'def load_records[T](');f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/analyzers/hypothesis_loop.py';s=f.read_text(encoding='utf-8')
s=s.replace('from GarimpoInvestimentos.durable_io import append_json_history, load_json_history','from GarimpoInvestimentos.durable_io import append_json_history, load_json_history, file_lock, atomic_write')
s=s.replace('PROPOSALS_PATH = DATA_DIR / "research" / "hypothesis_proposals.json"','PROPOSALS_PATH = DATA_DIR / "research" / "hypothesis_proposals.json"\n_LEGACY_PROPOSALS_PATH = Path(__file__).resolve().parent.parent / "hypothesis_proposals.json"')
s=s.replace('    return load_json_history(path)','    historical = load_json_history(_LEGACY_PROPOSALS_PATH) if path == PROPOSALS_PATH else []\n    return historical + load_json_history(path)',1)
s=s.replace('bruto = json.loads(limpo)','bruto = json.loads(limpo, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"JSON nao finito: {value}")))')
s=s.replace('except (json.JSONDecodeError, ValueError) as exc:','except (json.JSONDecodeError, ValueError, RecursionError) as exc:')
a=s.index('    vistos = {p.get("proposal_id") for p in load_proposals(path)}');b=s.index('    return propostas',a)
s=s[:a]+'''    with file_lock(path):
        vistos = {p.get("proposal_id") for p in load_proposals(path)}
        propostas = parse_proposals(
            texto,
            proposed_at=(now or datetime.now(UTC)).isoformat(),
            proposer=proposer_name,
            horizon_days=horizon_days,
            vistos={v for v in vistos if v},
        )
        current = load_json_history(path)
        payload = json.dumps(current + [asdict(row) for row in propostas], ensure_ascii=False, indent=2, allow_nan=False)
        atomic_write(path, (payload + "\\n").encode("utf-8"))
''' + s[b:]
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/analyzers/hypothesis_loop_runner.py';s=f.read_text(encoding='utf-8').replace('EVALUATIONS_PATH = DATA_DIR / "research" / "hypothesis_evaluations.json"','EVALUATIONS_PATH = DATA_DIR / "research" / "hypothesis_evaluations.json"\n_LEGACY_EVALUATIONS_PATH = Path(__file__).resolve().parent.parent / "hypothesis_evaluations.json"').replace('    return load_json_history(path)','    historical = load_json_history(_LEGACY_EVALUATIONS_PATH) if path == EVALUATIONS_PATH else []\n    return historical + load_json_history(path)',1);f.write_text(s,encoding='utf-8')
