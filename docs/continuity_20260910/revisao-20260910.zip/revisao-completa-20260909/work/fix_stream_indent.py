from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910/GarimpoInvestimentos/trading/binance_spot_collector.py')
s=p.read_text(encoding='utf-8').replace('    def _default_db() -> Path:\n','def _default_db() -> Path:\n');p.write_text(s,encoding='utf-8')
