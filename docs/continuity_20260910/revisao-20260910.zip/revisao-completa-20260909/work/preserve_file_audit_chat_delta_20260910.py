import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
F = R / 'organization_20260910'
D = R / 'chat_closure_20260910'
source = Path(r'C:\Users\leona\.codex\sessions\2026\09\09\rollout-2026-09-09T18-45-21-01a08821-f27f-7970-a87f-f37b1e249910.jsonl')
manifest = json.loads((D / 'manifest.json').read_bytes())
prefix_bytes = (D / 'session.private.jsonl').stat().st_size
digest = hashlib.sha256()
with source.open('rb') as stream:
    remaining = prefix_bytes
    while remaining:
        block = stream.read(min(1048576, remaining))
        assert block
        remaining -= len(block)
        digest.update(block)
    assert digest.hexdigest() == manifest['files']['session.private.jsonl']
    tail = stream.read()
tail = tail[:tail.rfind(b'\n') + 1]
assert tail
records = [json.loads(line) for line in tail.splitlines()]
assert any('confere os arquivos' in json.dumps(record, ensure_ascii=False) for record in records)
target = F / 'chat_delta.private.jsonl'
with target.open('xb') as stream:
    stream.write(tail)
result = {'captured_at_utc': datetime.now(UTC).isoformat(), 'prefix_backup': str(D / 'session.private.jsonl'),
          'prefix_bytes': prefix_bytes, 'prefix_sha256': digest.hexdigest(), 'delta_file': str(target), 'delta_bytes': len(tail),
          'delta_sha256': hashlib.sha256(tail).hexdigest(), 'records': len(records), 'first_event_at': records[0].get('timestamp'),
          'last_event_at': records[-1].get('timestamp'), 'prefix_still_matches_source': True, 'every_delta_record_valid_json': True,
          'scope': 'Private continuation after the earlier chat backup; records after this explicit cut are not included. Not published in Git.'}
(F / 'chat_delta.private_manifest.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if 'sha256' not in k}, ensure_ascii=False))
