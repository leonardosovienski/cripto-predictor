import hashlib
import json
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

from GarimpoInvestimentos.security.redaction import configured_secret_values

P = Path(r'C:\Cripto\revisao-arquivos-20260910')
O = Path(r'C:\Cripto\pesquisa-20260909')
R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
F = R / 'organization_20260910'
E = P / 'docs/evidence/file_document_audit_20260910'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=P)

manifest = json.loads((E / 'manifest.json').read_bytes())
assert {x.name for x in E.iterdir() if x.is_file() and x.name != 'manifest.json'} == set(manifest['files'])
for name, digest in manifest['files'].items():
    assert hashlib.sha256((E / name).read_bytes()).hexdigest() == digest, name
    assert hashlib.sha256(git('show', ':' + (E / name).relative_to(P).as_posix())).hexdigest() == digest, name
assert not git('diff', '--cached', 'origin/main', '--', 'GarimpoInvestimentos', 'scripts', 'tests', 'charters', 'pyproject.toml', 'uv.lock', '.github')
assert not git('diff', '--cached', 'origin/main', '--', 'docs/NEXT_CHAT_PROMPT.md', 'docs/session_archive_20260908', 'docs/session_archive_20260907', 'docs/source_archive_20260908', 'docs/continuity_20260909')
assert hashlib.sha256((O / 'docs/NEXT_CHAT_PROMPT.md').read_bytes()).hexdigest() == '8969db38ef9a3ec29ee16a780b9572ec9f7d7808cabc9bac17a319616b47fe20'
secrets = [x.encode() for x in configured_secret_values() if len(x) >= 8]
assert secrets
changed = git('diff', '--cached', '--name-only', 'origin/main').decode().splitlines()
assert changed
for name in changed:
    data = git('show', ':' + name)
    assert not any(value in data for value in secrets), 'Configured secret found in staged publication'
    assert name == '.gitattributes' or name.endswith('.md') or name.startswith('docs/evidence/file_document_audit_20260910/')
    if name.endswith('.json'):
        json.loads(data)
frozen = Path(r'C:\Cripto\auditoria-ampliada-20260910')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=frozen, text=True).strip() == '595f1203475d04b01966ac3471bbafd6770dbb4d'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=frozen)
old = O / 'docs/evidence/remaining_dependencies_20260910'
for name, digest in json.loads((old / 'manifest.json').read_bytes())['files'].items():
    assert hashlib.sha256((old / name).read_bytes()).hexdigest() == digest
    assert hashlib.sha256(git('show', ':' + (old / name).relative_to(O).as_posix())).hexdigest() == digest
closure = R / 'chat_closure_20260910'
cm = json.loads((closure / 'manifest.json').read_bytes())
for name, digest in cm['files'].items():
    with (closure / name).open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == digest
assert hashlib.sha256(Path(cm['handoff_path']).read_bytes()).hexdigest() == cm['handoff_sha256']
docs = json.loads((F / 'updated_markdown_summary.json').read_bytes())
assert not docs['unresolved_current_links'] and not docs['historical_targets_missing_at_origin'] and not docs['utf8_errors']
original = json.loads((F / 'original_files_verification.private.json').read_bytes())
archive = json.loads((F / 'migration_archive_verification.json').read_bytes())
runtime = json.loads((F / 'frozen_runtime_validation.json').read_bytes())
assert original['status'] == archive['status'] == runtime['status'] == 'PASS'
record = {'status': 'PASS', 'at_utc': datetime.now(UTC).isoformat(), 'base': git('rev-parse', 'origin/main').decode().strip(),
          'changed_files': changed, 'manifest_files_verified_in_index': len(manifest['files']), 'configured_secret_matches': 0,
          'existing_evidence_files_verified': 31, 'runtime_tests_locks_charters_ci_unchanged': True, 'frozen_executor_unchanged': True,
          'prompt_and_private_chat_backup_unchanged': True, 'markdown': docs, 'network_calls': 0}
(F / 'artifact_validation.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in record.items() if k not in ('changed_files', 'markdown')}))
