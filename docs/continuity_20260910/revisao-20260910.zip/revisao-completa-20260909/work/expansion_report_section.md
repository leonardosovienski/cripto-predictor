## 16. Auditoria ampliada: temporalidade, execução, dados e preservação

Esta etapa começou novamente pelo estado real e pela nova linha de base completa no main `ffd6c327e2d323758f6ab6abac4ab15ef5ca0881`, após #114. Implementação em `C:\Cripto\auditoria-ampliada-20260910`, branch `fix/audit-expansion-20260910`. A revisão abaixo corrige alegações operacionais anteriores; documentos e resultados congelados mantêm seus bytes.

**Integração:** PR #115 integrado em a917927 e conferido no main: quatro jobs aprovados antes e depois do merge; 1.504 testes locais aprovados, um skip Windows e zero falhas antes e após integração. Prompt do dono e evidências congeladas preservados. Código integrado e validação de engenharia concluídos; dependências de evidência e renovação normal da quota permanecem explícitas. [PR #115](https://github.com/leonardosovienski/cripto-predictor/pull/115).

O documento versionado [Auditoria ampliada](C:/Cripto/auditoria-ampliada-20260910/docs/AUDITORIA_AMPLIADA_20260910.md) contém a matriz de defeitos, correções, fontes primárias, profundidade real da revisão e dependências concretas. Esta seção não equivale a afirmar leitura integral de todo arquivo restaurado nem lucro validado.

**Validação independente da linha de base:** [expansion_baseline01](expansion_baseline01/validation.json): 1394 aprovados, 0 falhas, 1 skips; sync_all_extras=0, ruff=0, format=0, pyright=0, secrets=0, build=0, tests=0, coverage=0, coverage_json=0, windows_status=0, windows_help=0.

**Validação final da correção:** [expansion_full03](expansion_full03/validation.json): 1504 aprovados, 0 falhas, 1 skips; sync_all_extras=0, ruff=0, format=0, pyright=0, secrets=0, build=0, tests=0, coverage=0, coverage_json=0, windows_status=0, windows_help=0.

As suítes intermediárias estão preservadas. `expansion_full01` teve 1.464 aprovações/14 falhas/um skip; eram expectativas antigas incompatíveis com a correção, tratadas com testes de recusa explícita. `expansion_full02` antecede a última correção de isolamento do orçamento e não certifica seu código. Os casos adversariais before3 (49 falhas/3 passes), before4 (12 falhas), before5 (6 falhas/2 passes) e anchor_before (2 falhas/2 passes) são contagens de casos, não de causas independentes.

**Correções principais:** contratos de ordem/fill e reconciliação econômica; transações e conflitos em SQLite/CSV; locks e persistência atômica; continuidade de manifesto e cadeia pública; fonte spot Binance correta e unidade pós-2025; datas de recebimento e vintages; cache com TTL e hash dos dados de treino; indicadores e janelas causais; HMM transacional; cálculo aritmético de retorno, funding por evento, barreiras a preço observado, Sharpe sem sqrt(n); registros de sweep antes de resultados; paper sem falsa promoção; saúde com timestamps e amostra semanal válidos; exportação sem injeção de fórmula; plugin consulta o charter atual.

**Resultado econômico:** WFA novo publica `UNVALIDATED`, diagnóstico separado e capital=false. Bps de cenário não são calibração de execução. PSR IID com retornos sobrepostos não é confiança confirmatória. Nenhuma família encerrada foi reaberta. O Aave da seção 15 continua histórico positivo condicional; não existe execução pessoal ou lucro futuro comprovado.

**Fonte real:** [resultado da recuperação spot](C:/Cripto/operacao/dados/spot-source-audit-20260910/result.json): 743 candles BTC e 743 ETH de agosto/2026, checksums conferidos, 48 comparações com REST sem divergência. Seis chamadas, dois ativos. Corte 31/08 23:59:59.999 UTC exclui corretamente a última hora ainda aberta; não é mês integral. Brutos e recibos preservados. Arquivo antigo chamado spot não foi recopiado para fingir fonte correta.

**Incidente adicional da própria validação:** [evidência do orçamento](expansion_budget_incident/result.json). Duas rotinas de teste podiam apagar o banco operacional por chamar `reset_for_test` sem path temporário. A tabela estava vazia antes da recuperação spot, logo zero não atesta consumo anterior. O helper não apaga mais contador e a fixture agora isola o banco. Backup preservado; a quota corrente foi reservada conservadoramente, sem ampliar limite nem atribuir consumo medido à reserva. Novas chamadas de ingestão/notícias/LLM ficam bloqueadas até o próximo dia UTC. A contagem exata anterior não é recuperável apenas pelo banco restante.

**Pendências de evidência:** inputs H5 originais; versões históricas macro comprovadamente disponíveis; custos/fills/mark/liquidez do instrumento e execução pessoal; amostra futura de 84 dias; segunda fonte histórica Aave; comprovação de revogação/uso antigo nos painéis. Falta de histórico exato não se resolve com outro pacote Python. Cobertura universal dos arquivos/anos fora dos recortes não foi certificada. Segurança administrativa da branch permanece excluída pelo dono.

**Compatibilidade operacional:** consumidores diários exigem `daily-v4-audited`, modelos HMM schema 2 e sinais schema 3.2.0. Caches antigos não recebem identidade nova por renomeação; novos dados/derivações exigem procedência. Os futuros protocolos manuais congelados continuam usando seus executores próprios, sem scheduler. Atualização de snapshots diários é coleta operacional normal na próxima quota, não amostra científica obtida retroativamente.

**Registro futuro conferido:** carry v2 permanece WAITING, zero linhas. O registro LLM v2 foi preservado e recusou o código modificado. O novo `llm-paired-manual-20260912-v3` mantém protocolo/datas/ambiente e tem 84 horários futuros, sem observações. Ele vincula o executor aos bytes da área `C:\Cripto\auditoria-ampliada-20260910`, inclusive a diferença LF/CRLF de local_runtime.py. Preserve essa área e use os comandos atualizados em docs/manual_dependencies_20260910/EXECUCAO.md, que passam pelo lançador explícito. Nenhum hash antigo foi alterado para forçar aprovação. [Status LLM novo](expansion_llm_status_v3.json), [carry](expansion_carry_status.json).

[CI do PR final](expansion_ci_pr_final.json).

[CI após merge](expansion_ci_main.json).

[Verificação operacional e preservação](expansion_operational.json).

**Conferência local após merge:** [postmerge_expansion01](postmerge_expansion01/validation.json): 1504 aprovados, 0 falhas, 1 skips; sync_all_extras=0, build=0, windows_status=0, windows_help=0, tests=0.

[Wheel instalado fora do checkout](expansion_full03/wheel_contract.json); [consistência dos 79 pacotes](expansion_full03/dependency_consistency.log). Cobertura da correção: 87,433155% no escopo runtime com branches; não é percentual de auditoria manual.

Registro desta seção atualizado em 2026-09-10T18:16:49.911284+00:00.
