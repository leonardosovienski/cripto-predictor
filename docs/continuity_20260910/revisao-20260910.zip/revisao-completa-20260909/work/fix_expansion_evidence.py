from pathlib import Path
P=Path(r'C:\Cripto\auditoria-ampliada-20260910')
def edit(name,old,new):
    p=P/name;s=p.read_text(encoding='utf-8');assert old in s,(name,old[:60]);p.write_text(s.replace(old,new),encoding='utf-8')
c='GarimpoInvestimentos/dpl/feature_store.py'
edit(c,'    def write_signals(\n','''    def write_signals(self, signals: list[SignalPoint], *, require_enriched: bool = False, scientific_state: str = "COLLECTION_ONLY") -> int:
        # Serialize identity checks with insertion, including other processes.
        with self._conn:
            if not self._conn.in_transaction:
                self._conn.execute("BEGIN IMMEDIATE")
            return self._write_signals(signals, require_enriched=require_enriched, scientific_state=scientific_state)

    def _write_signals(
''')
edit(c,'            self._check_temporal(f"{s.source}/{s.name}", s.timestamp, s.published_at)','''            if not math.isfinite(s.value):
                raise ValueError("signal value must be finite")
            if "available_at_receipt" in s.quality_flags:
                if s.vintage != s.published_at or s.published_at < s.timestamp or (s.ingested_at is not None and s.ingested_at < s.published_at):
                    raise ValueError("invalid observed-vintage timestamp")
            else:
                self._check_temporal(f"{s.source}/{s.name}", s.timestamp, s.published_at)''')
edit(c,'            # Provider batches can repeat an observation. First-valid-wins makes\n            # retries deterministic and matches the resilience contract.\n            if key in unique:\n                continue','''            if key in unique:
                if unique[key] != s:
                    raise ValueError("conflicting duplicate observation in batch")
                continue''')
edit(c,'"""SELECT content_hash FROM raw_signals','"""SELECT * FROM raw_signals')
starttext='''            if (
                existing
                and existing["content_hash"]
                and s.content_hash
                and existing["content_hash"] != s.content_hash
            ):
                raise ValueError(
                    "duplicate observation key has a different content_hash; "
                    "use a later vintage for a genuine revision"
                )'''
edit(c,starttext,'''            if existing:
                expected = {
                    "value": s.value, "published_at": _iso(s.published_at),
                    "reference_date": _iso(s.reference_date) if s.reference_date else None,
                    "instrument": s.instrument, "metric": s.metric, "unit": s.unit,
                    "event_at": _iso(s.event_at) if s.event_at else None,
                    "ingested_at": _iso(s.ingested_at) if s.ingested_at else None,
                    "content_hash": s.content_hash, "collector_version": s.collector_version,
                    "schema_version": s.schema_version, "quality_flags": json.dumps(sorted(s.quality_flags)),
                    "scientific_state": scientific_state,
                }
                if any(existing[k] != v for k,v in expected.items()):
                    raise ValueError("duplicate observation key has conflicting content_hash or metadata; use a later vintage")
                continue''')
edit(c,'WHERE source=? AND name=? AND ts=? AND content_hash=? LIMIT 1','WHERE source=? AND name=? AND ts=? AND content_hash=? AND collector_version=? AND quality_flags=? AND value=? LIMIT 1')
edit(c,'(s.source, s.name, _iso(s.timestamp), s.content_hash),','(s.source, s.name, _iso(s.timestamp), s.content_hash, s.collector_version, json.dumps(sorted(s.quality_flags)), s.value),')

c='GarimpoInvestimentos/quality_snapshot.py'
edit(c,'from GarimpoInvestimentos.phase1_watchdog import check_phase1_health','from GarimpoInvestimentos.phase1_watchdog import check_phase1_health\nfrom GarimpoInvestimentos.durable_io import atomic_write, file_lock, strict_json_loads')
edit(c,'    path.parent.mkdir(parents=True, exist_ok=True)\n    with open(path, "a", encoding="utf-8") as f:\n        f.write(json.dumps(_history_record(snap), sort_keys=True) + "\\n")','''    with file_lock(path):
        original = path.read_text(encoding="utf-8") if path.exists() else ""
        for line in original.splitlines():
            if not isinstance(strict_json_loads(line),dict):
                raise ValueError("invalid snapshot history")
        encoded = json.dumps(_history_record(snap),sort_keys=True,allow_nan=False)+"\\n"
        atomic_write(path, (original.rstrip("\\n")+("\\n" if original else "")+encoded).encode("utf-8"))''')
# Lock the public state read/check/write transaction and preserve corrupt bytes.
p=P/c;s=p.read_text(encoding='utf-8');a=s.index('    novo = h6_status_payload(snap)',s.index('def write_h6_status'));b=s.index('\n\ndef main(',a)
body=s[a:b]
start=body.index('        try:\n');end=body.index('        if isinstance(atual, dict):',start)
body=body[:start]+'''        atual = strict_json_loads(path.read_text(encoding="utf-8"))
        if not isinstance(atual,dict):
            raise ValueError("invalid public H6 status; preserve before recovery")
'''+body[end:]
body=body.replace('    path.write_text(json.dumps(novo, indent=2, sort_keys=True) + "\\n", encoding="utf-8")','    atomic_write(path, (json.dumps(novo, indent=2, sort_keys=True,allow_nan=False)+"\\n").encode("utf-8"))')
s=s[:a]+'    with file_lock(path):\n'+''.join('    '+line+'\n' if line else '\n' for line in body.splitlines())+s[b:]
# Public anchor publication happens with DB prefix verification and file lock.
old='''            manifest = chain_manifest(_store._conn)
        if not report.ok:'''
new='''            manifest = chain_manifest(_store._conn)
            if not report.ok:
                raise ValueError("ledger verification failed before manifest publication")
            with file_lock(manifest_path):
                anterior = strict_json_loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else None
                if anterior is not None:
                    if not isinstance(anterior,dict) or anterior.get("schema") != 1:
                        raise ValueError("invalid prior manifest; preserve before recovery")
                    aid, head = anterior.get("head_archive_id"), anterior.get("head")
                    if aid is not None:
                        prefix = _store._conn.execute("SELECT chain_hash FROM predictions_archive_chain WHERE archive_id=?",(aid,)).fetchone()
                        count = _store._conn.execute("SELECT COUNT(*) FROM predictions_archive_chain WHERE archive_id<=?",(aid,)).fetchone()[0]
                        if prefix is None or prefix[0] != head or count != anterior.get("entries"):
                            raise ValueError("prior public manifest is not a verified prefix of this ledger")
                    elif head is not None or anterior.get("entries") != 0:
                        raise ValueError("invalid empty prior manifest")
                if anterior is None or anterior.get("head") != manifest.get("head"):
                    atomic_write(manifest_path,(json.dumps(manifest,indent=2,sort_keys=True,allow_nan=False)+"\\n").encode("utf-8"))
        if not report.ok:'''
assert old in s;s=s.replace(old,new)
a=s.index('        anterior = None\n',s.index('def main'));b=s.index('    except Exception as _chain_exc:',a)
s=s[:a]+s[b:]
p.write_text(s,encoding='utf-8')

# Tests formerly demanded overwriting damaged evidence; preserve and refuse now.
p=P/'tests/test_quality_snapshot.py';s=p.read_text(encoding='utf-8')
for name,next_name in [('test_arquivo_corrompido_e_reescrito_em_vez_de_explodir','test_arquivo_com_bytes_nao_utf8_tambem_e_reescrito'),('test_arquivo_com_bytes_nao_utf8_tambem_e_reescrito','test_artefato_nao_e_capturado_por_nenhuma_regra_do_gitignore')]:
    a=s.index('def '+name);b=s.index('def '+next_name,a)
    sub=s[a:b].replace('    assert quality_snapshot.write_h6_status(_snap(6), destino) == quality_snapshot.H6_WRITTEN\n    assert json.loads(destino.read_text(encoding="utf-8"))["n"] == 6','    before = destino.read_bytes()\n    with __import__("pytest").raises(ValueError):\n        quality_snapshot.write_h6_status(_snap(6), destino)\n    assert destino.read_bytes() == before')
    s=s[:a]+sub+s[b:]
s=s.replace('test_arquivo_corrompido_e_reescrito_em_vez_de_explodir','test_arquivo_corrompido_preservado_com_erro').replace('test_arquivo_com_bytes_nao_utf8_tambem_e_reescrito','test_arquivo_com_bytes_nao_utf8_preservado_com_erro')
p.write_text(s,encoding='utf-8')
