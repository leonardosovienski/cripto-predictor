# Ampliação de auditoria em andamento — 10/09/2026

Base: ffd6c327e2d323758f6ab6abac4ab15ef5ca0881, igual ao main remoto conferido. Diff do dono em NEXT_CHAT_PROMPT preservado. Nenhum agente, scheduler, operação financeira, credencial financeira ou mudança de proteção da branch.

Linha de base: expansion_baseline01/validation.json (aguardar conclusão antes de alterar código). Regressores antes da correção: work/test_expansion_regressions.py; expansion_before.xml/log (30 falhas, 3 pass), expansion_before2.xml/log (segunda rodada).

Confirmados por reprodução: repetição/conflito de fill; reconciliação cega a preço/taxa/identidade/tempo; sobrescrita de ordem com mesmo ID; NaN/inf nos contratos; fill anterior à ordem; duplicação de níveis; book alterado parcialmente após erro/cruzamento; quantidade pequena reportada como preenchida sem VWAP; perda de lotes no relatório de carteira; duplicatas no lote e conflito ignorado nos três CSVs V3.

Segunda rodada: lag maior que série muda comprimento; DSL aceita receitas inválidas na construção; Spearman do harness ignora empates (score constante vira correlação); duplicação mascara previsão ausente; PBO aceita NaN; equivalência aprova zero comparações.

Leitura adicional a reproduzir/corrigir:
- Vision usa futures/um para o arquivo chamado spot; checksum de cache não é revalidado; unidade spot pós-2025 é microssegundo (fonte oficial Binance lida em 10/09).
- DXY: diária é frequência de observação, não publicação. H.10 publica semana anterior e série é revisável. FRED atual mostra 04/09 publicado em 08/09 15:16 CDT. Não certificar 1 dia útil/00h como disponibilidade. Usar recibo da versão atual; histórico causal exige vintage. Macro_features original faz hipótese de lag, não prova causalidade.
- Cost_policy declara perp calibrado sem evidência e permite for_verdict=True. Correção legítima de contrato + errata necessária.
- Paper: escrita retrospectiva chamada prospectiva; relatório mistura soma log com equity aritmética, ignora horizonte por linha, duplica e não inclui equity inicial. Preservar livros congelados, impedir novas promessas/entradas inválidas.
- Microstructure collector: NaN em trades/BBO; install_snapshot não invalida estado antigo quando aplicação do buffer falha; reconnect não limpa books/tarefas antigas; snapshot watchdog fica stale embora diffs saudáveis; scorecard não mede saltos crescentes de sequência e publica resynchronizations=0 sem ler saúde.
- TradingStore denso descarta venue e converte sessão curta para hex na leitura; latest_microstructure descompacta histórico inteiro. Reproduzir antes de mudar.

Leitura direta adicional já realizada: trading contracts/execution/portfolio/costs/cost_policy/report/signal_adapter/microstructure/binance_spot_collector/microstructure_quality; store linhas 158–600 (resto ainda falta); v3 collectors funding/oi/spot/binance_vision, vision_ingest, signal_engine, paper_trader, paper_report, daily, macro_features; pipeline 1–240; analyzers factor_dsl/pbo/equivalence/judge_calibration/gate_power/ground_truth_harness; dpl providers dxy/fear_greed; business_days; observation_collect; CI/pyproject/configuração/mandato.

O restante da cobertura deve continuar explícito; nenhum registro de leitura integral dos arquivos restantes deve ser inferido desta lista. Manter REVISAO.md como relatório vivo final; este arquivo é controle de trabalho, não conclusão.

## Estado atualizado desta ampliacao (10/09, em andamento)

Worktree de correcao: C:\Cripto\auditoria-ampliada-20260910, branch fix/audit-expansion-20260910, base ffd6c327e2d323758f6ab6abac4ab15ef5ca0881. Nenhum commit/push/PR desta ampliacao ainda. P0 e prompt do dono intocados.

Linha de base expansion_baseline01 COMPLETA: sync, ruff, format, pyright, segredos, build, cobertura/suite Windows, status/help PASS. Logs e validation.json preservados. Correcao nao altera a base dessa medicao.

- expansion_before3: 49 falhas / 3 passes em 52 casos adversariais (nao 49 causas distintas).
- expansion_trade01: 156 passes / 26 falhas; 25 ainda nao corrigidas naquela etapa, 1 fixture de ordem com fills apontando outra ordem.
- expansion_group04: 145 passes / 1 falha de teste legado que exigia ignorar JSON corrompido (teste corrigido para recusar/preservar).
- expansion_group05: 150 passes (inclui 52 regressores + sources + model integrity + DSL/H8/DXY/HMM/coverage).
- expansion_group06: 84 passes / 5 expectativas antigas a atualizar (equity inicial, resultado ausente None, log vs aritmetico no paper, ignorar JSONL corrompido). Novos testes de barriers/funding/custos/guard paper PASS. Integracao H7 sintetica com published_at explicito passou.
- expansion_pyright02: PASS 0 erros/avisos no ESCOPO CONFIGURADO (nao no projeto inteiro); usar --pythonpath C:\Cripto\pesquisa-20260909\.venv\Scripts\python.exe para worktree sem venv. Tentativa01 sem pythonpath falhou por import resolucao e e evidencia de setup, nao defeito runtime.
- ruff02 corrigiu imports/format, PASS na etapa; novas alteracoes posteriores precisam repetir.

Helpers work/fix_expansion_*.py ja aplicados: trading, csv, science, store, stream, sources, macro, features_model, history_tests, costs, signals, paper, backtest. Nao reexecutar (alguns dependem dos trechos antigos).
Runtime para P: CRIPTO.cmd python ...\work\isolated_python.py -m pytest/ruff/etc. Faz chdir + sys.path P, usa venv autorizado original.

Correcao implementada (ainda requer verificacao final conjunta):
- Trading: fills idempotentes/conflitos, reconciliacao completa, contratos finitos e tempos, ledger IDs, book atomico e qty pequena, agregacao de lotes.
- durable_io novo: OS locks Windows/POSIX + atomic writes. CSVs dedup/conflict/symbol/finite validation e paginas monotonic/range; spot aberto removido antes do retorno/persistencia.
- DSL validacao no construtor e lag curto; Spearman empates/duplicatas; PBO NaN; equivalencia semcomparacoes falha e comparacao runtime semtimestamps nao atesta equivalencia.
- Tracos cientificos novos em DATA_DIR/research; le historicos do pacote como legado readonly; append locked/atomic sem apagar corrupcao, run_round valida antes de LLM e serializa classificacao de duplicata+append. H8 alvo por timestamp exato, bloco correto 3obs/dia.
- Store: migration0006 session_text/collector_version; venue denso restrito, hashes completos, latest decodifica apenas ultimos porgrupo, compactacao checa payload/metadados e apaga somente PK verificada (sem loop infinito).
- Stream: finitos/IDs/UTC, snapshot invalida falha, reconnect reseta e encerra todas as tasks; shutdown interrompe espera, health resnapshot real. Quality gaps/session, bins de minuto em coverage (nao uptime), snapshot freshness por sessao/diffs.
- Vision: spot usa mercado spot, microssegundos2025 normalizados, cache verified_v2 por mercado com checksum obrigatorio e recibo/hash; ZIP 1CSV64MiB; OI invalid/symbol nao ignorado. Novo spot_binance_1h.csv em consumidores; NENHUM dado antigo renomeado/copiado automaticamente.
- DXY: FRED atual carimba published_at/vintage=recebimento; nao inventa lag. Macro_dxy exige available_at ou modo explicitamente hipotetico de reproducao; WFA exige CSV com published_at e cobertura completa; datasUTC/hora respeitadas. CSV DXY valida headers, finitos e conflito.
- Features: vol24h=24retornos/25closes completos, lacunas funding8h rejeitadas, O(logn) asof, indices copiados, volume apenas candlefechado, MODEL_SCHEMA_VERSION=2.
- HMM: refit transacional, rejeita legacy semfingerprint, atomicpickle, inversas uma vez/estado, training_data_hash; cache pipeline por schema+hash e outputs explicitamente REPLAY em novo arquivo.
- Sinais: frozen dataclass, finitos/domino, timestampfuturorecusado, enginehashparametros, JSONL dedup/conflict lockedatomic.
- Custos: parametros finitos, fee entrada/saida comnocionalreal; perp NAO marcado calibrado so por terhistorico; assertions deveredicto recusam ambos os modelos semcalibracaoreal.
- Backtest: barreira ao preco observado (nao thresholdinventado), maturidade/lacunas corretas, duracao saida real, expm1 log->aritmetico, funding por eventos/marcas com cobertura e missingfail, HAC para erro IS sobreposto, novas mensagens sem AUTORIZADA. Ainda spot proxy para perp -> DESCRIPTIVE_REPLAY e capitalfalse, nao lucro executavel. Grid inclui family frozen.
- Paper: run_paper bloqueia familia congelada antespipeline; ledger JSONL naoignora corrupcao e appendatomico; timestampentryreal/newmode teorico. Report horizonteporlinha, duplicatasrecusadas, retornoaritmetico, ausencia None; maxDD/PnLcarteira indisponiveis semalocacao/custos/fills/markpath, soma bruta portrade explicita. 5 testslegados atualizar conforme resultados group06.

PENDENCIAS EXECUTAVEIS AINDA:
1. Revisar as proprias correcoes e ampliar regressores de store atomic/conflict/limiteddecode, paginacao/cache, sinaisconfig, paperhorizonte/duplicatas, datas e defasagem das OUTRAS fontes (abaixo). Algumas validacoes precisam completar.
2. Backtest ainda escreve wfa_returns.json sobrescrevendo e params incompletos; versionar cada run + hashes/params. Kelly sweep ainda nao registra tentativas nem bloqueia frozenfamily; fazer antes de qualquerresultado. Parametros/escala de Sharpe e outputs ainda exigem revisao final.
3. Source availability DEFEITO RECEM LIDO: BCB ref+lag presumido embora SGS atual revise; FearGreed cache eterno mutavel e published_at=ts nao comprovado; derivatives.py funding/OI published_at=exchange sem recibo; macro_calendar.py assume calendario atual sempre conhecido no passado. Corrigir para observed vintage / flags e historico exige evidencia; preservar snapshots. Macro features calendar semproveniencia ainda aceita historico. Nao afirmar todasfontesOK.
4. Shape/finite signalposterior: atualmente checksbounds mas naosomatorio1; testsstub confrest0, alterarstub para posteriorvalido quandohabilitar. HMM fithash, integer/model chronology e floats extreme revisar. Factor arithmetic overflow ainda podeNaN/inf, methodunknownconstructionguardestaok.
5. Report paper retrospective_records hoje conta so na fase comspot; contar mesmo semprecos. _already_recorded retorna cedo e nao detecta corrupcaolater, embora nao reescreva nessescasos; preferir validarhistoricotodo.
6. Full baseline corrigida/sync locked all extras/build/ruffformat/pyright/secret/fullcoverage/integracao CI quatro jobs contra base atual + apos merge; ainda NAO executados.
7. Auditar restantes modulos ativos/scripts/infra previstosrepasse (inventario gitls-files); atualizar coverage map leitura real vs suites, semconfundir90%codcovcomauditmanual. Muitos wrappers/shims pequenos; contratos/persistence/renewal_research/profit_research recem lidos integralmente semnovadefeitorepro.
8. Artefato final: adicionar secao16 ao REVISAO.md canonicolive via builder (preservar sectionsold); errata fonte/calibracao/modelo e lista de breakslegit/testsupdates. Nao alterar NEXT_CHAT dono nem evidenciafrozen/manifestos.

Fontes primarias lidas pela web em 10/09:
https://www.federalreserve.gov/releases/h10/about.htm (H.10 semanal, releases antigos nao revisados)
https://fred.stlouisfed.org/series/DTWEXBGS (04/09 atualizado08/09/2026 15:16CDT, dailyobs revisavel)
https://github.com/binance/binance-public-data/blob/master/README.md (spot/futures separados, spot2025microseconds, checksums e archiveupdates)

## Encerramento da ampliacao — 10/09/2026 18:16 UTC

Os itens executaveis listados acima foram tratados; ler agora REVISAO.md secao16 e expansion_integration.json, nao interpretar os rascunhos anteriores como estado atual.

PR115 integrado em a9179270a55a31caa0f9bfc251d373c53034ebb1. Implementacao9d89871, documentacao final595f120, tree2f203f7938b49b6a9a5fb64d7295958051918c80. Quatro jobs PASS no PR final34511800012 e main34512528458. Full03 Windows1504passed1skip0fail, Ruff/format/Pyright/secrets/build/wheel e79pacotescompativeis. Posmerge_expansion01 Windows1504passed1skip0fail; codigo operacionalP0 restaurado como instalacao editable e treeigualtestada. Prompt8969db38ef9a3ec29ee16a780b9572ec9f7d7808cabc9bac17a319616b47fe20 preservado; unica alteracao local do P0 continua o prompt do dono.

Achado adicional durante validacao: reset_for_test apagava contadoroperacional em dois testes semisolamento. Corrigido para nunca apagarDB e fixturetemporaria. Contadoranteriorvazio e aposduasingestoesspot=2; backupem expansion_budget_incident. Quota10/09UTC reservadaconservadoramente28/8/6, NAOconsumomedido; nenhumreset/ampliacao. Posmergetestes preservaram essa reserva. Proximaingestao normal a partir11/09 00UTC (10/09 21Brasilia), semagendamento. Snapshotoperacionalexistente ainda daily-v3, novo codigo exige daily-v4; nao promover dadoantigo. Codigoestavalidado; frescoroperacionaldependedanovacoleta.

Fontepontualspot1486candles BTC/ETH Agosto (corteantesdo ultimofechamento),6HTTP,checksums e48comparacoesREST exatas: C:/Cripto/operacao/dados/spot-source-audit-20260910.

PRESERVAR W=C:/Cripto/auditoria-ampliada-20260910: registro LLM manualv3 vincula hashes exatos nessaarea. V2 preservado semobservacoesrecusouconfig/api_guard alterados; local_runtime.py tambemdiferiu porLF/CRLF entreW eP0 (semalteracaologica). V3mantem protocolo/datas/ambiente,84horariosfuturos. Comandos em docs/manual_dependencies_20260910/EXECUCAO.md usam CRIPTO.cmd python R/work/isolated_python.py -m scripts.paired_llm --directory C:/Cripto/operacao/dados/llm-paired-manual-20260912-v3. Carregar P0diretamentenaosatisfazessecongelamento. Carryv2WAITING0linhas. Nenhumtick/automacao/ordem/conta/pagamentoativado.

Dependenciasdeevidencia: H5inputsoriginais, vintagesmacro, custos/fills/mark/liquidezpessoais, futuraamostra84dias, segundafonteAave, paineisrevogacaousoantigo. Protecaobranchfoiexcluidapelodono. Nao declararlucrovalidadoouauditoriamanualuniversaldearquivos. Nenhuma sessao de teste ficou aberta ao concluir esta etapa.
