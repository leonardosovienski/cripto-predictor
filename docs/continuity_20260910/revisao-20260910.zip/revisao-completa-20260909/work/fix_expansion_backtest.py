from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
f=p/'GarimpoInvestimentos/v3/backtest_v3.py';s=f.read_text(encoding='utf-8')
s=s.replace('from dataclasses import', 'from dataclasses import',1)
a=s.index('# Fração de Kelly homologada');b=s.index('DEFAULT_KELLY_FRACTION =',a);s=s[:a]+'# Historical research setting only. No production or capital approval.\n'+s[b:]
s=s.replace('    minimum_net_edge: float = _DEFAULT_MINIMUM_NET_EDGE\n\n\n@dataclass\nclass KellySweepResult','    minimum_net_edge: float = _DEFAULT_MINIMUM_NET_EDGE\n    scientific_state: str = "DESCRIPTIVE_REPLAY"\n    capital_enabled: bool = False\n    execution_assumption: str = "spot price proxy for perpetual; hourly-close exits; no fill validation"\n\n\n@dataclass\nclass KellySweepResult',1)
s=s.replace('    if close_start is None or close_end is None or close_start <= 0:','    if close_start is None or close_end is None or not math.isfinite(close_start) or not math.isfinite(close_end) or close_start <= 0 or close_end <= 0:')
s=s.replace('    return math.log(close_end / close_start)','    return math.log(close_end) - math.log(close_start)')
a=s.index('def _find_barrier_return(');b=s.index('def _ms_to_day_offset(',a)
s=s[:a]+'''@dataclass(frozen=True)
class BarrierExit:
    log_return: float
    reason: str
    elapsed_hours: int


def _barrier_exit(
    ts_ms: int, horizon_hours: int, direction: int,
    spot_index: "dict[int, float] | SortedTimeIndex",
    stop_loss_bps: float = 0.0, take_profit_bps: float = 0.0, tolerance_ms: int = 300_000,
) -> BarrierExit | None:
    """Hourly-close simulation. Barriers trigger at the observed price, never at an invented fill."""
    if isinstance(horizon_hours, bool) or not isinstance(horizon_hours, int) or horizon_hours < 1 or direction not in {-1, 1}:
        raise ValueError("horizonte/direcao invalido")
    if any(not math.isfinite(value) or value < 0 for value in (stop_loss_bps, take_profit_bps)):
        raise ValueError("barreiras devem ser finitas nao negativas")
    index = spot_index if isinstance(spot_index, SortedTimeIndex) else SortedTimeIndex(spot_index)
    entry = index.as_of(ts_ms - _SPOT_CANDLE_MS, tolerance_ms)
    if entry is None or not math.isfinite(entry) or entry <= 0:
        return None
    for hour in range(1, horizon_hours + 1):
        price = index.as_of(ts_ms + (hour - 1) * _SPOT_CANDLE_MS, tolerance_ms)
        if price is None or not math.isfinite(price) or price <= 0:
            if stop_loss_bps or take_profit_bps or hour == horizon_hours:
                return None  # Exit path or maturity is unobservable.
            continue
        log_return = math.log(price) - math.log(entry)
        signed_return = direction * (price / entry - 1)
        if stop_loss_bps and signed_return <= -stop_loss_bps / 10000:
            return BarrierExit(log_return, "stop_loss", hour)
        if take_profit_bps and signed_return >= take_profit_bps / 10000:
            return BarrierExit(log_return, "take_profit", hour)
        if hour == horizon_hours:
            return BarrierExit(log_return, "horizon", hour)
    return None


def _find_barrier_return(
    ts_ms: int, horizon_hours: int, direction: int,
    spot_index: "dict[int, float] | SortedTimeIndex",
    stop_loss_bps: float = 0.0, take_profit_bps: float = 0.0, tolerance_ms: int = 300_000,
) -> tuple[float, str] | None:
    result = _barrier_exit(ts_ms, horizon_hours, direction, spot_index, stop_loss_bps, take_profit_bps, tolerance_ms)
    return (result.log_return, result.reason) if result else None


def _realized_funding_pnl(position: float, entry_ms: int, exit_ms: int, entry_price: float, records: list) -> float | None:
    """Fixed-quantity linear-perpetual funding at observed settlement marks.

    Prices used by the existing strategy are still a spot proxy, so this does not
    establish executable perpetual P&L. Missing marks or settlement coverage fail closed.
    """
    if not math.isfinite(entry_price) or entry_price <= 0:
        raise ValueError("preco de entrada invalido")
    expected = set(range((entry_ms // _MS_PER_8H + 1) * _MS_PER_8H, exit_ms + 1, _MS_PER_8H))
    observed = {record.funding_time_ms: record for record in records if entry_ms < record.funding_time_ms <= exit_ms}
    if set(observed) != expected or any(record.mark_price <= 0 for record in observed.values()):
        return None
    return -position * sum(record.funding_rate * record.mark_price / entry_price for record in observed.values())


''' + s[b:]
s=s.replace('    equity: list[float] = []\n    acc = 1.0','    equity: list[float] = [1.0]\n    acc = 1.0',1)
s=s.replace('    num_slots = max(1, num_slots)','    if isinstance(num_slots, bool) or not isinstance(num_slots, int) or num_slots < 1:\n        raise ValueError("num_slots deve ser inteiro positivo")\n    if len({id(trade) for trade in trades}) != len(trades):\n        raise ValueError("trade duplicado")\n    if any(not math.isfinite(trade.net_return) or trade.net_return <= -1 or trade.horizon_hours <= 0 for trade in trades):\n        raise ValueError("trade invalido ou insolvencia sem modelo de liquidacao")',1)
s=s.replace('    if use_macro_dxy and dxy_closes_path is None:','    if isinstance(horizon_hours, bool) or not isinstance(horizon_hours, int) or horizon_hours < 1:\n        raise ValueError("horizon_hours deve ser inteiro positivo")\n    if not math.isfinite(kelly_fraction) or not 0 < kelly_fraction <= 1:\n        raise ValueError("kelly_fraction deve estar em (0,1]")\n    if use_macro_dxy and dxy_closes_path is None:',1)
s=s.replace('calibration_signal.direction * calibration_fwd','calibration_signal.direction * math.expm1(calibration_fwd)')
s=s.replace('                n_executed += 1\n                position =','                position =',1)
s=s.replace('                barrier = _find_barrier_return(','                barrier = _barrier_exit(',1)
a=s.index('                pnl_return = barrier[0]');b=s.index('                fold_gross.append(gross)',a)
s=s[:a]+'''                if barrier is None:
                    continue
                entry_price = spot_ti.as_of(fv.timestamp_exchange_ms - _SPOT_CANDLE_MS)
                if entry_price is None:
                    continue
                funding = _realized_funding_pnl(position, fv.timestamp_exchange_ms,
                    fv.timestamp_exchange_ms + barrier.elapsed_hours * _SPOT_CANDLE_MS, entry_price, funding_records)
                if funding is None:
                    continue
                gross = position * math.expm1(barrier.log_return)
                net = gross + funding - costs.friction(position)
                n_executed += 1
''' + s[b:]
s=s.replace('                        horizon_hours=horizon_hours,\n                    )\n                )\n                fold_ic_pairs','                        horizon_hours=barrier.elapsed_hours,\n                    )\n                )\n                fold_ic_pairs',1)
s=s.replace('"selection_family": "threshold_grid",','"selection_family": "threshold_grid",\n                "family": "funding_oi_hmm_v3",')
s=s.replace('    if r.final_verdict == "GO":\n        logger.info("→ Critérios da Fase 1 atendidos. Fase 2 AUTORIZADA.")\n    else:\n        logger.info("→ Critérios não atendidos. Fase 2 BLOQUEADA. Pivot de pesquisa necessário.")','    logger.info("Replay descritivo. Critérios numericos nao autorizam capital nem reabrem familia congelada.")')
s=s.replace('"Retorno medio  : bruto %.6f -> LIQUIDO %.6f por sinal (fee %sbps + slip + funding real)"','"Retorno medio  : bruto %.6f -> liquido simulado %.6f por sinal (fee %sbps + slip + funding observado)"')
s=s.replace('"Max Drawdown   : %.2f%%  (threshold: %.0f%%)"','"MaxDD em fechamentos: %.2f%% (nao mede perdas intratrade; threshold %.0f%%)"')
f.write_text(s,encoding='utf-8')
# Expected stops must use the observed 97 close, rather than assuming a fill at 99.
f=p/'tests/test_v3_backtest_barriers.py';s=f.read_text(encoding='utf-8').replace('assert math.isclose(ret, -0.01, rel_tol=1e-6)','assert math.isclose(ret, math.log(97.0 / 100.0), rel_tol=1e-6)');f.write_text(s,encoding='utf-8')
