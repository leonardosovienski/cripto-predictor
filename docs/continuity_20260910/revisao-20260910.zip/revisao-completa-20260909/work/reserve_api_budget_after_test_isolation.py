"""Fail-closed reservation after discovering a test helper erased durable usage."""
from pathlib import Path
from datetime import UTC, datetime
import sqlite3
import json
from GarimpoInvestimentos.core.api_guard import _BUDGET_DB

root = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\expansion_budget_incident')
root.mkdir(exist_ok=False)
day = datetime.now(UTC).date().isoformat()
with sqlite3.connect(_BUDGET_DB) as conn:
    with sqlite3.connect(root/'before.sqlite') as backup:
        conn.backup(backup)
    before = conn.execute('SELECT bucket,stage,guard_key,used FROM api_budget').fetchall()
    conn.execute('BEGIN IMMEDIATE')
    reservations = [('ingest','assets',28),('news','serpapi',8)] + [('llm',p,6) for p in ['gemini','groq','cerebras','openai','mistral','openrouter']]
    for stage,key,limit in reservations:
        conn.execute('INSERT INTO api_budget(bucket,stage,guard_key,used) VALUES(?,?,?,?) ON CONFLICT(bucket,stage,guard_key) DO UPDATE SET used=MAX(api_budget.used,excluded.used)',(day,stage,key,limit))
    conn.commit()
    after = conn.execute('SELECT bucket,stage,guard_key,used FROM api_budget').fetchall()
record={'at':datetime.now(UTC).isoformat(),'budget_path':str(_BUDGET_DB),'classification':'CONSERVATIVE_RESERVATION_NOT_MEASURED_USAGE','reason':'Legacy test reset helper could erase the operational budget. Before the two source-audit asset calls the table was empty. Exact previous usage is not reconstructable from this database. Reserve remaining allowance for current UTC day without resetting or issuing further calls. Runtime helper corrected; tests isolated.','before':before,'after':after,'further_connected_work_today':'BLOCKED_UNTIL_NEXT_UTC_BUCKET','backup':str(root/'before.sqlite')}
(root/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
