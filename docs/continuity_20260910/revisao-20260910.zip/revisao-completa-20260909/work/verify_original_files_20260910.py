import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

root = Path(r'C:\Cripto')
out = root / 'operacao/relatorios/REVISAO_COMPLETA_20260909/organization_20260910'
manifest = json.loads((root / 'MANIFESTO.json').read_bytes())
restored = root / 'restaurado-20260908'
relocations = {x['path']: x['after'] for x in json.loads((restored / 'RESTAURACAO.json').read_bytes())['relocated_environment_files']}
checks = [('restored_files', restored, manifest['files']), ('restored_runtime', restored / 'runtime', manifest['runtime_files']), ('package_runtime', root / 'runtime', manifest['runtime_files'])]
result = {'started_at_utc': datetime.now(UTC).isoformat(), 'groups': [], 'failures': [], 'relocation_exceptions': list(relocations), 'modified_files': 0}
for label, base, entries in checks:
    count = 0
    for entry in entries:
        path = base / entry['path']
        expected = relocations.get(entry['path'], entry['sha256']) if label == 'restored_files' else entry['sha256']
        try:
            with path.open('rb') as stream:
                actual = hashlib.file_digest(stream, 'sha256').hexdigest()
        except OSError as exc:
            result['failures'].append({'group': label, 'path': entry['path'], 'error': type(exc).__name__})
            continue
        if actual != expected:
            # Do not publish digests of private environment files.
            result['failures'].append({'group': label, 'path': entry['path'], 'error': 'sha256_mismatch'})
        count += 1
        if count % 10000 == 0:
            print(json.dumps({'group': label, 'checked': count, 'failures': len(result['failures'])}), flush=True)
    result['groups'].append({'name': label, 'expected': len(entries), 'read': count})
result['finished_at_utc'] = datetime.now(UTC).isoformat()
result['status'] = 'PASS' if not result['failures'] else 'FAIL'
(out / 'original_files_verification.private.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result), flush=True)
