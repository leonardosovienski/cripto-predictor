from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
def edit(name, pairs):
 path=p/name; s=path.read_text(encoding='utf-8')
 for old,new in pairs:
  assert old in s,(name,old[:80]);s=s.replace(old,new)
 path.write_text(s,encoding='utf-8')
edit('GarimpoInvestimentos/analyzers/hypothesis_loop.py',[
 ('import json\n','import json\nimport math\n'),
 ('from GarimpoInvestimentos.analyzers.backtest import overlap_block_length','from GarimpoInvestimentos.analyzers.backtest import overlap_block_length\nfrom GarimpoInvestimentos.durable_io import append_json_history, load_json_history\nfrom GarimpoInvestimentos.core.paths import DATA_DIR'),
 ('PROPOSALS_PATH = Path(__file__).resolve().parent.parent / "hypothesis_proposals.json"','PROPOSALS_PATH = DATA_DIR / "research" / "hypothesis_proposals.json"'),
 ('proposal: Proposal, dados: dict[str, list[float | None]], retornos: Sequence[float | None]\n','proposal: Proposal, dados: dict[str, list[float | None]], retornos: Sequence[float | None],\n    *, observations_per_day: int = 1\n'),
 ('    fator: Factor = from_recipe(proposal.recipe)','    if proposal.horizon_days < 1 or observations_per_day < 1:\n        raise ValueError("horizonte e frequencia devem ser positivos")\n    fator: Factor = from_recipe(proposal.recipe)'),
 ('    aquecimento = warmup(fator)','    if len(valores) != len(retornos):\n        raise ValueError("feature e alvo devem ter o mesmo comprimento")\n    aquecimento = warmup(fator)'),
 ('retornos[aquecimento:], strict=False','retornos[aquecimento:], strict=True'),
 ('if v is not None and r is not None','if v is not None and r is not None and math.isfinite(v) and math.isfinite(r)'),
 ('overlap_block_length(proposal.horizon_days)','overlap_block_length(proposal.horizon_days * observations_per_day)'),
 ('    if not path.exists():\n        return []\n    try:\n        dados = json.loads(path.read_text(encoding="utf-8"))\n    except (OSError, ValueError):\n        return []\n    return dados if isinstance(dados, list) else []','    return load_json_history(path)'),
 ('    atuais = load_proposals(path)\n    atuais.extend(asdict(p) for p in proposals)\n    path.write_text(json.dumps(atuais, indent=2, ensure_ascii=False) + "\\n", encoding="utf-8")\n    return len(proposals)','    return append_json_history(path, [asdict(p) for p in proposals])'),
 ('    prompt = build_prompt(features=features, horizon_days=horizon_days, historico=historico)','    if isinstance(horizon_days, bool) or not isinstance(horizon_days, int) or horizon_days < 1:\n        raise ValueError("horizon_days deve ser inteiro positivo")\n    load_proposals(path)  # Validate history before consuming a provider call.\n    prompt = build_prompt(features=features, horizon_days=horizon_days, historico=historico)'),
])
edit('GarimpoInvestimentos/analyzers/hypothesis_loop_runner.py',[
 ('from GarimpoInvestimentos.core.paths import DATA_DIR','from GarimpoInvestimentos.core.paths import DATA_DIR\nfrom GarimpoInvestimentos.durable_io import append_json_history, load_json_history'),
 ('EVALUATIONS_PATH = Path(__file__).resolve().parent.parent / "hypothesis_evaluations.json"','EVALUATIONS_PATH = DATA_DIR / "research" / "hypothesis_evaluations.json"'),
 ('    passos = horizon_days * _PERIODS_PER_DAY','    if isinstance(horizon_days, bool) or not isinstance(horizon_days, int) or horizon_days < 1:\n        raise ValueError("horizon_days deve ser inteiro positivo")\n    times = [fv.timestamp_exchange_ms for fv in feature_vectors]\n    if any(a >= b for a, b in zip(times, times[1:])) or len({fv.asset for fv in feature_vectors}) > 1:\n        raise ValueError("serie deve ter um ativo e timestamps unicos crescentes")\n    by_time = {fv.timestamp_exchange_ms: fv.spot_close for fv in feature_vectors}'),
 ('    for i in range(len(closes)):\n        j = i + passos\n        if j >= len(closes) or closes[i] <= 0.0 or closes[j] <= 0.0:\n            retornos.append(None)\n            continue\n        retornos.append(math.log(closes[j] / closes[i]))','    for i, ts in enumerate(times):\n        target = by_time.get(ts + horizon_days * 86_400_000)\n        if target is None or not math.isfinite(target) or not math.isfinite(closes[i]) or closes[i] <= 0 or target <= 0:\n            retornos.append(None)\n            continue\n        retornos.append(math.log(target) - math.log(closes[i]))'),
 ('    if not path.exists():\n        return []\n    try:\n        dados = json.loads(path.read_text(encoding="utf-8"))\n    except (OSError, ValueError):\n        return []\n    return dados if isinstance(dados, list) else []','    return load_json_history(path)'),
 ('    atuais = load_evaluations(path)\n    atuais.extend(asdict(e) for e in evaluations)\n    path.write_text(json.dumps(atuais, indent=2, ensure_ascii=False) + "\\n", encoding="utf-8")\n    return len(evaluations)','    return append_json_history(path, [asdict(e) for e in evaluations])'),
 ('    feature_vectors = _load_feature_vectors(symbol)','    load_evaluations(evaluations_path)\n    feature_vectors = _load_feature_vectors(symbol)'),
 ('evaluate_proposal(p, dados, retornos)','evaluate_proposal(p, dados, retornos, observations_per_day=_PERIODS_PER_DAY)'),
 ('nada chamava `evaluate_proposal` sobre as propostas aceitas, e nada agendava\nisso pra rodar. Sem isso, o checklist de ativação do H8 nunca sai do item 4\n("coletar dado GENUINAMENTE NOVO") — é exatamente essa lacuna que este módulo\nfecha.','este modulo liga `evaluate_proposal` as propostas aceitas. Reutiliza historia\nexistente: NAO coleta dados prospectivos nem satisfaz o requisito de dados novos.\nNenhum agendamento e ativado.'),
])
edit('GarimpoInvestimentos/analyzers/ground_truth_harness.py',[
 ('    for r in enriched:\n        medido = r.get(chave)','    for r in enriched:\n        pred_date = r["pred_date"]\n        timestamp = pred_date.replace(tzinfo=UTC) if pred_date.tzinfo is None else pred_date.astimezone(UTC)\n        k = (r["ativo"], timestamp)\n        if k in vistas:\n            raise ValueError(f"Previsao duplicada: {k}")\n        vistas.add(k)\n        medido = r.get(chave)'),
 ('        k = (r["ativo"], r["pred_date"].replace(tzinfo=None))\n        esperado = world.truth.get((k[0], k[1].replace(tzinfo=UTC)))','        esperado = world.truth.get(k)'),
 ('        vistas.add(k)\n        recuperadas += 1','        if not math.isfinite(float(medido)):\n            raise ValueError("Medicao nao finita")\n        recuperadas += 1'),
 ('        for pos, i in enumerate(ordem):\n            r[i] = float(pos)','        pos = 0\n        while pos < n:\n            end = pos + 1\n            while end < n and vals[ordem[end]] == vals[ordem[pos]]:\n                end += 1\n            for i in ordem[pos:end]:\n                r[i] = (pos + end - 1) / 2.0\n            pos = end'),
 ('    n = len(pares)\n    if n < 3:','    if any(not math.isfinite(value) for pair in pares for value in pair):\n        raise ValueError("Spearman exige valores finitos")\n    n = len(pares)\n    if n < 3:'),
])
edit('GarimpoInvestimentos/analyzers/pbo.py',[
 ('    if n_splits % 2 or n_splits < 2:','    if isinstance(n_splits, bool) or not isinstance(n_splits, int) or n_splits % 2 or n_splits < 2:'),
 ('    blocos = _blocos(n_obs, n_splits)','    if any(not math.isfinite(value) for series_values in series for value in series_values):\n        raise PBOError("observacoes devem ser finitas")\n    blocos = _blocos(n_obs, n_splits)'),
 ('        melhor = max(range(n_config), key=lambda c: perf_is[c])','        if any(math.isnan(value) for value in perf_is):\n            raise PBOError("performance IS indefinida")\n        melhor = max(range(n_config), key=lambda c: perf_is[c])'),
 ('        # rank 1 = PIOR','        if any(math.isnan(value) for value in perf_oos):\n            raise PBOError("performance OOS indefinida")\n        # rank 1 = PIOR'),
])
edit('GarimpoInvestimentos/analyzers/equivalence.py',[
 ('import asyncio\n','import asyncio\nimport math\n'),
 ('    if a == b:\n','    if not math.isfinite(a) or not math.isfinite(b):\n        return float("inf")\n    if a == b:\n'),
 ('    return out\n','    out["ok"] = out["ok"] and any(value is not None for value in out["indicadores"].values())\n    return out\n'),
 ('    all_ok = True','    all_ok = bool(results)'),
 ('        if "skipped" in r:\n            print','        if "skipped" in r:\n            all_ok = False\n            print'),
 ('— não conta no veredito','— comparacao incompleta'),
 ('            results[ativo] = compare_asset(','            results[ativo] = compare_asset('),
 ('                changes_dpl=feats,\n            )','                changes_dpl=feats,\n            )\n            results[ativo]["ok"] = False\n            results[ativo]["alignment"] = "unverified: direct series lacks timestamps/source identity"'),
])
