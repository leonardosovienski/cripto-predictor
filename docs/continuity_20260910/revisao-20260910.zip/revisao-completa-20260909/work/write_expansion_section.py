from pathlib import Path
from datetime import datetime, timezone
import json
import hashlib
import xml.etree.ElementTree as ET

R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
P=Path(r'C:\Cripto\auditoria-ampliada-20260910')
def read(p, default=None):
    return json.loads((R/p).read_text(encoding='utf-8')) if (R/p).exists() else default
def validation(p):
    data=read(p+'/validation.json',{})
    xml=R/p/'tests.xml'
    counts='em execução'
    if xml.exists():
        suites=ET.parse(xml).getroot()
        cases=suites.findall('.//testcase')
        failed=sum(c.find('failure') is not None or c.find('error') is not None for c in cases)
        skipped=sum(c.find('skipped') is not None for c in cases)
        counts=f'{len(cases)-failed-skipped} aprovados, {failed} falhas, {skipped} skips'
    checks=', '.join(f"{c['name']}={c['exit_code']}" for c in data.get('checks',[]))
    return f'[{p}]({p}/validation.json): {counts}; {checks}'

integration=read('expansion_integration.json',{})
lines=[
'## 16. Auditoria ampliada: temporalidade, execução, dados e preservação',
'',
'Esta etapa começou novamente pelo estado real e pela nova linha de base completa no main `ffd6c327e2d323758f6ab6abac4ab15ef5ca0881`, após #114. Implementação em `C:\\Cripto\\auditoria-ampliada-20260910`, branch `fix/audit-expansion-20260910`. A revisão abaixo corrige alegações operacionais anteriores; documentos e resultados congelados mantêm seus bytes.',
'',
'**Integração:** '+integration.get('summary','PR #115 aberto; aguardando validação final local e quatro jobs contra a base atual.')+' [PR #115](https://github.com/leonardosovienski/cripto-predictor/pull/115).',
'',
'O documento versionado [Auditoria ampliada](C:/Cripto/auditoria-ampliada-20260910/docs/AUDITORIA_AMPLIADA_20260910.md) contém a matriz de defeitos, correções, fontes primárias, profundidade real da revisão e dependências concretas. Esta seção não equivale a afirmar leitura integral de todo arquivo restaurado nem lucro validado.',
'',
'**Validação independente da linha de base:** '+validation('expansion_baseline01')+'.',
'',
'**Validação final da correção:** '+validation('expansion_full03')+'.',
'',
'As suítes intermediárias estão preservadas. `expansion_full01` teve 1.464 aprovações/14 falhas/um skip; eram expectativas antigas incompatíveis com a correção, tratadas com testes de recusa explícita. `expansion_full02` antecede a última correção de isolamento do orçamento e não certifica seu código. Os casos adversariais before3 (49 falhas/3 passes), before4 (12 falhas), before5 (6 falhas/2 passes) e anchor_before (2 falhas/2 passes) são contagens de casos, não de causas independentes.',
'',
'**Correções principais:** contratos de ordem/fill e reconciliação econômica; transações e conflitos em SQLite/CSV; locks e persistência atômica; continuidade de manifesto e cadeia pública; fonte spot Binance correta e unidade pós-2025; datas de recebimento e vintages; cache com TTL e hash dos dados de treino; indicadores e janelas causais; HMM transacional; cálculo aritmético de retorno, funding por evento, barreiras a preço observado, Sharpe sem sqrt(n); registros de sweep antes de resultados; paper sem falsa promoção; saúde com timestamps e amostra semanal válidos; exportação sem injeção de fórmula; plugin consulta o charter atual.',
'',
'**Resultado econômico:** WFA novo publica `UNVALIDATED`, diagnóstico separado e capital=false. Bps de cenário não são calibração de execução. PSR IID com retornos sobrepostos não é confiança confirmatória. Nenhuma família encerrada foi reaberta. O Aave da seção 15 continua histórico positivo condicional; não existe execução pessoal ou lucro futuro comprovado.',
'',
'**Fonte real:** [resultado da recuperação spot](C:/Cripto/operacao/dados/spot-source-audit-20260910/result.json): 743 candles BTC e 743 ETH de agosto/2026, checksums conferidos, 48 comparações com REST sem divergência. Seis chamadas, dois ativos. Corte 31/08 23:59:59.999 UTC exclui corretamente a última hora ainda aberta; não é mês integral. Brutos e recibos preservados. Arquivo antigo chamado spot não foi recopiado para fingir fonte correta.',
'',
'**Incidente adicional da própria validação:** [evidência do orçamento](expansion_budget_incident/result.json). Duas rotinas de teste podiam apagar o banco operacional por chamar `reset_for_test` sem path temporário. A tabela estava vazia antes da recuperação spot, logo zero não atesta consumo anterior. O helper não apaga mais contador e a fixture agora isola o banco. Backup preservado; a quota corrente foi reservada conservadoramente, sem ampliar limite nem atribuir consumo medido à reserva. Novas chamadas de ingestão/notícias/LLM ficam bloqueadas até o próximo dia UTC. A contagem exata anterior não é recuperável apenas pelo banco restante.',
'',
'**Pendências de evidência:** inputs H5 originais; versões históricas macro comprovadamente disponíveis; custos/fills/mark/liquidez do instrumento e execução pessoal; amostra futura de 84 dias; segunda fonte histórica Aave; comprovação de revogação/uso antigo nos painéis. Falta de histórico exato não se resolve com outro pacote Python. Cobertura universal dos arquivos/anos fora dos recortes não foi certificada. Segurança administrativa da branch permanece excluída pelo dono.',
'',
'**Compatibilidade operacional:** consumidores diários exigem `daily-v4-audited`, modelos HMM schema 2 e sinais schema 3.2.0. Caches antigos não recebem identidade nova por renomeação; novos dados/derivações exigem procedência. Os futuros protocolos manuais congelados continuam usando seus executores próprios, sem scheduler. Atualização de snapshots diários é coleta operacional normal na próxima quota, não amostra científica obtida retroativamente.',
'',
'**Registro futuro conferido:** carry v2 permanece WAITING, zero linhas. O registro LLM v2 foi preservado e recusou o código modificado. O novo `llm-paired-manual-20260912-v3` mantém protocolo/datas/ambiente e tem 84 horários futuros, sem observações. Ele vincula o executor aos bytes da área `C:\\Cripto\\auditoria-ampliada-20260910`, inclusive a diferença LF/CRLF de local_runtime.py. Preserve essa área e use os comandos atualizados em docs/manual_dependencies_20260910/EXECUCAO.md, que passam pelo lançador explícito. Nenhum hash antigo foi alterado para forçar aprovação. [Status LLM novo](expansion_llm_status_v3.json), [carry](expansion_carry_status.json).',
]
for path,label in [('expansion_ci_pr_final.json','CI do PR final'),('expansion_ci_main.json','CI após merge'),('expansion_operational.json','Verificação operacional e preservação')]:
    if (R/path).exists():
        lines+=['',f'[{label}]({path}).']
if (R/'postmerge_expansion01/validation.json').exists():
    lines+=['','**Conferência local após merge:** '+validation('postmerge_expansion01')+'.']
lines+=['','[Wheel instalado fora do checkout](expansion_full03/wheel_contract.json); [consistência dos 79 pacotes](expansion_full03/dependency_consistency.log). Cobertura da correção: 87,433155% no escopo runtime com branches; não é percentual de auditoria manual.']
lines+=['',f'Registro desta seção atualizado em {datetime.now(timezone.utc).isoformat()}.']
(R/'work'/'expansion_report_section.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps({'section':16,'integration':integration.get('summary','pending'),'doc_sha256':hashlib.sha256((P/'docs/AUDITORIA_AMPLIADA_20260910.md').read_bytes()).hexdigest()}))
