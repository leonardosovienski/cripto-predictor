from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
f=p/'GarimpoInvestimentos/v3/signal_engine.py';s=f.read_text(encoding='utf-8')
s=s.replace('import json\n','import json\nimport hashlib\nimport math\n')
s=s.replace('from dataclasses import asdict, dataclass','from dataclasses import asdict, dataclass, replace')
s=s.replace('from GarimpoInvestimentos.v3.feature_builder import FeatureVector','from GarimpoInvestimentos.v3.feature_builder import FeatureVector\nfrom GarimpoInvestimentos.durable_io import file_lock, atomic_write\nfrom GarimpoInvestimentos.trading.contracts import require_finite')
s=s.replace('@dataclass\nclass SignalRecord','@dataclass(frozen=True)\nclass SignalRecord')
s=s.replace('    features_used: dict\n','    features_used: dict\n    scientific_state: str = "DESCRIPTIVE_SIGNAL"\n    capital_enabled: bool = False\n')
s=s.replace('_SCHEMA_VERSION = "v3.1.0"','_SCHEMA_VERSION = "v3.2.0"')
s=s.replace('def generate_signal(\n','def _generate_signal(\n',1)
a=s.index('def _generate_signal(')
s=s[:a]+'''def generate_signal(
    fv: FeatureVector, regime: RegimeOutput, horizon_hours: int = 24,
    fr_zscore_threshold: float = _FR_ZSCORE_THRESHOLD,
    min_regime_confidence: float = _MIN_REGIME_CONFIDENCE,
) -> SignalRecord:
    if isinstance(horizon_hours, bool) or not isinstance(horizon_hours, int) or horizon_hours <= 0:
        raise ValueError("horizon_hours deve ser inteiro positivo")
    for name, value in (("fr_zscore_threshold", fr_zscore_threshold), ("min_regime_confidence", min_regime_confidence),
                        ("quality", fv.data_quality_score), ("funding_zscore", fv.funding_zscore), ("oi_log_delta", fv.oi_log_delta), ("entropy", regime.hmm_entropy)):
        require_finite(value, name)
    if fr_zscore_threshold <= 0 or not 0 <= min_regime_confidence <= 1 or not 0 <= fv.data_quality_score <= 1 or not 0 <= regime.hmm_entropy <= 1:
        raise ValueError("parametros de sinal fora do dominio")
    if not isinstance(regime.hmm_state, int) or not 0 <= regime.hmm_state < len(regime.hmm_posterior) or any(not math.isfinite(value) or not 0 <= value <= 1 for value in regime.hmm_posterior):
        raise ValueError("posterior de regime invalido")
    if fv.timestamp_exchange_ms > int(datetime.now(UTC).timestamp() * 1000):
        raise ValueError("timestamp de mercado no futuro")
    policy = {"schema": _SCHEMA_VERSION, "horizon_hours": horizon_hours,
              "fr_zscore_threshold": fr_zscore_threshold, "min_regime_confidence": min_regime_confidence,
              "fr_zscore_max": _FR_ZSCORE_MAX, "min_data_quality": _MIN_DATA_QUALITY}
    result = _generate_signal(fv, regime, horizon_hours, fr_zscore_threshold, min_regime_confidence)
    fingerprint = hashlib.sha256(json.dumps(policy, sort_keys=True, allow_nan=False).encode()).hexdigest()[:16]
    return replace(result, engine_id=f"{_ENGINE_ID}:{fingerprint}",
                   features_used={**result.features_used, "signal_policy": policy,
                                  "replay_scope": "signal decision given posterior; HMM replay also requires model and input history"})


''' + s[a:]
a=s.index('    path.parent.mkdir(parents=True, exist_ok=True)',s.index('def save_signals_jsonl'))
s=s[:a]+'''    with file_lock(path):
        original = path.read_text(encoding="utf-8") if path.exists() else ""
        seen = {}
        for line in original.splitlines():
            if line.strip():
                row = json.loads(line)
                if row["event_id"] in seen and seen[row["event_id"]] != row:
                    raise ValueError("event_id conflitante no historico de sinais")
                seen[row["event_id"]] = row
        added = []
        for record in records:
            row = asdict(record)
            if record.event_id in seen:
                if seen[record.event_id] != row:
                    raise ValueError("event_id de sinal reutilizado com conteudo diferente")
                continue
            seen[record.event_id] = row
            added.append(json.dumps(row, ensure_ascii=False, allow_nan=False))
        if added:
            separator = "\\n" if original and not original.endswith("\\n") else ""
            atomic_write(path, (original + separator + "\\n".join(added) + "\\n").encode("utf-8"))
    logger.info("signal_engine: %d novos sinais gravados em %s", len(added), path)
'''
f.write_text(s,encoding='utf-8')
f=p/'GarimpoInvestimentos/v3/pipeline.py';s=f.read_text(encoding='utf-8').replace('import logging\n','import logging\nimport hashlib\nimport json\n')
s=s.replace('from GarimpoInvestimentos.v3.regime_engine import RegimeEngine, StaleRegimeModelError','from GarimpoInvestimentos.v3.regime_engine import RegimeEngine, StaleRegimeModelError, MODEL_SCHEMA_VERSION\nfrom GarimpoInvestimentos.v3.collectors.record_io import validate_observation')
s=s.replace('    return _DATA_ROOT / symbol','    validate_observation(symbol, 0, {})\n    return _DATA_ROOT / symbol',1)
s=s.replace('return _symbol_dir(symbol) / "signals.jsonl"','return _symbol_dir(symbol) / "signals.replay.v3_2.jsonl"')
s=s.replace('    # 4. Treinar HMM sobre série completa (in-sample para o pipeline de sinal)\n    #    O backtest_v3 fará o WFA com janelas rolantes — este fit é para produção.','    # 4. Descriptive in-sample fit; historical rows are replay, not OOS forecasts.')
s=s.replace('    if model_path.exists() and not force_refresh:', '    data_hash = hashlib.sha256(json.dumps([log_returns, realized_vols], allow_nan=False).encode()).hexdigest()\n    model_path = model_path.with_name(f"{model_path.stem}.schema{MODEL_SCHEMA_VERSION}.{data_hash}{model_path.suffix}")\n    if model_path.exists() and not force_refresh:',1)
s=s.replace('            engine.load(model_path)','            engine.load(model_path)\n            if engine.training_data_hash != data_hash:\n                raise StaleRegimeModelError("cache pertence a outra amostra de treino")',1)
s=s.replace('    # 5. Inferência causal — um regime por feature vector','    # 5. Forward filtering on an IS fit. Whole-history outputs remain retrospective.')
s=s.replace('    4. Gera sinais causais para toda a série','    4. Gera sinais retrospectivos descritivos; o ajuste completo nao e OOS')
s=s.replace('            "model_path": str(model_path),','            "scientific_state": "DESCRIPTIVE_REPLAY",\n            "training_data_hash": data_hash,\n            "model_path": str(model_path),')
f.write_text(s,encoding='utf-8')
