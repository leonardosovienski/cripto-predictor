import json
import subprocess
from datetime import UTC, datetime
from pathlib import Path

root = Path(r'C:\Cripto').resolve(strict=True)
target = root / 'publicacao-conferencia-20260910'
P = root / 'pesquisa-20260909'
F = root / 'operacao/relatorios/REVISAO_COMPLETA_20260909/organization_20260910'
def git(where, *args):
    return subprocess.check_output(['git', *args], cwd=where, text=True).strip()

assert target.resolve(strict=True) == target and target.parent == root
assert not target.is_symlink() and not target.is_junction()
head = git(target, 'rev-parse', 'HEAD')
tree = git(target, 'rev-parse', 'HEAD^{tree}')
assert head == '08dc4f7548d082d528047ed430087607388cc253'
assert tree == git(P, 'rev-parse', 'HEAD^{tree}') == 'b08d2cf79d3148525435ab69ba2cc130691c8a65'
assert not git(target, 'status', '--porcelain', '--untracked-files=all')
assert not git(target, 'ls-files', '--others', '--ignored', '--exclude-standard')
branch = git(target, 'branch', '--show-current')
assert git(P, 'rev-parse', branch) == head
tracked = git(target, 'ls-files').splitlines()
record = {'at_utc': datetime.now(UTC).isoformat(), 'path': str(target), 'head': head, 'tree': tree, 'branch_preserved': branch,
          'tracked_files': len(tracked), 'untracked_or_ignored_files': 0, 'clean': True, 'identical_to_operational_tree': True,
          'inventory_bytes': 625000474, 'restore_command': f'git -C C:\\Cripto\\pesquisa-20260909 worktree add {target} {branch}',
          'reason': 'Clean publication copy is identical to the integrated operational tree; commit and branch remain in the shared Git repository and on GitHub.', 'removed': False}
(F / 'redundant_worktree.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
# Git refuses dirty worktrees; no force option and no independent filesystem deletion.
subprocess.run(['git', '-C', str(P), 'worktree', 'remove', str(target)], check=True)
assert not target.exists()
assert git(P, 'rev-parse', branch) == head
record['removed'] = True
(F / 'redundant_worktree.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
(root / 'backups/operational-20260910-files-audit/removed_worktree.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(record, ensure_ascii=False))
