import importlib.util
from pathlib import Path
import sys
import scripts

HERE = Path(__file__).resolve().parent
for name in ('paired_llm', 'paired_llm_source', 'recover_aave_history'):
    spec = importlib.util.spec_from_file_location('scripts.'+name, HERE/(name+'.py'))
    module = importlib.util.module_from_spec(spec)
    sys.modules['scripts.'+name] = module
    setattr(scripts, name, module)
    spec.loader.exec_module(module)
import pytest
raise SystemExit(pytest.main([str(HERE/'test_paired_llm.py'), str(HERE/'test_recover_aave_history.py'), *sys.argv[1:]]))
