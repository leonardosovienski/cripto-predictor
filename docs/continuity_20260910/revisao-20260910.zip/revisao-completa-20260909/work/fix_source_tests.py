from pathlib import Path
p=Path(r'C:\Cripto\auditoria-ampliada-20260910')
f=p/'tests/test_dpl_dxy.py';s=f.read_text(encoding='utf-8');s=s.replace('import asyncio\n','import asyncio\nfrom datetime import UTC, datetime\n')
a=s.index('def test_dxy_publish_lag_is_applied_conservatively');b=s.index('\n\ndef test_dxy_respects_limit',a)
s=s[:a]+'''def test_dxy_availability_is_the_observed_vintage(monkeypatch):
    monkeypatch.setattr(dxy, "get_http_client", lambda *a, **k: _Client(_CSV))
    before = datetime.now(UTC)
    points = asyncio.run(dxy.DXYProvider().fetch())
    assert all(p.published_at >= before and p.vintage == p.published_at for p in points)
''' + s[b:]
s=s.replace('assert all(p.published_at == p.timestamp for p in points)','assert all(p.published_at > p.timestamp and "available_at_receipt" in p.quality_flags for p in points)')
a=s.index('def test_dxy_publish_lag_skips_weekend');b=s.index('\n\ndef test_dxy_publish_lag_two_business_days_from_friday',a)
s=s[:a]+'''def test_dxy_does_not_invent_monday_publication_for_friday(monkeypatch):
    friday_csv = "observation_date,DTWEXBGS\\n2026-08-14,103.10\\n"
    monkeypatch.setattr(dxy, "get_http_client", lambda *a, **k: _Client(friday_csv))
    before = datetime.now(UTC)
    points = asyncio.run(dxy.DXYProvider(publish_lag_days=1).fetch())
    assert len(points) == 1
    assert points[0].published_at >= before
''' + s[b:]
f.write_text(s,encoding='utf-8')
# Synthetic macro inputs now explicitly include publication stamps, rather than treating observation date as availability.
f=p/'tests/test_v3_macro_dxy_integration.py';s=f.read_text(encoding='utf-8').replace('w.writerow(["date", "close"])','w.writerow(["date", "close", "published_at"])').replace('w.writerow([d.isoformat(), f"{close:.4f}"])','w.writerow([d.isoformat(), f"{close:.4f}", datetime.combine(d + dt.timedelta(days=1), datetime.min.time(), tzinfo=UTC).isoformat()])');f.write_text(s,encoding='utf-8')
# Unit fixture timestamps in this file represented availability; make the candle OPEN one hour earlier.
f=p/'tests/test_v3_crowding_features.py';s=f.read_text(encoding='utf-8').replace('timestamp_exchange_ms=ts_ms,','timestamp_exchange_ms=ts_ms + 3_600_000,');f.write_text(s,encoding='utf-8')
