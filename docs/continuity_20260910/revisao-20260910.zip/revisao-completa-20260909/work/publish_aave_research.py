from pathlib import Path
import json
import hashlib
import shutil

P=Path(r'C:\Cripto\pesquisa-20260909')
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
E=P/'docs/evidence/aave_validation_20260910'
E.mkdir(parents=True,exist_ok=False)
sources={
 'history':r'C:\Cripto\operacao\dados\aave-validation-20260910-r1',
 'funded_costs':r'C:\Cripto\operacao\dados\aave-validation-20260910-funded-costs',
 'execution_attempt01':r'C:\Cripto\operacao\dados\aave-execution-receipts-20260910-r1',
 'execution_receipts':r'C:\Cripto\operacao\dados\aave-execution-receipts-20260910-r2',
 'conversion_quote':r'C:\Cripto\operacao\dados\aave-conversion-quote-20260910',
}
for name,location in sources.items():
    shutil.copytree(location,E/name)
shutil.copy2(R/'work/test_aave_extended.py',E/'synthetic_tests.source')
shutil.copy2(R/'executor_dependencies/aave-extended-tests.xml',E/'synthetic_tests_attempt01.xml')
shutil.copy2(R/'executor_dependencies/aave-extended-tests02.xml',E/'synthetic_tests_passed.xml')
manifest={p.relative_to(E).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(E.rglob('*')) if p.is_file()}
(E/'MANIFEST.json').write_text(json.dumps({'files':manifest,'source_directories':sources,'private_credentials_included':False},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'files':len(manifest),'bytes':sum(p.stat().st_size for p in E.rglob('*') if p.is_file())}))
