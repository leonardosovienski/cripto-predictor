"""Use the authorized runtime against the isolated audit worktree."""
import os
import runpy
import sys
from pathlib import Path

project = Path(r'C:\Cripto\fechamento-revisao-20260910')
os.chdir(project)
sys.path.insert(0, str(project))
args = sys.argv[1:]
if args[0] == '-m':
    sys.argv = [args[1], *args[2:]]
    runpy.run_module(args[1], run_name='__main__', alter_sys=True)
else:
    sys.argv = args
    runpy.run_path(args[0], run_name='__main__')
