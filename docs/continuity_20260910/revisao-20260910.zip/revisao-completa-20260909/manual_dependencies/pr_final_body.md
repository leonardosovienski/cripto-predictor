O fallback intradiário CoinGecko produzia volume zero quando a fonte fornecia apenas OHLC. Agora recusa esses intervalos antes da rede, preservando o fallback diário e permitindo ao roteador buscar outra fonte de OHLCV.

A auditoria explica os 542 dias de gaps dos 12 pares por interrupções documentadas de negociação, com fontes oficiais e separação de identidades, incluindo Terra Classic/Terra 2.0 e redenominações. Não cria candles nem altera pesquisa congelada. Inclui auditor reproduzível e registro manual separado de carry com custos originais, status offline, validação de fontes/relógio e guarda persistente. Nenhuma observação, ordem ou automação foi iniciada.

A tentativa OnFinality consumiu uma unidade de ingestão em duas chamadas públicas e foi recusada por acesso/rate limit. H5 continua sem inputs originais encontrados. O desenho de avaliação LLM é um rascunho não ativado; executor pareado e amostra futura continuam explicitamente pendentes. Custos e evidências privados têm campos/unidades definidos. Configurações de segurança da branch estão excluídas pelo dono.

Validação final no head b44f29c57b101c18cc45bd7eed6e019a5d5aa9d5, contra main 9b8de9802c61570610bc0b212bdb0bb4c4e1d643:

- Windows: 1.358 testes aprovados, um skip de symlink por privilégio, zero falhas; all-extras, lint, formato, tipagem, scanner, build, entradas Windows e wheel instalado fora do checkout aprovados.
- [CI do PR](https://github.com/leonardosovienski/cripto-predictor/actions/runs/34424968376): quality, all-extras, container e python-314-experimental aprovados. Linux/all-extras: 1.359 testes aprovados, cobertura do escopo runtime exibida como 90%.
- Auditoria reproduzida a partir dos arquivos publicados: 542 dias explicados, zero não explicados nesses 12 gaps, zero candles gerados. Isso não certifica todo o universo histórico.
- Congelamento original do carry e o diff preexistente de NEXT_CHAT_PROMPT.md preservados. Pós-merge confirmado em 33b0627ac016b23531228053b9256dbedcb407d0: árvore idêntica à testada; novamente 1.358 testes locais aprovados, um skip Windows e zero falhas. Os quatro jobs do [main resultante](https://github.com/leonardosovienski/cripto-predictor/actions/runs/34425802284) passaram.

Comandos, fontes e limites: [retomada manual](https://github.com/leonardosovienski/cripto-predictor/blob/main/docs/manual_dependencies_20260910/RETOMADA.md).
