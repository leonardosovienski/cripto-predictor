# Retomada do projeto após esta conversa

Este arquivo é um índice de continuidade, conferido em 10/09/2026. O registro vivo único continua sendo o relatório indicado abaixo. Verifique novamente data, Git e quota antes de executar ações dependentes deles.

## Leitura inicial

1. [Regras do dono](C:/Cripto/AGENTS.md).
2. [Configuração local](C:/Cripto/pesquisa-20260909/docs/CONFIGURACAO_LOCAL.md) e [mandato original preservado](C:/Cripto/pesquisa-20260909/docs/NEXT_CHAT_PROMPT.md).
3. [Relatório canônico, incluindo seções 18 e 19](C:/Cripto/operacao/relatorios/REVISAO_COMPLETA_20260909/REVISAO.md).
4. [Conferência publicada](C:/Cripto/pesquisa-20260909/docs/CONFERENCIA_CHAT_20260910.md) e [comprovante final de integração](C:/Cripto/operacao/relatorios/REVISAO_COMPLETA_20260909/publication_chat_20260910/integration.json).

O PR #117 está integrado em `94fc9e769fe6aaf16439e845ca29378701d34886`. Quatro jobs aprovados no PR e no main; suíte Windows pós-merge com 1.505 aprovados, um skip de symlink e zero falhas. Esses resultados pertencem à versão/datagem registrada, não substituem a conferência do estado futuro.

O snapshot v4 foi recuperado offline; a janela de frescor termina em 11/09/2026 02:00 UTC. H5/vintages históricos, confirmação Aave por segunda fonte, observações futuras e custos pessoais continuam dependências explícitas nas seções 18–19. Não há lucro pessoal/prospectivo validado. Preserve as chaves atuais; não exigir revogação como condição para a pesquisa. Segurança administrativa da branch foi excluída pelo dono.

Trabalhar sozinho, dentro de `C:\Cripto`, usando `C:\Cripto\CRIPTO.cmd` para Python/uv. Preservar dados, pacote restaurado e o executor congelado em `C:\Cripto\auditoria-ampliada-20260910`. Sem agendamentos, ordens, assinaturas, movimentação de fundos ou credenciais financeiras. Não contornar a guarda de API; recalcular disponibilidade pela data UTC atual. O repasse original não deve ter seus bytes reescritos.

## Histórico preservado localmente

A [pasta de preservação do chat](C:/Cripto/operacao/relatorios/REVISAO_COMPLETA_20260909/chat_closure_20260910/README.md) contém a cópia local do registro e das mensagens, com manifesto de integridade. Inclui o fechamento do PR #117 e o pedido de conferência antes de apagar o chat. Não foi publicada no GitHub. Não há promessa de reimportação automática desse arquivo na interface do aplicativo.

Para continuar em outra conversa: “Leia C:\Cripto\RETOMADA_APOS_CHAT_20260910.md, confira o estado real e continue a partir das pendências documentadas, preservando as restrições do dono.”

Excluir o histórico da interface não é autorização para apagar `C:\Cripto`: essa pasta mantém os dados operacionais e privados necessários, além do material já publicado.
