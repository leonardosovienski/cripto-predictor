# Cripto neste computador

O trabalho e o armazenamento do projeto ficam em **C:\Cripto**. Para continuar sem depender do chat:

1. Leia [AGENTS.md](AGENTS.md) e a [configuração local](pesquisa-20260909/docs/CONFIGURACAO_LOCAL.md).
2. Abra a [retomada preservada de 10/09](RETOMADA_APOS_CHAT_20260910.md) e a [conferência dos arquivos](pesquisa-20260909/docs/CONFERENCIA_ARQUIVOS_20260910.md), que a complementa.
3. Consulte o [registro vivo da revisão](operacao/relatorios/REVISAO_COMPLETA_20260909/REVISAO.md), o [índice documental](pesquisa-20260909/docs/README.md) e o estado real do Git.

| Local | Finalidade |
|---|---|
| `pesquisa-20260909` | Código operacional e ambiente atual |
| `auditoria-ampliada-20260910` | Executor LLM manual v3 congelado em `595f120` |
| `restaurado-20260908` | Código, ambientes, dados e diários preservados da migração |
| `configuracao/pipeline.env` | Configuração privada, fora do Git |
| `operacao` | Dados novos, saídas, cache, estado, logs e relatórios |
| `backups` | Cópias locais verificadas; compartilham o mesmo disco |

```powershell
C:\Cripto\CRIPTO.cmd status
C:\Cripto\CRIPTO.cmd pipeline --help
```

O [prompt original](pesquisa-20260909/docs/NEXT_CHAT_PROMPT.md) permanece intacto como mandato. O fechamento de 09/09 com 1.285 testes é histórico. A referência posterior ao PR #117 (`94fc9e7`) tem 1.505 testes aprovados e um skip de symlink; os resultados de cada publicação seguinte ficam no registro vivo. Não reaproveite a validação de um SHA como se fosse de outro.

`LEIA-ME.md`, `RETOMAR_NO_CODEX.md`, `dados.zip`, os manifestos e os utilitários originais pertencem ao pacote de migração. Preserve-os e preserve toda a pasta restaurada. Não execute restauração sobre esta instalação. Worktrees antigos registram etapas diferentes; aparência de duplicação não significa que podem ser apagados. A cópia limpa `publicacao-conferencia-20260910` foi retirada após comprovar igualdade com a árvore integrada; a conferência registra o commit e o comando para recriá-la.

O backup privado do chat está em `operacao/relatorios/REVISAO_COMPLETA_20260909/chat_closure_20260910`; seus hashes e o guia de retomada foram verificados. Ele não é publicado no Git.

Nenhum agendamento ou capital foi ativado. Carry e LLM aguardam as janelas dos protocolos; dados originais H5, versões macro comprovadas, segunda fonte Aave e extratos pessoais ainda têm dependências documentadas. As chaves atuais foram mantidas por decisão do dono, e a segurança da branch ficou fora do escopo.
