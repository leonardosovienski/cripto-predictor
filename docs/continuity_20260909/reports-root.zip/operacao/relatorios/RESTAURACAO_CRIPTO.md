# Restauração do projeto Cripto

**Resultado: PASS.** Conferência concluída em 2026-09-09T03:34:23.966731+00:00.

Projeto restaurado em `C:\Cripto\restaurado-20260908\projeto`.
Raiz dos dados e das sessões: `C:\Cripto\restaurado-20260908`.
Pacote original preservado em `C:\Cripto`.

| Verificação | Resultado |
|---|---|
| Arquivos do projeto, pesquisas e backups | 63.632 conferidos por SHA256 |
| Arquivos do Python preservado | 2.728 conferidos por SHA256 |
| Total do manifesto | 66.360 arquivos; 4.449.143.406 bytes de conteúdo original |
| Conferência independente após restauração e validação | PASS; nenhum arquivo inesperado fora do diretório Git |
| Pacote de origem | ZIP, manifesto, scripts e documentos mantêm os hashes anteriores |
| Dependências dos observadores | PASS; 3.785 arquivos conferidos pelo verificador do pacote |
| Altcoins | Freeze íntegro; 2 registros de diário, 1 snapshot e 616 arquivos brutos gzip verificados |
| Carry | Freeze íntegro; 1 registro de diário e 6 fontes brutas verificadas |
| Git | `git fsck --full` aprovado |
| Branch e commit | `main` — `522de73de85ada9f3491cd4c7c7d666557381f98` |
| Estado local | Somente `?? fred_test.csv`, igual ao estado exportado |

Os arquivos foram restaurados em uma pasta nova. O restaurador ajustou quatro arquivos do ambiente Python para o novo caminho: `pyvenv.cfg`, a referência `.pth` ao código e os executáveis `python.exe` e `pythonw.exe`. A segunda conferência confirmou esses quatro ajustes e os hashes originais dos demais arquivos do manifesto.

O histórico Git veio do bundle local. Não houve atualização a partir do GitHub, criação de commits, publicação ou ativação de automações. Os observadores permanecem em suas pastas históricas, separados de `projeto`.

O relatório original da execução está em `C:\Cripto\restaurado-20260908\RESTAURACAO.json`. A evidência consolidada está em [RESTAURACAO_CRIPTO.json](RESTAURACAO_CRIPTO.json).

Para repetir a validação dos observadores no PowerShell:

```powershell
& 'C:\Cripto\restaurado-20260908\sessoes\20260907-altcoins\work\cripto-v1.2\.venv\Scripts\python.exe' -B 'C:\Cripto\restaurado-20260908\validar.py' 'C:\Cripto\restaurado-20260908'
git -C 'C:\Cripto\restaurado-20260908\projeto' fsck --full
```

Os arquivos `.sha256` externos citados em `D:` não estavam acessíveis. A integridade foi conferida contra o manifesto interno do pacote presente em `C:\Cripto`, sem comparação com os checksums externos. Esta execução validou a restauração e o ambiente dos observadores; não executou a suíte de desenvolvimento nem uma nova pesquisa de rentabilidade.
