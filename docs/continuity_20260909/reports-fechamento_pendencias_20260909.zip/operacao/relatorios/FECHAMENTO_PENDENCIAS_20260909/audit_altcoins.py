"""Read-only semantic and hash inventory of both preserved altcoin acquisitions."""
import gzip
import hashlib
import json
import math
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(r'C:\Cripto\restaurado-20260908\sessoes\20260907-altcoins\work')
DAY = 86400000
result = {'at_utc':datetime.now(UTC).isoformat(), 'read_only':True, 'datasets':[]}
for name in ('altcoin-data','altcoin-retro-data'):
    folder = ROOT/name
    acq = json.loads((folder/'acquisition.json').read_bytes())
    report = {'dataset':str(folder),'acquisition_sha256':hashlib.sha256((folder/'acquisition.json').read_bytes()).hexdigest(),'pairs':[],'raw_files_checked':0,'raw_hash_errors':[],'normalized_hash_errors':[],'errors':[]}
    metadata = {p['symbol']:p for p in acq['pairs']}
    for file in sorted((folder/'raw').glob('*.json')):
        meta = json.loads(file.read_bytes())
        body_file = file.with_suffix('.bin.gz')
        if body_file.exists() and 'sha256' in meta:
            body = gzip.decompress(body_file.read_bytes())
            report['raw_files_checked']+=1
            if hashlib.sha256(body).hexdigest()!=meta['sha256']:
                report['raw_hash_errors'].append(file.name)
    for file in sorted((folder/'pairs').glob('*.json.gz')):
        body = file.read_bytes()
        data = json.loads(gzip.decompress(body))
        symbol = data['metadata']['symbol']
        rows = data['rows']; times=[r[0] for r in rows]
        meta = metadata[symbol]
        expected_hash = meta.get('normalized_sha256')
        if expected_hash and hashlib.sha256(body).hexdigest()!=expected_hash:
            report['normalized_hash_errors'].append(symbol)
        gaps = [[a+DAY,b-DAY,(b-a)//DAY-1] for a,b in zip(times,times[1:]) if b-a>DAY]
        invalid_prices = sum(not(all(math.isfinite(float(v)) for v in r[1:7]) and min(r[1:5])>0 and r[2]>=max(r[1],r[4]) and r[3]<=min(r[1],r[4]) and r[2]>=r[3] and r[5]>=0 and r[6]>=0) for r in rows)
        close_issues = sum(r[7] != r[0]+DAY-1 for r in rows)
        entry={'symbol':symbol,'rows':len(rows),'first_open_ms':min(times) if times else None,'last_open_ms':max(times) if times else None,'duplicates':len(times)-len(set(times)),'sorted':times==sorted(times),'internal_missing_days':sum(g[2] for g in gaps),'gaps':gaps,'non_daily_open':sum(t%DAY!=0 for t in times),'nonstandard_close_time_rows':close_issues,'invalid_ohlcv_rows':invalid_prices,'sha256':hashlib.sha256(body).hexdigest(),'hash_in_manifest':expected_hash is not None}
        for key,metakey in [('rows','rows'),('first_open_ms','first_open_ms'),('last_open_ms','last_open_ms'),('duplicates','duplicate_rows'),('internal_missing_days','missing_internal_days')]:
            if entry[key]!=meta.get(metakey):report['errors'].append({'symbol':symbol,'manifest_mismatch':key})
        report['pairs'].append(entry)
    report['summary']={'pairs':len(report['pairs']),'rows':sum(p['rows'] for p in report['pairs']),'pairs_with_gaps':sum(bool(p['gaps']) for p in report['pairs']),'internal_missing_days':sum(p['internal_missing_days'] for p in report['pairs']),'duplicate_rows':sum(p['duplicates'] for p in report['pairs']),'invalid_ohlcv_rows':sum(p['invalid_ohlcv_rows'] for p in report['pairs']),'nonstandard_close_time_rows':sum(p['nonstandard_close_time_rows'] for p in report['pairs']),'raw_hash_errors':len(report['raw_hash_errors']),'normalized_hash_errors':len(report['normalized_hash_errors']),'manifest_mismatches':len(report['errors'])}
    result['datasets'].append(report)
    print(json.dumps({'dataset':name,**report['summary']}),flush=True)
result['limits']='Coverage within observed listing ranges; absence outside them is not imputed. Existing universe selection remains retrospective. Hash and OHLC checks do not establish profitability or prospective independence. Raw hashes verified, not a second reconstruction of every pair.'
(Path(__file__).parent/'altcoin_data_quality.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
