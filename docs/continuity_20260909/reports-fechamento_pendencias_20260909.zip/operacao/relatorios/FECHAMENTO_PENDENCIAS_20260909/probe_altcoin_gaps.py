"""One public request per observed gap; preserve missing data and every response."""
import gzip
import hashlib
import json
import logging
from datetime import UTC,datetime
from pathlib import Path

import httpx

logging.disable(logging.CRITICAL)
RUN=Path(__file__).parent
OUT=Path(r'C:\Cripto\operacao\dados\altcoin-gap-probes-20260909')
OUT.mkdir(exist_ok=False)
audit=json.loads((RUN/'altcoin_data_quality.json').read_text(encoding='utf-8'))['datasets'][1]
gaps=[(p['symbol'],g) for p in audit['pairs'] for g in p['gaps']]
assert len(gaps)==12
scope={'registered_at_utc':datetime.now(UTC).isoformat(),'additional_public_http_attempts_max':12,'reason':'Semantic audit exposed twelve preserved spot-history gaps. Query each exact missing range once to distinguish recoverable observations from public endpoint unavailability; no strategy variant, retry, account or paid access.'}
(RUN/'altcoin_gap_probe_scope.json').write_text(json.dumps(scope,indent=2),encoding='utf-8')
results=[]
with httpx.Client(timeout=12,trust_env=False,follow_redirects=False) as client:
    for symbol,(start,end,count) in gaps:
        item={'symbol':symbol,'start_ms':start,'end_ms':end,'expected_days':count,'attempts':1,'known_at_utc':datetime.now(UTC).isoformat()}
        try:
            request=client.build_request('GET','https://api.binance.com/api/v3/klines',params={'symbol':symbol,'interval':'1d','startTime':start,'endTime':end+86399999,'limit':1000})
            response=client.send(request)
            item.update(url=str(request.url),status=response.status_code,raw_sha256=hashlib.sha256(response.content).hexdigest(),received_at_utc=datetime.now(UTC).isoformat())
            (OUT/f'{symbol}.response.gz').write_bytes(gzip.compress(response.content,mtime=0))
            if response.status_code==200:
                rows=response.json()
                if not isinstance(rows,list):raise ValueError('Unexpected response')
                item['returned_rows']=len(rows)
                item['returned_in_gap']=sum(start<=r[0]<=end for r in rows)
            else:item['returned_rows']=0
        except Exception as exc:item['error_type']=type(exc).__name__
        results.append(item)
        (OUT/f'{symbol}.metadata.json').write_text(json.dumps(item,indent=2),encoding='utf-8')
result={'http_attempts':len(results),'missing_days_total':sum(g[2] for _,g in gaps),'observations_returned_in_gaps':sum(r.get('returned_in_gap',0) for r in results),'results':results,'originals_unchanged':True}
(RUN/'altcoin_gap_probe_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='results'}),flush=True)
