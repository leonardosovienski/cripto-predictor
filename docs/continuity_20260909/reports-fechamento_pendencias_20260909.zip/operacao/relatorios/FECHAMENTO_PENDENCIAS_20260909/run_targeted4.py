from pathlib import Path
from datetime import datetime,timezone
import os,sys,subprocess,json
root=Path(r"C:\Cripto")
project=root/"pesquisa-20260909"
run=root/"operacao/relatorios/FECHAMENTO_PENDENCIAS_20260909"
temp=root/"operacao/temporarios/fechamento-targeted-20260909"
temp.mkdir(parents=True,exist_ok=True)
(temp/"empty.env").touch()
env=os.environ.copy()
for key in list(env):
    if key.endswith(("_API_KEY","_AUTH_TOKEN","_API_SECRET","_SECRET_KEY")):
        env.pop(key,None)
for key,value in {"CRIPTO_ENV_FILE":str(temp/"empty.env"),"DATA_DIR":str(temp/"data"),"OUTPUT_DIR":str(temp/"output"),"CACHE_DIR":str(temp/"cache"),"LOGS_DIR":str(temp/"logs"),"PREDICTOR_OPS_STATE_DIR":str(temp/"state"),"PREDICTOR_EVENTS_PATH":str(temp/"events.jsonl"),"COVERAGE_FILE":str(run/"targeted.coverage")}.items():env[key]=value
for name in ["DATA","OUTPUT","CACHE","LOGS"]:env["GARIMPO_"+name+"_DIR"]=env[name+"_DIR"]
command=[sys.executable,"-B","-u","-m","coverage","run","--rcfile=coverage-runtime.ini","-m","pytest","-q","tests/test_provider_runtime_config.py","tests/test_security_redaction.py","tests/test_dpl_features.py","tests/test_cache.py","--basetemp",str(temp/"pytest")]
start=datetime.now(timezone.utc)
with (run/"targeted4_tests.log").open("x",encoding="utf-8") as log:
    process=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT)
result={"started_at_utc":start.isoformat(),"finished_at_utc":datetime.now(timezone.utc).isoformat(),"returncode":process.returncode,"real_credentials_available_to_tests":False,"base_commit":"98db3ef58ce3e9f1f4cf3253dbed971de1b57c8a","log":str(run/"targeted4_tests.log")}
(run/"targeted4_status.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result))
sys.exit(process.returncode)
