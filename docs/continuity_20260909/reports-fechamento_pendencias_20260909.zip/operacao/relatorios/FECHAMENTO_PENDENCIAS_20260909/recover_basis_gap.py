"""Recover fixed 2026-06-29 gaps into a new dataset; never modify the parent."""
import gzip
import hashlib
import json
import logging
import shutil
from datetime import UTC, datetime
from pathlib import Path

import httpx
from scripts.audit_basis_sources import audit, rebuild

logging.disable(logging.CRITICAL)
OUT = Path(__file__).parent
PARENT = Path(r'C:\Cripto\restaurado-20260908\sessoes\20260907-pesquisa\work\basis-research-data')
DEST = Path(r'C:\Cripto\operacao\dados\basis-recovered-20260909')
manifest_bytes = (PARENT / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
start = int(datetime(2026, 6, 29, tzinfo=UTC).timestamp()*1000)
expected = list(range(start, start + 86400000, 3600000))
items = []
fetched = []
with httpx.Client(timeout=25, follow_redirects=False, trust_env=False) as client:
    for symbol in ('BTCUSDT_260925', 'BTCUSDT_261225'):
        item = {'symbol': symbol, 'expected_rows': 24, 'attempts': 1}
        req = client.build_request('GET', 'https://fapi.binance.com/fapi/v1/markPriceKlines', params={'symbol':symbol,'interval':'1h','startTime':start,'endTime':start+86400000-1,'limit':24})
        begun = datetime.now(UTC).isoformat()
        try:
            response = client.send(req)
            item['http_status'] = response.status_code
            if response.status_code == 200:
                body = response.content
                rows = rebuild(response.json(), 'bars')
                if [r[0] for r in rows] != expected:
                    raise ValueError('Incomplete public response')
                meta = {'url': str(req.url), 'request_started_utc': begun, 'known_at': datetime.now(UTC).isoformat(), 'status':200, 'sha256':hashlib.sha256(body).hexdigest(), 'bytes':len(body)}
                fetched.append((symbol, body, rows, meta))
                item['recovered_rows'] = len(rows)
        except Exception as exc:
            item['error_type'] = type(exc).__name__
        items.append(item)
if len(fetched) == 2:
    if DEST.exists():
        raise RuntimeError('New destination already exists')
    shutil.copytree(PARENT, DEST)
    for symbol, body, rows, meta in fetched:
        key = hashlib.sha256(meta['url'].encode()).hexdigest()
        (DEST/'raw'/f'{key}.bin.gz').write_bytes(gzip.compress(body,mtime=0))
        (DEST/'raw'/f'{key}.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
        manifest['sources'][key] = meta
        group = manifest['groups'][symbol+'_mark']
        original = json.loads(gzip.decompress((PARENT/group['file']).read_bytes()))
        combined = sorted(original+rows,key=lambda r:r[0])
        if len({r[0] for r in combined}) != len(combined):
            raise ValueError('Overlap with parent observations')
        packed = gzip.compress(json.dumps(combined,separators=(',',':')).encode(),mtime=0)
        (DEST/group['file']).write_bytes(packed)
        group.update(sha256=hashlib.sha256(packed).hexdigest(),rows=len(combined))
        group['parts'].append({'source':key,'format':'rest_bars'})
    manifest['supplement'] = {'id':'DATA-READINESS-CLOSURE-20260909','parent_manifest_sha256':hashlib.sha256(manifest_bytes).hexdigest(),'parent':str(PARENT),'acquired_at_utc':datetime.now(UTC).isoformat(),'added_rows':48,'meaning':'New derived dataset; original protocol and economic evidence preserved. Acquisition does not backdate knowledge or establish prospective evidence.'}
    manifest['network_requests'] += 2
    manifest['download_bytes'] += sum(len(x[1]) for x in fetched)
    (DEST/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    verified = audit(DEST, OUT/'basis_recovered_validation.json')
else:
    verified = {'status':'NOT_RECOVERED'}
result = {'requests':items,'derived_dataset':str(DEST) if len(fetched)==2 else None,'validation':verified['status'],'parent_manifest_unchanged':(PARENT/'manifest.json').read_bytes()==manifest_bytes,'added_rows':sum(len(x[2]) for x in fetched)}
(OUT/'basis_gap_recovery.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
