"""Bounded read-only service validation. Never persist responses or credentials."""
import json
import logging
from datetime import UTC, datetime
from pathlib import Path

import httpx

from GarimpoInvestimentos.config import settings

OUT = Path(__file__).parent / 'provider_preflight.json'
logging.disable(logging.CRITICAL)
results = []
checks = [
    ('serpapi', 'https://serpapi.com/account.json', {}, {'api_key': settings.SERP_API_KEY}, ''),
    ('gemini', 'https://generativelanguage.googleapis.com/v1beta/models', {'x-goog-api-key': settings.GEMINI_API_KEY}, {}, 'models/' + settings.GEMINI_MODEL),
    ('groq', 'https://api.groq.com/openai/v1/models', {'Authorization': 'Bearer ' + settings.GROQ_API_KEY}, {}, settings.GROQ_MODEL),
    ('cerebras', 'https://api.cerebras.ai/v1/models', {'Authorization': 'Bearer ' + settings.CEREBRAS_API_KEY}, {}, settings.CEREBRAS_MODEL),
    ('coingecko', 'https://api.coingecko.com/api/v3/ping', {'x-cg-demo-api-key': settings.COINGECKO_API_KEY}, {}, ''),
]
with httpx.Client(timeout=20, follow_redirects=False, trust_env=False) as client:
    for provider, url, headers, params, model in checks:
        item = {'provider': provider, 'at_utc': datetime.now(UTC).isoformat(), 'http_attempts': 1}
        try:
            response = client.get(url, headers=headers, params=params)
            item['http_status'] = response.status_code
            item['authenticated_metadata_ok'] = response.status_code == 200
            if response.status_code == 200:
                data = response.json()
                if provider == 'serpapi':
                    for field in ('plan_monthly_price', 'searches_per_month', 'plan_searches_left', 'total_searches_left', 'this_month_usage', 'account_rate_limit_per_hour'):
                        value = data.get(field)
                        if isinstance(value, (int, float)):
                            item[field] = value
                elif model:
                    field, name = ('models', 'name') if provider == 'gemini' else ('data', 'id')
                    entries = data.get(field, [])
                    item['listed_models'] = len(entries)
                    item['configured_model_available'] = any(x.get(name) == model for x in entries)
                    item['model'] = model
            else:
                item['failure'] = 'authentication' if response.status_code in (401, 403) else 'http_error'
        except Exception as exc:
            item['authenticated_metadata_ok'] = False
            item['error_type'] = type(exc).__name__
        results.append(item)
        OUT.write_text(json.dumps({'purpose': 'metadata_only_no_generation', 'calls': results}, indent=2), encoding='utf-8')
        print(json.dumps(item), flush=True)
