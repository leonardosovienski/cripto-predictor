"""Bounded real operational check: one asset, one generation attempt per free provider."""
import asyncio
import contextlib
import json
import logging
import sqlite3
import sys
import threading
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

import httpx
from GarimpoInvestimentos.config import settings
from GarimpoInvestimentos.security.redaction import configured_secret_values, safe_redact_text, install_log_redaction

OUT = Path(__file__).parent
secrets = configured_secret_values()
install_log_redaction(secrets)
logging.getLogger('httpx').setLevel(logging.WARNING)
logging.getLogger('httpcore').setLevel(logging.WARNING)
attempts = []
generations = Counter()
mutex = threading.Lock()
routes = {
 'api.binance.com': ('GET', ('/api/v3/klines',)),
 'api.coingecko.com': ('GET', ('/api/v3/coins/bitcoin/market_chart',)),
 'api.alternative.me': ('GET', ('/fng/',)),
 'serpapi.com': ('GET', ('/search',)),
 'generativelanguage.googleapis.com': ('POST', ('/v1beta/models/gemini-2.5-flash:generateContent',)),
 'api.groq.com': ('POST', ('/openai/v1/chat/completions',)),
 'api.cerebras.ai': ('POST', ('/v1/chat/completions',)),
}

def gate(request):
    host, path = request.url.host, request.url.path
    with mutex:
        if host not in routes or request.method != routes[host][0] or path not in routes[host][1]:
            raise RuntimeError('Endpoint outside registered diagnostic scope')
        if len(attempts)>=40:
            raise RuntimeError('Diagnostic HTTP budget exhausted')
        if request.method=='POST':
            if generations[host]>=1 or sum(generations.values())>=3:
                raise RuntimeError('Diagnostic generation budget exhausted')
            generations[host]+=1
        item={'host':host,'path':path,'method':request.method,'started_utc':datetime.now(UTC).isoformat()}
        attempts.append(item)
        return item

sync_send = httpx.Client._send_single_request
async_send = httpx.AsyncClient._send_single_request
def sync_checked(self, request):
    item=gate(request)
    try:
        response=sync_send(self,request);item['status']=response.status_code;return response
    except Exception as exc:
        item['error_type']=type(exc).__name__;raise
async def async_checked(self, request):
    item=gate(request)
    try:
        response=await async_send(self,request);item['status']=response.status_code;return response
    except Exception as exc:
        item['error_type']=type(exc).__name__;raise
httpx.Client._send_single_request=sync_checked
httpx.AsyncClient._send_single_request=async_checked

class CleanWriter:
    def __init__(self, stream):self.stream=stream
    def write(self, text):return self.stream.write(safe_redact_text(text,secrets))
    def flush(self):self.stream.flush()

result={'purpose':'OPERATIONAL_DIAGNOSTIC_NOT_PROSPECTIVE_VALIDATION','started_utc':datetime.now(UTC).isoformat(),'calls':attempts,'stages':[],'providers':{}}
with (OUT/'live_pipeline.log').open('x',encoding='utf-8') as logfile:
    writer=CleanWriter(logfile)
    with contextlib.redirect_stdout(writer),contextlib.redirect_stderr(writer):
        from GarimpoInvestimentos.cli import main
        from GarimpoInvestimentos.core.paths import FEATURE_STORE_DB, OUTPUT_DIR
        from GarimpoInvestimentos.dpl import FeatureStore
        from GarimpoInvestimentos.dpl.feature_engineering import to_hard_data
        from GarimpoInvestimentos.analyzers import ai_insights
        from GarimpoInvestimentos.collectors import news
        from GarimpoInvestimentos.core.api_guard import allow
        captured_news=[]
        original_news=news.get_news_result
        async def capture_news(*args,**kwargs):
            found=await original_news(*args,**kwargs);captured_news[:]=found.titles;return found
        news.get_news_result=capture_news
        for arguments in (['--ingest','--assets','bitcoin'], ['--assets','bitcoin','--summary']):
            sys.argv=['cripto-predictor',*arguments]
            stage={'arguments':arguments}
            try:
                main();stage['exit_code']=0
            except (Exception,SystemExit) as exc:
                stage['exit_code']=getattr(exc,'code',1);stage['error_type']=type(exc).__name__
            result['stages'].append(stage)
        store=FeatureStore(FEATURE_STORE_DB)
        hard_data=to_hard_data(store.latest_features('bitcoin','1d'))
        result['feature_keys']=sorted(hard_data)
        result['news_titles_used']=len(captured_news)
        store.close()
        for provider in ('groq','cerebras'):
            settings.LLM_PROVIDER=provider
            decision=allow('llm',provider,settings.API_GUARD_MAX_LLM_CALLS_PER_PROVIDER)
            if not decision.allowed:
                result['providers'][provider]={'budget_blocked':True};continue
            try:
                value=asyncio.run(ai_insights.analyze_asset('bitcoin',hard_data,captured_news))
                result['providers'][provider]={'judge':ai_insights.judge_signature('bitcoin'),'llm_fallback':bool(value['llm_fallback']),'score':value['opportunity_score']}
            except Exception as exc:
                result['providers'][provider]={'error_type':type(exc).__name__}
        # Re-reading the persisted Gemini result through cache must create no request
        # and must preserve the prediction identity instead of duplicating a row.
        settings.LLM_PROVIDER='gemini'
        with sqlite3.connect(FEATURE_STORE_DB) as con:
            result['tables']={name:con.execute('SELECT COUNT(*) FROM "'+name+'"').fetchone()[0] for name, in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            before=con.execute('SELECT COUNT(*) FROM predictions').fetchone()[0]
        before_calls=len(attempts)
        sys.argv=['cripto-predictor','--assets','bitcoin','--summary']
        try:main()
        except (Exception,SystemExit) as exc:result['reread_error_type']=type(exc).__name__
        with sqlite3.connect(FEATURE_STORE_DB) as con:
            after=con.execute('SELECT COUNT(*) FROM predictions').fetchone()[0]
            con.row_factory=sqlite3.Row
            rows=[dict(row) for row in con.execute('SELECT * FROM predictions')]
        result['reread']={'new_http_requests':len(attempts)-before_calls,'prediction_rows_before':before,'prediction_rows_after':after}
        result['persisted_predictions']=rows
        result['feature_store']=str(FEATURE_STORE_DB)
        result['output_dir']=str(OUTPUT_DIR)
result['finished_utc']=datetime.now(UTC).isoformat()
(OUT/'live_pipeline_result.json').write_text(safe_redact_text(json.dumps(result,indent=2,default=str),secrets),encoding='utf-8')
print(json.dumps({'stages':result['stages'],'http_attempts':len(attempts),'generation_attempts':dict(generations),'providers':result['providers'],'reread':result.get('reread'),'predictions':len(result.get('persisted_predictions',[]))}),flush=True)
