"""Bounded read-only magic/header search, including nested ZIP members; no extraction."""
import gzip
import io
import json
import os
import re
import zipfile
from datetime import UTC,datetime
from pathlib import Path

ROOT=Path(r'C:\Cripto')
OUT=Path(__file__).parent/'old_store_extended_search.json'
excluded={'.venv','venv','.git','site-packages','__pycache__','node_modules','tooling','uv-cache','python','pip','operacao','pesquisa-20260909','configuracao'}
report={'started_utc':datetime.now(UTC).isoformat(),'loose_files_examined':0,'archive_files_opened':0,'archive_entries_examined':0,'nested_archives_opened':0,'bytes_read_decompressed':0,'sqlite_magic_matches':[],'database_name_candidates':[],'export_candidates':[],'skipped':[],'errors':[]}
pattern=re.compile(r'(feature.?store|predictions|historico|history|trials|garimpo_result)',re.I)
def inspect_header(name,header):
    if header.startswith(b'SQLite format 3\x00'):report['sqlite_magic_matches'].append(name)
    suffix=Path(name).suffix.lower()
    if suffix in {'.db','.sqlite','.sqlite3','.sql','.dump'}:report['database_name_candidates'].append(name)
    if suffix in {'.csv','.json','.jsonl','.sql','.dump'} and pattern.search(Path(name).name):report['export_candidates'].append(name)
def zip_scan(stream,name,depth=0):
    if depth>3:
        report['skipped'].append({'path':name,'reason':'nested_depth_limit'});return
    try:
        with zipfile.ZipFile(stream) as z:
            report['archive_files_opened']+=1
            for entry in z.infolist():
                if entry.is_dir():continue
                if report['archive_entries_examined']>=250000:
                    report['skipped'].append({'path':name,'reason':'entry_budget'});return
                report['archive_entries_examined']+=1
                path=name+'!'+entry.filename
                parts=set(Path(entry.filename.replace('\\','/')).parts)
                if parts & excluded:continue
                if '.env' in Path(entry.filename).name.lower():continue
                with z.open(entry) as member:
                    header=member.read(16);report['bytes_read_decompressed']+=len(header)
                inspect_header(path,header)
                if header.startswith(b'PK\x03\x04') and entry.filename.lower().endswith('.zip'):
                    if entry.file_size>100000000 or report['bytes_read_decompressed']+entry.file_size>1500000000:
                        report['skipped'].append({'path':path,'reason':'nested_byte_budget'});continue
                    packed=z.read(entry);report['bytes_read_decompressed']+=len(packed)
                    report['nested_archives_opened']+=1
                    zip_scan(io.BytesIO(packed),path,depth+1)
                elif header.startswith(b'\x1f\x8b') and entry.file_size<10000000:
                    with z.open(entry) as member, gzip.GzipFile(fileobj=member) as unpacked:
                        inner=unpacked.read(16);report['bytes_read_decompressed']+=len(inner)
                    inspect_header(path+'!gzip',inner)
    except Exception as exc:
        report['errors'].append({'path':name,'type':type(exc).__name__})
for folder,dirs,files in os.walk(ROOT):
    dirs[:]=[d for d in dirs if d not in excluded]
    for name in files:
        file=Path(folder)/name
        if '.env' in name.lower():continue
        try:
            with file.open('rb') as f:header=f.read(16)
            report['loose_files_examined']+=1
            inspect_header(str(file),header)
            if header.startswith(b'PK\x03\x04') and file.suffix.lower()=='.zip':zip_scan(file,str(file))
            elif header.startswith(b'\x1f\x8b'):
                with gzip.open(file,'rb') as f:inspect_header(str(file)+'!gzip',f.read(16))
        except Exception as exc:report['errors'].append({'path':str(file),'type':type(exc).__name__})
report['finished_utc']=datetime.now(UTC).isoformat()
report['limits']='Available preserved package and restored files only; excludes environments, dependencies, secrets, current operational data and new checkout. ZIP depth 3; 250k entries; 1.5GB nested reads; individual nested ZIP max100MB. Export candidates are not certified historical predictions.'
OUT.write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:len(v) if isinstance(v,list) else v for k,v in report.items() if k!='limits'}),flush=True)
