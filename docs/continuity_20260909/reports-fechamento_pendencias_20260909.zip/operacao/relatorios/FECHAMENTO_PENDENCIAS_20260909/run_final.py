from pathlib import Path
from datetime import datetime,timezone
import os,sys,subprocess,json
root=Path(r"C:\Cripto")
project=root/"pesquisa-20260909"
run=root/"operacao/relatorios/FECHAMENTO_PENDENCIAS_20260909"
temp=root/"operacao/temporarios/fechamento-final-20260909"
temp.mkdir(parents=True,exist_ok=True)
(temp/"empty.env").touch()
env=os.environ.copy()
for key in list(env):
    if key.endswith(("_API_KEY","_AUTH_TOKEN","_API_SECRET","_SECRET_KEY")):
        env.pop(key,None)
for key,value in {"CRIPTO_ENV_FILE":str(temp/"empty.env"),"DATA_DIR":str(temp/"data"),"OUTPUT_DIR":str(temp/"output"),"CACHE_DIR":str(temp/"cache"),"LOGS_DIR":str(temp/"logs"),"PREDICTOR_OPS_STATE_DIR":str(temp/"state"),"PREDICTOR_EVENTS_PATH":str(temp/"events.jsonl"),"COVERAGE_FILE":str(run/"final.coverage")}.items():env[key]=value
for name in ["DATA","OUTPUT","CACHE","LOGS"]:env["GARIMPO_"+name+"_DIR"]=env[name+"_DIR"]
command=[sys.executable,"-B","-u","-m","coverage","run","--rcfile=coverage-runtime.ini","-m","pytest","-q","--basetemp",str(temp/"pytest")]
start=datetime.now(timezone.utc)
with (run/"final_tests.log").open("x",encoding="utf-8") as log:
    process=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT)
result={"started_at_utc":start.isoformat(),"finished_at_utc":datetime.now(timezone.utc).isoformat(),"returncode":process.returncode,"real_credentials_available_to_tests":False,"base_commit":"a4801e4cd37bcb7296976c8e84cac91f9ed11f3c","log":str(run/"final_tests.log")}
(run/"final_status.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result))
sys.exit(process.returncode)
