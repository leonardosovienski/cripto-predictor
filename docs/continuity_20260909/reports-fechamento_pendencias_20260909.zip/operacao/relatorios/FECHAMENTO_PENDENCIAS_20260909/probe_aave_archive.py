"""Six-call archive feasibility check of the previously registered historical block."""
import hashlib
import json
import logging
from datetime import UTC, datetime
from pathlib import Path

import httpx

logging.disable(logging.CRITICAL)
OUT=Path(__file__).parent/'aave_archive_followup'
OUT.mkdir(exist_ok=False)
OLD=Path(r'C:\Cripto\pesquisa-20260909\docs\evidence\economic_round_20260909\h1_rpc\005.json')
historical=json.loads(OLD.read_bytes())['request']['params']
endpoints=['https://arbitrum-one-rpc.publicnode.com','https://arbitrum-rpc.publicnode.com','https://arb1.arbitrum.io/rpc']
records=[]
with httpx.Client(timeout=12,trust_env=False,follow_redirects=False) as client:
    for endpoint in endpoints:
        chain_ok=False
        for method,params in [('eth_chainId',[]),('eth_call',historical)]:
            if method=='eth_call' and not chain_ok:break
            request={'jsonrpc':'2.0','id':len(records)+1,'method':method,'params':params}
            record={'endpoint':endpoint,'request':request,'started_utc':datetime.now(UTC).isoformat()}
            try:
                response=client.post(endpoint,json=request)
                record['http_status']=response.status_code
                record['raw_sha256']=hashlib.sha256(response.content).hexdigest()
                record['response']=response.json()
                if method=='eth_chainId':chain_ok=record['response'].get('result')=='0xa4b1'
                if method=='eth_call':record['historical_index_available']=isinstance(record['response'].get('result'),str) and len(record['response']['result'])==66 and int(record['response']['result'],16)>0
            except Exception as exc:record['error_type']=type(exc).__name__
            records.append(record)
            (OUT/f'{len(records):02}.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
result={'calls':len(records),'historical_index_available':any(r.get('historical_index_available') for r in records),'probe_block':historical[-1],'meaning':'Availability probe only, not the registered 13 weekly observations, liquidity verification or APY estimate. No capital/account activity.'}
(OUT/'report.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
