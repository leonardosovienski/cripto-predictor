# CONTINUIDADE: REVISÃO COMPLETA DE ARQUITETURA, LÓGICA, DADOS, PREMISSAS E RESULTADO ECONÔMICO

Atualizado em 09/09/2026, após a integração das correções do PR #109, confirmação dos quatro jobs de CI e preparação anterior do projeto.

Este documento é o ponto de entrada canônico para uma NOVA REVISÃO COMPLETA.

Leia primeiro:

* `FECHAMENTO_PENDENCIAS_20260909.md`;
* sua validação final;
* `AGENTS.md`;
* `CONFIGURACAO_LOCAL.md`;
* os documentos técnicos, científicos e econômicos indicados abaixo.

Mas aplique desde o início esta regra:

> Nenhum documento, relatório, README, teste anterior, resultado econômico, arquitetura descrita ou conclusão histórica deve ser tratado como verdade por autoridade.

Todos são alegações a serem confrontadas com:

* código atual;
* dados atuais;
* artefatos preservados;
* configuração real;
* testes;
* execução;
* cálculos independentes;
* proveniência;
* evidência reproduzível.

A revisão anterior pode orientar onde olhar.

Ela não certifica que o projeto está correto.

---

# 1. PEDIDO CENTRAL DO DONO

Quero uma conferência geral e profunda do projeto inteiro.

Não quero apenas procurar bugs.

Não quero apenas revisar código.

Não quero apenas produzir outra lista de pendências.

Quero descobrir, com evidência:

1. tudo o que o projeto diz que possui;
2. tudo o que realmente possui;
3. tudo o que diz fazer;
4. tudo o que realmente faz;
5. tudo o que pressupõe ser verdade;
6. quais dessas premissas são verdadeiras;
7. quais estão erradas;
8. quais nunca foram comprovadas;
9. quais ficaram desatualizadas;
10. quais dados temos;
11. quais dados não temos;
12. quais dados são adequados ao uso pretendido;
13. quais dados faltantes invalidam conclusões;
14. quais componentes realmente são usados;
15. quais existem mas não participam do fluxo;
16. quais são históricos ou abandonados;
17. quais decisões técnicas foram boas;
18. quais precisam ser revistas;
19. quais resultados econômicos sobrevivem a uma nova verificação;
20. o que falta resolver para deixar cada parte pronta para seu uso declarado.

A ordem importa.

Comece pelo que já existe.

Primeiro entenda.

Depois confira.

Depois critique.

Depois corrija.

Depois teste.

Depois meça.

Depois conclua.

---

# 2. PRINCÍPIO FUNDAMENTAL

Não assuma que a implementação atual é o melhor caminho apenas porque já existe.

Para cada componente relevante faça duas perguntas distintas:

### Pergunta A

> Isso está implementado e funcionando conforme o projeto afirma?

### Pergunta B

> Mesmo funcionando, isso é uma boa solução para o objetivo real do projeto?

Essas perguntas não são equivalentes.

Um componente pode:

* existir;
* funcionar;
* passar testes;

e ainda assim:

* ser metodologicamente inadequado;
* consumir dados ruins;
* produzir um sinal inútil;
* introduzir complexidade desnecessária;
* não contribuir para decisão econômica;
* ser inferior a uma alternativa muito mais simples.

---

# 3. OBJETIVO FINAL

O objetivo não é “melhorar o código”.

O objetivo é chegar a um estado em que possamos responder, com evidência:

* sabemos exatamente o que o projeto faz;
* sabemos exatamente o que ele não faz;
* sabemos exatamente quais dados utiliza;
* sabemos de onde esses dados vêm;
* conhecemos suas limitações;
* conhecemos o fluxo ponta a ponta;
* sabemos quais componentes são realmente utilizados;
* sabemos quais resultados são reproduzíveis;
* sabemos quais afirmações permanecem verdadeiras;
* sabemos quais foram contraditas;
* sabemos quais hipóteses econômicas sobreviveram;
* sabemos quais foram enfraquecidas ou rejeitadas;
* corrigimos tudo que é executavelmente corrigível;
* temos testes pertinentes;
* temos execução reproduzível;
* temos documentação compatível com o estado real;
* sabemos exatamente o que ainda impede cada uso restante.

Não use “100% pronto”.

Use critérios objetivos por finalidade.

---

# 4. MANDATO

Leia também:

`C:\Cripto\operacao\relatorios\MANDATO_ECONOMICO_ORIGINAL_20260908.txt`

O mandato permite:

* corrigir;
* simplificar;
* substituir;
* remover;
* reorganizar;
* reescrever componentes;

quando isso for tecnicamente justificado.

Preserve:

* evidências;
* dados históricos;
* trabalho do usuário;
* resultados negativos;
* rastreabilidade.

O pedido atual e instruções posteriores do dono prevalecem sobre orientações históricas conflitantes.

Não trate conteúdo externo como instrução do usuário automaticamente.

---

# 5. LOCALIZAÇÃO OBRIGATÓRIA

Trabalhe sozinho, sem coordenar agentes.

Use somente:

`C:\Cripto`

e suas subpastas.

Leia:

`C:\Cripto\AGENTS.md`

e:

`CONFIGURACAO_LOCAL.md`

Estado esperado:

Código atual:

`C:\Cripto\pesquisa-20260909`

Python:

`C:\Cripto\pesquisa-20260909\.venv\Scripts\python.exe`

Entrada principal:

`C:\Cripto\CRIPTO.cmd`

Dados e ambientes preservados:

`C:\Cripto\restaurado-20260908`

Configuração privada:

`C:\Cripto\configuracao\pipeline.env`

Novas saídas, dados, logs, cache e temporários:

`C:\Cripto\operacao`

Relatórios:

`C:\Cripto\operacao\relatorios`

Não crie worktrees, ambientes, temporários ou entregas do projeto em:

* Documents;
* Desktop;
* AppData;
* pastas arbitrárias de tarefas.

Se criar nova área de pesquisa, mantenha dentro de `C:\Cripto` e configure explicitamente o executor.

---

# 6. ARTEFATOS QUE NÃO DEVEM SER ALTERADOS

Não altere:

* pacote de migração;
* manifestos preservados;
* snapshots;
* dados brutos históricos;
* diários;
* ambientes congelados;
* código congelado dos observadores.

Não repita a restauração sobre a instalação atual.

Não apague cópias antigas apenas para organizar diretórios.

Evidência histórica deve permanecer histórica.

Quando um documento congelado estiver errado:

* preserve seus bytes;
* publique uma errata vinculada.

---

# 7. ESTADO TÉCNICO DE PARTIDA — TRATAR COMO ALEGAÇÃO A REVALIDAR

Antes desta atualização documental, o checkout estava descrito como:

branch:

`fix/data-readiness-20260909`

HEAD/origin/main:

`276d6db224f266e9ec889b6de4ab5ba0328cc321`

Código integrado equivalente à versão testada:

`e1c2a26ec6567cb56bb96dca300d4372a4a0fc83`

O repasse foi alterado posteriormente.

Portanto:

* preserve diff documental local;
* confirme o estado real;
* não faça downgrade automático para SHA citado em documento antigo.

A validação anterior registra:

* 1.285 testes locais aprovados;
* 1 skip por permissão de symlink no Windows;
* zero falhas;
* 1.286 testes aprovados no CI com extras;
* cobertura `coverage-runtime.ini`: 88,5089%, exibida como 89%;
* quatro jobs aprovados no CI;
* run `34403156484`.

Referência:

`C:\Cripto\operacao\relatorios\FECHAMENTO_PENDENCIAS_20260909\VALIDACAO_FINAL.json`

Esses números são evidência histórica.

Eles NÃO comprovam:

* a nova linha de base;
* taxa de acerto;
* ausência de bugs metodológicos;
* qualidade dos dados;
* ausência de leakage;
* validade econômica;
* adequação arquitetural;
* corretude de todas as premissas.

Não sobrescreva essa evidência.

---

# 8. COMEÇO OBRIGATÓRIO

Comece verificando exatamente:

```powershell
Set-Location -LiteralPath 'C:\Cripto\pesquisa-20260909'
git status --short
git branch --show-current
git rev-parse HEAD
git worktree list
C:\Cripto\CRIPTO.cmd status
```

Depois:

1. leia `AGENTS.md`;
2. leia `CONFIGURACAO_LOCAL.md`;
3. registre estado Git;
4. identifique alterações locais;
5. preserve evidência;
6. inventarie estrutura;
7. reconstrua arquitetura;
8. só então avance para alterações.

Não inicie pipeline conectado antes de conferir:

* cotas gratuitas;
* guarda de API;
* retries;
* exposição de secrets;
* necessidade real daquela chamada.

---

# 9. REGRA DE OURO DA AUDITORIA

Quatro estados diferentes devem permanecer separados:

### EXISTE

O código, dado ou artefato está presente.

### FUNCIONA

Foi exercitado e produziu o comportamento esperado naquele escopo.

### ESTÁ CORRETO

A lógica, metodologia ou cálculo foi confrontado com uma referência adequada.

### FOI VALIDADO PARA O USO DECLARADO

Existe evidência suficiente para confiar nele na finalidade específica.

Nunca converta automaticamente:

`EXISTE → FUNCIONA → ESTÁ CORRETO → ESTÁ VALIDADO`

Cada transição exige evidência própria.

---

# 10. FASE 1 — INVENTÁRIO COMPLETO

Faça primeiro um inventário do repositório e dos componentes relacionados.

Examine:

* diretórios;
* código-fonte;
* módulos;
* scripts;
* CLIs;
* entrypoints;
* README;
* documentação;
* requirements;
* pyproject;
* package.json;
* Docker;
* docker-compose;
* CI;
* workflows;
* `.env` de exemplo;
* migrations;
* banco;
* notebooks;
* modelos salvos;
* datasets;
* configs;
* fixtures;
* testes;
* artefatos;
* observadores preservados;
* relatórios;
* caches relevantes;
* arquivos gerados;
* módulos compartilhados.

Não diga que “leu tudo” apenas porque listou arquivos.

Registre cobertura de leitura como:

* examinado diretamente;
* examinado por amostragem;
* apenas inventariado;
* não examinado;
* histórico/frozen.

---

# 11. MAPA REAL DO SISTEMA

Construa um mapa:

| Componente | Responsabilidade | Entrada | Saída | Dependências | Consumidor real | Estado |
| ---------- | ---------------- | ------- | ----- | ------------ | --------------- | ------ |

Classifique componentes como:

* implementado e conectado;
* implementado mas não utilizado;
* parcialmente implementado;
* simulado;
* planejado;
* desativado;
* histórico;
* duplicado;
* aparentemente abandonado;
* inconsistente.

Reconstrua especificamente as relações atuais entre:

* GarimpoInvestimentos;
* DPL;
* Feature Store;
* V3;
* módulos compartilhados;
* componentes de pesquisa;
* pipeline econômico;
* observadores preservados.

Use os nomes atuais encontrados no código.

Não confie nos nomes históricos sem conferir.

---

# 12. FASE 2 — RECONSTRUIR O QUE O PROJETO PROMETE

Leia e confronte:

* README principal;
* documentação;
* comentários;
* interfaces;
* endpoints;
* relatórios;
* configurações;
* material econômico;
* material destinado ao investidor;
* auditorias anteriores.

Crie uma matriz canônica:

| ID | Afirmação | Origem/versão | Significado verificável | Evidência necessária | Verificação | Resultado | Impacto | Ação |
| -- | --------- | ------------- | ----------------------- | -------------------- | ----------- | --------- | ------- | ---- |

Estados permitidos:

* comprovada no escopo testado;
* parcialmente comprovada;
* contradita;
* não verificada;
* desatualizada.

Uma afirmação repetida em dez documentos continua sendo uma afirmação.

Repetição documental não é evidência independente.

---

# 13. FUNCIONALIDADES A CONFERIR

Inclua tudo que encontrar, inclusive — sem se limitar a:

* coleta automática;
* preços;
* OHLCV;
* futuros;
* spot;
* altcoins;
* funding;
* notícias;
* busca;
* LLMs;
* score;
* seleção;
* indicadores;
* Feature Store;
* geração de features;
* ML;
* modelos;
* treinamento;
* inferência;
* previsão;
* validação;
* backtesting;
* walk-forward;
* dimensionamento;
* risco;
* execução simulada;
* custos;
* métricas;
* histórico;
* caches;
* API;
* frontend;
* banco;
* observadores;
* scheduler;
* automações;
* Docker;
* CI;
* deployment;
* reporting.

Para cada uma:

> O projeto afirma que isso existe?

> Existe?

> Está conectado?

> Está sendo usado?

> Funciona?

> Está correto?

> Está validado?

> Ainda faz sentido?

---

# 14. FASE 3 — AUDITORIA COMPLETA DOS DADOS

Esta é uma das partes mais importantes.

Para cada frente e fluxo ativo, identifique:

* dado necessário;
* dado disponível;
* fonte;
* endpoint;
* arquivo;
* ativo;
* identidade do contrato;
* campo;
* unidade;
* frequência;
* intervalo temporal exigido;
* intervalo disponível;
* timezone;
* timestamp do evento;
* timestamp de disponibilidade;
* esquema;
* quantidade;
* duplicatas;
* gaps;
* inválidos;
* outliers;
* procedência;
* hashes;
* bruto;
* derivado;
* coletor;
* normalizador;
* consumidor;
* acesso;
* cota;
* evidência de validação.

Monte:

| Dado necessário | Temos? | Fonte | Cobertura | Qualidade | Adequado? | Consumidor | Lacuna |
| --------------- | ------ | ----- | --------- | --------- | --------- | ---------- | ------ |

Diferencie:

* chave preenchida;
* autenticação aceita;
* endpoint acessível;
* resposta válida;
* cobertura suficiente.

Esses estados não são equivalentes.

---

# 15. DADOS: REGRAS DE INTEGRIDADE

Procure ativamente:

* gaps;
* duplicações;
* timezone incorreto;
* candle ainda aberto;
* timestamps desalinhados;
* volume incorreto;
* símbolo errado;
* contrato errado;
* mudança de identidade;
* resolução incompatível;
* alteração de metodologia da fonte;
* unidades incompatíveis;
* normalização inconsistente;
* cache incorreto;
* mistura de dados atuais e históricos;
* reconstrução com informação futura;
* silent fallback;
* dados sintéticos tratados como reais.

Não:

* interpole silenciosamente;
* transforme aproximação em observação;
* trate dado obtido hoje como se estivesse disponível historicamente;
* misture diagnóstico operacional com avaliação prospectiva;
* invente cobertura que não existe.

---

# 16. ESTADO DE DADOS CONHECIDO — REVALIDAR

A preparação anterior registrou:

* 48 observações de futuros recuperadas em nova base;
* reconstrução independente do normalizador;
* duas bases de altcoins verificadas;
* 12 intervalos ausentes sem retorno em consultas públicas específicas;
* banco antigo não encontrado;
* produção de mercado, notícias, análises, histórico e cache;
* correções envolvendo CoinGecko, candle fechado, volume e identidade de cache.

Pendências conhecidas:

* 542 dias de observações ausentes somados entre 12 pares;
* 200 fechamentos não padrão;
* banco antigo de previsões não encontrado;
* inputs exatos da H5 não encontrados;
* índices históricos e liquidez necessários à Aave não obtidos;
* ausência de observações futuras independentes.

Confira cada uma dessas afirmações.

Não trate 542 como 542 dias consecutivos.

Não trate duas aquisições da mesma retrospectiva como universos independentes.

Não use 200 candles de diagnóstico como prova de cobertura global.

---

# 17. RECUPERAÇÃO DE DADOS FALTANTES

Para cada ausência:

1. identifique exatamente o dado faltante;
2. identifique por que ele importa;
3. verifique se realmente não existe localmente;
4. examine tentativas anteriores;
5. não repita consulta sem nova hipótese;
6. procure fontes oficiais;
7. procure alternativas públicas compatíveis;
8. confira identidade do ativo;
9. confira intervalo;
10. confira metodologia;
11. confira disponibilidade histórica;
12. confira gratuidade;
13. limite número de tentativas;
14. preserve resposta;
15. manifeste proveniência.

Se uma fonte alternativa tiver metodologia diferente:

* não combine silenciosamente;
* compare antes;
* documente impacto.

Se o dado continuar indisponível:

registre:

* tentativas;
* motivo;
* dependência externa;
* conclusão impedida;
* caminho ainda executável.

Ausência de dado não autoriza inventar resultado.

---

# 18. CHAVES E SERVIÇOS EXTERNOS

Estado registrado anteriormente:

* `GEMINI_API_KEY`;
* `SERP_API_KEY`;
* `GROQ_API_KEY`;
* `CEREBRAS_API_KEY`;
* `COINGECKO_API_KEY`;

preenchidas.

Modo selecionado:

* Gemini;
* SerpAPI.

Também existe arquivo:

`C:\Cripto\.env.txt`

Ele é uma lista anotada.

Não trate como dotenv diretamente carregável.

Contém também:

* GNews;
* Binance.

GNews ≠ NewsAPI.ai.

Não faça mapeamento silencioso.

Credenciais Binance não autorizam uso de conta.

Não use credenciais financeiras.

---

# 19. SEGREDOS

Nunca imprima:

* segredo completo;
* prefixo;
* hash;
* fragmento identificável;
* conteúdo privado.

Não exponha secrets em:

* terminal;
* logs;
* testes;
* exceptions;
* documentos;
* commits;
* relatórios.

Reporte apenas:

* nome da variável;
* tipo do erro;
* status da integração.

Não copie secrets para o checkout Git.

---

# 20. COTAS E GRATUIDADE

A guarda anterior registrou limites diários:

* 28 unidades de ingestão;
* 8 tentativas de notícias por provedor;
* 6 chamadas lógicas de LLM por provedor.

Eles:

* não são cotas oficiais;
* não são teto monetário;
* não autorizam gasto.

O dono confirmou uso somente de recursos gratuitos.

Não:

* habilite serviços pagos;
* gere nova despesa;
* apague banco de orçamento;
* burle cotas;
* aumente retries para “forçar” uma resposta.

Antes de chamadas conectadas, confira necessidade e disponibilidade gratuita.

---

# 21. FASE 4 — RECONSTRUÇÃO DO PIPELINE PONTA A PONTA

Mapeie:

`aquisição`

→ `normalização`

→ `armazenamento`

→ `proveniência`

→ `tempo de disponibilidade`

→ `features`

→ `scores`

→ `notícias/LLMs`

→ `seleção`

→ `sinais`

→ `validação`

→ `backtest`

→ `custos`

→ `dimensionamento`

→ `risco`

→ `execução simulada`

→ `resultado`

→ `relatório`

→ `operação`

Para cada etapa:

* finalidade;
* entrada;
* saída;
* dependências;
* consumidor real;
* evidência de funcionamento;
* modo de falha;
* fallback;
* custo;
* latência;
* risco metodológico.

Procure:

* funções desconectadas;
* código morto;
* wrappers que escondem dependências;
* duplicação;
* gargalos;
* cache incorreto;
* falha silenciosa;
* caminhos nunca exercitados.

---

# 22. FASE 5 — AUDITORIA DE ML, SINAIS E PREVISÃO

Se houver modelos, previsões, scores ou lógica estatística, reconstrua primeiro a definição real do problema.

Identifique:

* target;
* horizonte;
* frequência;
* ativo;
* target econômico;
* regressão/classificação/ranking;
* interpretação da saída;
* uso real da previsão.

Depois confira:

## Preparação

* limpeza;
* transformação;
* normalização;
* janela;
* indicadores;
* features;
* missing data;
* temporalidade.

## Split

Procure:

* shuffle indevido;
* mistura de futuro;
* normalização usando teste;
* feature calculada com futuro;
* leakage indireto;
* seleção de universo ex-post;
* survivor bias.

## Modelos

Para cada modelo:

* por que existe;
* onde é usado;
* inputs;
* outputs;
* hiperparâmetros;
* treinamento;
* persistência;
* loading;
* inferência;
* compatibilidade com código atual;
* evidência de treinamento real.

Não confunda arquivo de modelo com modelo válido.

---

# 23. BASELINES

Qualquer complexidade preditiva deve ser comparada com alternativas simples adequadas.

Quando fizer sentido, use:

* último preço;
* random walk;
* média;
* média móvel;
* regra simples;
* buy-and-hold;
* ausência de trade;
* benchmark operacional simples.

Um modelo complexo não é automaticamente útil.

Pergunta obrigatória:

> O componente adiciona valor mensurável frente a uma alternativa simples?

---

# 24. NOTÍCIAS, SCORE E LLMs

Reexamine especialmente:

* utilidade real do score;
* contribuição incremental;
* atraso de publicação;
* disponibilidade histórica;
* causalidade;
* alinhamento temporal;
* estabilidade;
* custo;
* reprodutibilidade;
* fallback;
* dependência do provedor.

Não presuma que notícias ou LLM melhoram resultado.

Meça.

Quando não houver evidência de contribuição:

* simplifique;
* desative;
* ou mantenha apenas onde seu benefício seja demonstrável.

---

# 25. FASE 6 — BACKTESTING

Descubra se existe backtesting real ou apenas código com esse nome.

Verifique:

* ordem temporal;
* walk-forward;
* rolling windows;
* treino/validação/teste;
* preço executável;
* candle correto;
* disponibilidade da informação;
* spread;
* slippage;
* taxa;
* funding;
* latência;
* liquidez;
* margem;
* caixa;
* posição;
* sizing;
* principal;
* custos;
* look-ahead;
* survivor bias;
* data leakage.

Se houver trading:

* regra de entrada;
* regra de saída;
* posição;
* risco;
* stop;
* exposição;
* rebalance;
* retorno;
* drawdown;
* capacidade.

Não confunda:

boa previsão estatística

com:

estratégia economicamente executável.

---

# 26. CÁLCULOS ECONÔMICOS

Refaça cálculos materiais por caminho independente sempre que possível.

Confira:

* unidades;
* porcentagens;
* principal;
* capital comprometido;
* retorno nominal;
* lucro bruto;
* lucro líquido;
* taxas;
* funding;
* spread;
* slippage;
* drawdown;
* caixa;
* margem;
* posições;
* moeda;
* USDT;
* USDC;
* BRL;
* conversão.

Não:

* trate principal como lucro;
* some cenários independentes usando o mesmo capital;
* misture moedas sem conversão;
* trate ganho acumulado como mensal;
* trate simulação como execução real.

---

# 27. RESULTADOS ECONÔMICOS ANTERIORES — REVALIDAR

Referência histórica:

capital hipotético:

`5.000 USDT`

Período:

`01/01/2024 a 07/09/2026`

`980 dias`

Resultados registrados:

### AR1 BTC

Base:

`+424,25 USDT`

Adverso:

`+341,13 USDT`

Contribuição adversa de 2026 até o corte:

`+5,75 USDT`

### BR1 BTC

Base:

`+230,17 USDT`

Adverso:

`+110,07 USDT`

Cinco operações.

Nenhuma em 2026.

### AR2 BTC original

Base:

`+17,79 USDT`

Adverso:

`-82,26 USDT`

Renovação adjacente reduzida:

Base hipotética:

`+23,63`

Adverso:

`-65,90`

Limite otimista ampliado:

adverso ainda:

`-65,39`

Isso rejeita apenas a renovação como correção suficiente naquela referência.

Não rejeita automaticamente toda hipótese de carry.

### AR3

Perda modelada próxima de 99% no cenário base.

### BR2

Nenhuma entrada.

### Seletor de altcoins

Zero operações em 140 semanas.

### Diagnóstico carry — 84 dias até 08/09/2026

Base:

`+10,56`

Adverso:

`-6,97`

Estresse:

`-21,65`

Não equivale a piloto prospectivo.

### H1 — Aave USDC

Inconclusiva.

Motivo registrado:

acesso histórico bloqueado.

Não houve rendimento medido.

Necessita:

* índices históricos;
* liquidez de retirada.

Chaves LLM não resolvem esse problema.

Todos esses resultados devem ser CONFRONTADOS, não copiados.

---

# 28. FASE 7 — INVESTIGAR ZERO TRADES

Sempre que uma estratégia produzir zero entradas, determine a causa.

Possibilidades:

* dados ausentes;
* bug;
* condição impossível;
* filtro excessivo;
* desalinhamento temporal;
* ativo incorreto;
* campo incorreto;
* sinal nunca gerado;
* condição economicamente rara;
* hipótese válida mas sem eventos.

Não afrouxe filtros apenas para gerar operações.

Zero trade pode ser resultado legítimo.

---

# 29. FASE 8 — ARQUITETURA

Reconstrua arquitetura atual a partir de:

* código;
* testes;
* configuração;
* entrypoints;
* dependências;
* execução.

Use `ARQUITETURA_CONSOLIDADA.md` apenas como retrato histórico.

Compare:

## ARQUITETURA ATUAL

versus

## ARQUITETURA RECOMENDADA

Avalie:

* responsabilidade;
* acoplamento;
* coesão;
* modularidade;
* duplicação;
* abstração;
* dependência;
* estado;
* configuração;
* persistência;
* pipeline;
* interfaces;
* manutenção;
* observabilidade.

Para cada decisão relevante classifique:

* manter;
* simplificar;
* substituir;
* remover.

Explique:

* contribuição;
* complexidade;
* custo;
* risco;
* alternativa simples;
* efeito mensurável.

Não faça rewrite geral por estética.

---

# 30. FASE 9 — EXECUÇÃO REAL DO SISTEMA

Reconstrua o caminho necessário para executar do zero.

Valide:

1. instalação;
2. ambiente;
3. dependências;
4. configuração;
5. secrets;
6. banco;
7. migrations;
8. ingestão;
9. normalização;
10. armazenamento;
11. processamento;
12. features;
13. treinamento;
14. inferência;
15. sinais;
16. pesquisa econômica;
17. API;
18. frontend, se existir;
19. testes;
20. pacote;
21. entrypoint Windows;
22. Docker, se disponível.

Para falha:

`CAUSA → IMPACTO → CORREÇÃO → TESTE DE REGRESSÃO`

---

# 31. FASE 10 — TESTES COMPLETOS

Execute novamente:

* suíte completa;
* extras;
* lint;
* formatação;
* tipagem;
* build;
* pacote instalado;
* entradas Windows;
* verificações equivalentes a `.github/workflows/ci.yml`.

Diferencie:

* teste sintético;
* fixture;
* teste com dado preservado;
* teste de integração;
* verificação conectada;
* teste econômico;
* teste de causalidade.

Informe:

* quantidade coletada;
* aprovados;
* falhas;
* skips;
* não coletados;
* razão ambiental.

Não use o número antigo como certificado novo.

---

# 32. TESTES NÃO DEVEM SER TAUTOLOGIAS

Não crie teste que simplesmente repita a implementação.

Prefira:

* invariantes;
* exemplos calculados independentemente;
* propriedades;
* casos extremos;
* regressões;
* comportamento esperado;
* comparação contra referência externa ou cálculo manual.

Um teste passando só comprova o que ele exercitou.

---

# 33. FASE 11 — SEGURANÇA E OPERACIONALIZAÇÃO

Confira:

* secrets;
* tokens;
* `.env`;
* logs;
* exceptions;
* validação de entrada;
* permissões;
* retries;
* timeouts;
* rate limits;
* dependências;
* observabilidade;
* recuperação de falha;
* comportamento offline;
* fallback.

Verifique também:

* execução reproduzível;
* paths;
* caches;
* temporários;
* integridade de config.

---

# 34. FASE 12 — CONTRADIÇÕES

Crie uma seção explícita:

# “O projeto pressupõe que X é verdade, mas verificamos que…”

Procure ativamente:

* README diz que existe, código não existe;
* código existe, não é chamado;
* endpoint existe, serviço não;
* modelo existe, nunca foi treinado;
* modelo salvo não corresponde ao código;
* tabela está prevista, migration não existe;
* pipeline exige dado nunca coletado;
* frontend espera endpoint inexistente;
* métrica é exibida incorretamente;
* relatório usa resultado antigo;
* teste aprova mock mas fluxo real quebra;
* documentação diz que algo está resolvido mas condição ainda existe.

Essa seção é obrigatória.

---

# 35. FASE 13 — PREMISSAS

Para cada premissa material, registre:

* premissa;
* origem;
* por que deveria ser válida;
* condição em que falha;
* observação que a refutaria;
* verificação feita;
* resultado.

Reexamine especialmente:

* causalidade;
* score;
* notícias;
* LLM;
* disponibilidade histórica;
* continuidade de fonte;
* custo;
* retorno;
* ausência de trades;
* qualidade de série;
* tamanho de amostra;
* liquidez;
* execução.

Suspeita continua sendo hipótese até reprodução.

---

# 36. FASE 14 — ESTADO REAL DO PROJETO

Ao final da auditoria inicial, classifique cada área:

✅ Pronta para o uso declarado

🟡 Pronta com limitações que não invalidam esse uso

🔴 Bloqueada por dependência identificada

⚫ Abandonada por evidência

⚠️ Implementada, mas requer revisão

Áreas mínimas:

* dados;
* ingestão;
* armazenamento;
* normalização;
* proveniência;
* features;
* notícias;
* LLM;
* score;
* ML;
* treinamento;
* inferência;
* sinais;
* backtesting;
* custos;
* risco;
* execução simulada;
* API;
* frontend;
* testes;
* CI;
* Docker;
* documentação;
* segurança;
* observabilidade;
* pesquisa econômica.

---

# 37. FASE 15 — GAP ANALYSIS

Produza uma lista canônica de gaps.

Prioridade:

### P0

Invalida funcionamento, segurança ou resultado.

### P1

Necessário para considerar a finalidade pronta.

### P2

Melhoria importante.

### P3

Melhoria futura.

Para cada item:

* ID;
* problema;
* evidência;
* causa;
* impacto;
* solução;
* arquivos/componentes;
* dependências;
* teste;
* critério objetivo de aceite;
* estado.

Não transforme toda observação em P0/P1.

---

# 38. FASE 16 — CORRIGIR, NÃO APENAS REPORTAR

Depois que houver evidência suficiente:

`AUDITAR → CORRIGIR → TESTAR → MEDIR → VALIDAR → CONTINUAR`

Não pare no relatório.

Resolva o que puder dentro da autorização.

Para alteração significativa registre antes:

* problema;
* evidência;
* causa;
* opção escolhida;
* alternativa descartada;
* risco;
* critério de sucesso.

Depois:

* implemente;
* teste;
* compare antes/depois.

---

# 39. MELHORIAS

Uma melhoria deve ter pelo menos uma contribuição justificável em:

* corretude;
* confiabilidade;
* simplicidade;
* manutenção;
* custo;
* velocidade;
* reproducibilidade;
* decisão econômica;
* segurança.

Evite:

* refactor cosmético;
* abstração sem consumidor;
* rewrite geral;
* feature sem uso;
* aumento de complexidade não medido.

---

# 40. FOCO ECONÔMICO

O objetivo econômico é:

> lucro líquido absoluto executável em cripto.

Considere:

* capital comprometido;
* perda possível;
* custos;
* liquidez;
* capacidade;
* manutenção;
* risco operacional.

Não existe obrigação de superar:

* BTC;
* Selic;
* benchmark arbitrário.

Benchmarks podem servir para contextualizar.

Não são requisito oculto.

---

# 41. CAPITAL

Referência:

`5.000 USDT`

É capital hipotético.

Não é:

* saldo real;
* permissão para investir;
* autorização para conta;
* autorização para ordem.

`capital_permission = false`

Permanece falso.

---

# 42. LIMITES FINANCEIROS

Não:

* envie ordens;
* assine transações;
* movimente fundos;
* use credenciais Binance;
* conecte conta financeira;
* crie contas;
* contrate serviços;
* habilite plano pago;
* envie comunicação ao investidor.

Pode:

* simular;
* pesquisar;
* calcular;
* coletar dados públicos pontualmente;
* preparar material para o dono revisar.

---

# 43. PESQUISA ECONÔMICA

Reavalie criticamente ideias antigas e oportunidades ainda elegíveis.

Perguntas centrais:

1. Quem paga economicamente pelo retorno?
2. Por que esse retorno deveria existir?
3. O que consome esse retorno?
4. Quanto sobra depois de custos?
5. Qual capital precisa ficar comprometido?
6. Qual perda é possível?
7. Qual capacidade existe?
8. Qual dependência operacional existe?
9. Qual observação destruiria a hipótese?

Priorize:

* uma hipótese principal;
* no máximo uma alternativa ativa.

Não mantenha busca indefinida até achar backtest positivo.

---

# 44. EXPERIMENTOS

Antes de observar novos resultados, registre:

* hipótese;
* dados;
* período;
* variantes;
* métrica;
* custos;
* critérios;
* orçamento de experimentos;
* condição de interrupção.

Resultados negativos também contam.

Não reabra família encerrada apenas para procurar configuração vencedora.

Para reabrir:

* documente nova evidência material;
* estabeleça novo protocolo.

---

# 45. ADAPTAÇÃO E VALIDAÇÃO INDEPENDENTE

Dados históricos já examinados anteriormente fazem parte de pesquisa adaptativa.

Não chame isso de validação independente.

Validação independente requer:

* dados temporais ainda não utilizados;
* ou observação futura.

Não:

* retrodate registro;
* invente amostra prospectiva;
* ajuste sinal depois de observar resultado e chame de teste;
* trate diagnóstico como piloto.

---

# 46. CUSTOS DESCONHECIDOS

Custos desconhecidos não autorizam conclusão inventada.

Quando faltar informação, produza:

* cenário;
* intervalo;
* break-even;
* sensibilidade;
* dependência explícita.

Separe:

* custo de desenvolvimento;
* custo recorrente;
* custo de execução;
* custo de dados;
* custo de infraestrutura.

O gasto total do projeto ainda não foi consolidado.

Não invente ROI do dono ou investidor.

---

# 47. OBSERVADORES PRESERVADOS

Altcoins:

`C:\Cripto\restaurado-20260908\sessoes\20260907-altcoins\work\cripto-v1.2`

Carry:

`C:\Cripto\restaurado-20260908\sessoes\20260907-pesquisa\work\cripto-research`

AR2:

`C:\Cripto\restaurado-20260908\sessoes\20260907-pesquisa\work\carry-research-data`

Não:

* recrie;
* migre;
* reative automações;
* altere código congelado.

Horários antigos são históricos.

---

# 48. GIT E PUBLICAÇÃO

Branches, commits, PRs e integração estão autorizados quando tecnicamente necessários.

Leia:

`POLITICA_DE_MERGE.md`

Antes de integrar:

* revise diff;
* valide base;
* preserve evidências;
* execute checks.

Jobs exigidos:

* `quality`;
* `all-extras`;
* `container`;
* `python-314-experimental`.

Depois da integração:

* confira SHA;
* conteúdo;
* checks;
* estado resultante.

Não:

* force-push;
* faça limpeza destrutiva;
* sobrescreva evidência;
* divulgue dado privado.

Se integração não for segura:

deixe PR revisável.

---

# 49. DOCUMENTOS QUE DEVEM SER LIDOS E CONFRONTADOS

Inclua:

* README principal;
* índice da documentação;
* `CURRENT_RESEARCH_STATE_20260908.md`;
* `SESSION_HANDOFF_20260908.md`;
* `PROFIT_RESEARCH.md`;
* `evidence/profit_research_20260908/scope.json`;
* `HYPOTHESES.md`;
* `charters/scientific_state.json`;
* `evidence/economic_round_20260909/RESULTADOS.md`;
* `PRONTIDAO_DADOS.md`;
* `FECHAMENTO_PENDENCIAS_20260909.md`;
* `ARQUITETURA_CONSOLIDADA.md`;
* `RESULTADOS_ECONOMICOS_20260909.json`;
* `RESULTADO_GERAL_20260909.md`;
* `ATUALIZACAO_INVESTIDOR_20260909.md`;
* `ATUALIZACAO_INVESTIDOR_20260909_FINAL.md`.

Documentos antigos devem ser contextualizados pela data.

Não apresente texto antigo como estado atual sem revalidar.

---

# 50. REGISTRO CANÔNICO VIVO

Mantenha um registro enxuto durante a revisão.

Estrutura sugerida:

| ID | Área | Afirmação/Requisito | Evidência | Estado | Problema | Ação |
| -- | ---- | ------------------- | --------- | ------ | -------- | ---- |

Além disso mantenha:

* mapa da arquitetura;
* cobertura de leitura;
* inventário de dados;
* verificações;
* correções;
* testes;
* experimentos;
* decisões;
* pendências.

Evite criar dez relatórios diferentes contendo a mesma informação.

Prefira uma fonte canônica.

---

# 51. COMO TRABALHAR

Não faça uma revisão superficial de tudo em uma passada.

Use ciclos dirigidos por perguntas.

Exemplo:

### Ciclo

1. qual afirmação estamos verificando?
2. qual evidência seria suficiente?
3. onde está o código/dado relevante?
4. qual teste responde à pergunta?
5. qual foi o resultado?
6. a afirmação sobrevive?
7. existe correção necessária?
8. qual teste prova a correção?

Depois avance.

Não faça ciclos de pesquisa ou testes sem pergunta decisiva.

---

# 52. ORDEM GERAL

A sequência inicial deve ser:

1. estado Git;
2. instruções locais;
3. preservação;
4. inventário;
5. arquitetura atual;
6. fluxo atual;
7. capacidades alegadas;
8. matriz de afirmações;
9. inventário de dados;
10. análise de causalidade;
11. metodologia;
12. execução;
13. testes;
14. economia;
15. gaps;
16. correções;
17. reteste;
18. atualização documental;
19. conclusão.

Não comece propondo arquitetura nova.

---

# 53. CRITÉRIO DE CONCLUSÃO — ENGENHARIA

Uma frente de engenharia pode ser chamada de pronta quando:

* comportamento declarado foi confrontado com implementação;
* defeitos críticos foram corrigidos;
* testes pertinentes passam;
* execução é reproduzível;
* documentação corresponde ao estado real;
* limitações importantes estão explícitas.

---

# 54. CRITÉRIO DE CONCLUSÃO — DADOS

Dados podem ser considerados adequados quando:

* campos necessários existem;
* cobertura necessária existe;
* qualidade foi verificada;
* procedência é conhecida;
* identidade está correta;
* temporalidade está correta;
* lacunas que invalidariam o uso foram resolvidas.

Se uma lacuna invalida conclusão:

a frente permanece bloqueada.

---

# 55. CRITÉRIO DE CONCLUSÃO — ECONOMIA

Uma conclusão econômica exige:

* cálculo reproduzível;
* dados adequados;
* temporalidade válida;
* premissas explícitas;
* custos explícitos ou intervalos;
* separação de adaptação e validação;
* capital corretamente tratado;
* risco explicitado;
* nenhum leakage conhecido que invalide resultado.

Aprovação de CI não aprova estratégia econômica.

---

# 56. MATERIAL PARA O DONO E INVESTIDOR

Ao encerrar, prepare uma explicação acessível contendo:

* o que o projeto prometia;
* o que realmente faz;
* o que estava errado;
* o que foi corrigido;
* o que ficou melhor;
* resultados econômicos que sobreviveram;
* perdas encontradas;
* custos conhecidos;
* custos desconhecidos;
* limitações;
* riscos;
* pendências;
* próximos marcos;
* condições de interrupção.

Responda explicitamente:

> Qual descoberta mais mudou a decisão?

> Qual hipótese perdeu mais prioridade?

> Qual informação decidiria o próximo passo?

> Houve melhoria econômica demonstrada?

Se não houve, diga claramente.

---

# 57. RELAÇÃO COM INVESTIDOR

Não envie mensagens.

Prepare material para revisão do dono.

Não:

* prometa lucro;
* esconda perda;
* transforme simulação em resultado real;
* apresente projeção não validada como expectativa;
* apresente erro técnico como detalhe irrelevante.

Positividade significa mostrar progresso verdadeiro.

Não significa suavizar evidência negativa.

---

# 58. DEFINIÇÃO FINAL DE “PRONTO”

Não declare o projeto genericamente pronto.

Classifique cada frente separadamente como:

### PRONTA PARA O USO DECLARADO

### PRONTA COM LIMITAÇÕES QUE NÃO INVALIDAM O USO

### BLOQUEADA POR DEPENDÊNCIA IDENTIFICADA

### ABANDONADA POR EVIDÊNCIA

Uma lacuna que invalida a finalidade impede o rótulo “pronta”.

---

# 59. PERGUNTAS QUE A REVISÃO FINAL DEVE RESPONDER

Ao terminar, quero uma resposta explícita para cada uma:

1. O que o projeto dizia possuir?
2. O que realmente possui?
3. O que dizia fazer?
4. O que realmente faz?
5. O que existe mas não é usado?
6. O que existe mas está errado?
7. O que existia historicamente mas não existe mais?
8. Quais premissas foram comprovadas?
9. Quais foram parcialmente comprovadas?
10. Quais foram contraditas?
11. Quais continuam não verificadas?
12. Quais dados temos?
13. Quais dados faltam?
14. Quais gaps de dados foram resolvidos?
15. Quais não puderam ser resolvidos?
16. O pipeline é causal?
17. Existe leakage?
18. Os backtests são executáveis?
19. Os custos estão corretos?
20. Os resultados econômicos anteriores continuam válidos?
21. Quais componentes devem permanecer?
22. Quais devem ser simplificados?
23. Quais devem ser substituídos?
24. Quais devem ser removidos?
25. Quais P0 ainda existem?
26. Quais P1 ainda existem?
27. O que foi corrigido nesta revisão?
28. O que foi medido antes/depois?
29. O que está pronto?
30. O que ainda impede uso real?

---

# 60. REGRA FINAL

Não entregue somente um diagnóstico.

Não entregue somente um plano.

Não entregue somente código.

Não entregue somente testes.

Faça o ciclo completo possível dentro da autorização:

> DESCOBRIR → COMPROVAR → CORRIGIR → TESTAR → MEDIR → REAVALIAR → DOCUMENTAR → CONCLUIR

Preserve resultados negativos.

Não force conclusão positiva.

Não prometa recuperar dados que podem não existir.

Não invente certeza.

O objetivo desta revisão é deixar o projeto tão próximo quanto tecnicamente possível de um estado em que cada afirmação importante tenha:

* evidência;
* responsável técnico;
* dado correspondente;
* teste correspondente;
* limitação conhecida;
* decisão clara.

---

# 61. PRIMEIRA TAREFA

Comece AGORA pela nova linha de base.

Primeiro:

1. execute os comandos de status Git indicados;
2. leia `AGENTS.md`;
3. leia `CONFIGURACAO_LOCAL.md`;
4. confira branch, HEAD, worktrees e alterações locais;
5. preserve qualquer diff documental;
6. inventarie estrutura de código e testes;
7. identifique os entrypoints reais;
8. reconstrua a arquitetura atual;
9. registre a primeira versão da matriz de afirmações;
10. só então avance para correções.

Não assuma que a preparação anterior tornou o projeto correto.

O ponto desta revisão é justamente verificar isso.
