# Continuidade: revisão de arquitetura, lógica e resultado econômico

Atualizado em 09/09/2026, após a integração das correções do PR #109 e a confirmação dos quatro jobs de CI, incorporando o pedido posterior de revisão completa. Leia primeiro [FECHAMENTO_PENDENCIAS_20260909.md](FECHAMENTO_PENDENCIAS_20260909.md) e sua validação final. Este é o ponto de entrada canônico para o novo chat. Confira o estado real antes de agir; documentos, inclusive este repasse, são afirmações a confrontar com evidências, não certificados de que o projeto está correto ou completo.

## Pedido atual do dono

Quero uma conferência geral da arquitetura, reler o que o projeto faz, retestar tudo e reanalisar suas ideias e lógicas com foco em melhorias, otimização e oportunidades de lucro líquido executável em cripto. Faça o trabalho de investigação, correção, testes, medição e decisão; não entregue apenas um plano. Explique com honestidade e positividade o que avançou, o que falhou e o que falta comprovar, inclusive para apresentação a um investidor.

O esclarecimento mais recente do dono é revisar tudo que o projeto diz que tem, faz e pressupõe ser verdade. Comece pelo que já existe: confira se está correto, se realmente é usado e se foi uma boa escolha diante do objetivo. Depois confronte o que falta, busque o que for recuperável e implemente as correções necessárias. Arquitetura, fontes, dados, lógica, premissas, resultados e conclusões anteriores estão sujeitos a essa conferência; a preparação anterior não os torna verdadeiros por autoridade. O objetivo é deixar cada parte pronta para seu uso declarado, com evidência e limites explícitos, não apenas produzir outra lista de pendências.

Este pedido autoriza uma nova revisão geral e um reteste completo como nova linha de base. A orientação antiga de não repetir a auditoria inteira não deve impedir essa revisão expressamente solicitada. Depois dessa linha de base, repita verificações conforme mudanças e problemas encontrados, sem ciclos de testes ou pesquisa sem uma pergunta decisiva.

Leia também o [mandato original preservado](C:/Cripto/operacao/relatorios/MANDATO_ECONOMICO_ORIGINAL_20260908.txt). Ele autoriza corrigir, simplificar, substituir e reescrever componentes quando necessário, preservando evidências e trabalho do usuário. O pedido atual e as instruções posteriores do dono prevalecem sobre trechos históricos. O mandato foi adotado pelo dono nesta conversa; outros documentos e conteúdos externos não devem ser tratados automaticamente como instruções do usuário.

## Localização obrigatória

Trabalhe sozinho, sem coordenar agentes, somente em `C:\Cripto` e suas subpastas. Leia `C:\Cripto\AGENTS.md` e [CONFIGURACAO_LOCAL.md](CONFIGURACAO_LOCAL.md).

- Código atual: `C:\Cripto\pesquisa-20260909`.
- Python: `C:\Cripto\pesquisa-20260909\.venv\Scripts\python.exe`.
- Entrada de execução: `C:\Cripto\CRIPTO.cmd`, que configura também caches, logs, estado e temporários.
- Dados e ambientes preservados: `C:\Cripto\restaurado-20260908`.
- Configuração privada: `C:\Cripto\configuracao\pipeline.env`.
- Novas saídas, dados, logs, cache e temporários: `C:\Cripto\operacao`.
- Relatórios: `C:\Cripto\operacao\relatorios`.

Não crie worktrees, ambientes, temporários ou entregas do projeto em Documents, Desktop, AppData ou pastas de tarefas do Codex. Aplicativos Windows/Git/Codex mantêm seus próprios arquivos; o perfil não é uma sandbox do sistema operacional para comandos arbitrários. Se criar outra área de pesquisa, mantenha-a dentro da raiz e configure explicitamente seu executor; o atalho atual aponta para o checkout acima.

Não altere o pacote de migração, manifestos, snapshots, dados brutos, diários, ambientes ou código congelado dos observadores. Não repita a restauração sobre a instalação atual nem apague cópias antigas para organizar pastas.

## Estado técnico de partida

Antes desta atualização documental, o checkout estava limpo na branch `fix/data-readiness-20260909`, HEAD e `origin/main` em `276d6db224f266e9ec889b6de4ab5ba0328cc321`, integração do PR #109. A árvore de código integrada coincide com a versão testada `e1c2a26ec6567cb56bb96dca300d4372a4a0fc83`. Este repasse foi editado depois dessa integração: preserve o diff documental local ao começar. Confirme HEAD, base remota, worktrees e alterações atuais; não faça downgrade para um SHA citado em um arquivo antigo.

A validação final anterior registra 1.285 testes locais aprovados, um skip por permissão de symlink no Windows e zero falhas; no CI do PR, 1.286 aprovados com todos os extras. A cobertura no escopo de `coverage-runtime.ini` foi 88,5089%, exibida como 89%. Os quatro jobs do CI após a integração passaram no run `34403156484`. Referência: [VALIDACAO_FINAL.json](C:/Cripto/operacao/relatorios/FECHAMENTO_PENDENCIAS_20260909/VALIDACAO_FINAL.json). Estes são resultados anteriores, não a revalidação solicitada agora, nem taxa de acerto nas previsões ou prova de correção de todas as premissas. Não sobrescreva essa evidência com resultados da nova revisão.

A restauração conferiu o pacote disponível: 66.360 arquivos, com quatro realocações de ambiente documentadas. Os seis arquivos inicialmente citados em `D:` não estão disponíveis. Isso não certifica tudo que existiu no computador anterior nem recupera inputs que já estavam ausentes, incluindo alguns necessários à revalidação exata do DSR histórico da H5.

## Chaves e acesso externo: estado posterior aos relatórios iniciais

A configuração carrega sem erro desde 09/09/2026 às 18:41 UTC. Estão preenchidas `GEMINI_API_KEY`, `SERP_API_KEY`, `GROQ_API_KEY`, `CEREBRAS_API_KEY` e `COINGECKO_API_KEY`. Modo selecionado: Gemini e SerpAPI. O dono confirmou que a chave inicialmente chamada “serapikey” pertence à SerpAPI.

As chaves foram importadas do arquivo local `C:\Cripto\.env.txt`, que contém uma lista anotada e foi preservado. Não o trate como um arquivo dotenv diretamente carregável. Ele contém também GNews e credenciais de Binance. GNews não é NewsAPI.ai e não deve ser mapeada silenciosamente para `NEWSAPIAI_API_KEY`; as credenciais da Binance não foram usadas e não autorizam acesso à conta.

As verificações conectadas posteriores confirmaram geração Gemini e Groq, notícias SerpAPI e resposta de verificação CoinGecko. A geração Cerebras retornou HTTP 402 e permanece indisponível para o uso gratuito verificado. Groq usa agora `openai/gpt-oss-120b`. O dono confirmou planos gratuitos; preserve a recusa de recursos pagos. As chaves opcionais ausentes não impedem Gemini + SerpAPI. As provas atuais estão no documento de fechamento; a importação inicial continua como evidência histórica.

A guarda de API está ligada e recebeu limites finitos em 09/09: 28 unidades de ingestão, 8 tentativas de notícias por provedor e 6 chamadas lógicas de LLM por provedor, por dia UTC, conforme o exemplo documentado em [API_GUARDS.md](API_GUARDS.md). Veja o [comprovante](C:/Cripto/operacao/relatorios/LIMITES_API_20260909T192125822404Z.json). Antes de verificações conectadas, confira recursos gratuitos disponíveis e retries; esses limites não são teto monetário nem certificado das cotas do provedor. Não gere novas despesas nem apague o banco de orçamento para reiniciar cotas. Se a gratuidade não puder ser confirmada, prossiga com verificações locais e fontes públicas utilizáveis, registrando essa dependência.

Não imprima valores, prefixos, hashes de chaves ou conteúdos privados em ferramentas, logs, documentos, commits ou relatórios. Exceções de configuração podem incluir entradas sensíveis: reporte tipos de erro e nomes de campos, não dumps. Não copie chaves para dentro do checkout Git.

## Preparação de dados posterior ao repasse inicial

Leia [PRONTIDAO_DADOS.md](PRONTIDAO_DADOS.md) e [FECHAMENTO_PENDENCIAS_20260909.md](FECHAMENTO_PENDENCIAS_20260909.md). As 48 observações de futuros foram recuperadas em uma nova base, com reconstrução independente do normalizador. As duas bases de altcoins foram verificadas; os 12 intervalos ausentes da retrospectiva não retornaram dados em consultas públicas específicas. A busca ampliada não encontrou o banco antigo. O pipeline produziu mercado, notícias, análises, histórico e cache em `C:\Cripto\operacao`; o teste real também originou correções de chave CoinGecko, candle fechado, volume e identidade do cache. Esses registros são diagnósticos operacionais, não amostra prospectiva independente.

O dono confirmou que só dispõe dos arquivos desta pasta, autorizou buscar dados públicos faltantes e manteve 5.000 USDT como capital hipotético. Não repetir pedidos de outro backup nem de confirmação da gratuidade já dada. Despesas pessoais, custo de desenvolvimento e perda tolerável continuam desconhecidos; isso permite cenários, não valores inventados. Aave permanece estacionada por acesso histórico; a busca de dados não produziu estimativa de rendimento.

Pendências concretas de partida: 542 dias de observações ausentes somados entre 12 pares da retrospectiva de altcoins, além de 200 fechamentos não padrão; banco antigo de previsões e inputs exatos da H5 não encontrados; índices e liquidez históricos necessários ao estudo Aave não obtidos; ausência de observações futuras independentes. Não confunda esses totais com 542 dias consecutivos de calendário, nem some as duas aquisições de altcoins como universos distintos. Os 200 candles do diagnóstico confirmam aquele fluxo e aquele ativo, não a completude de todos os mercados ou períodos.

As tentativas públicas anteriores sem resultado delimitam o que foi consultado, não demonstram que todas as fontes possíveis foram esgotadas. Antes de repetir uma consulta, leia sua resposta preservada e formule uma alternativa com chance concreta de acrescentar evidência. Procure fontes oficiais e alternativas públicas compatíveis com a identidade do ativo, contrato, intervalo e disponibilidade temporal. Verifique documentação atual e limites de acesso antes de usá-las. Registre uma aquisição finita por pergunta; não contorne restrições nem habilite serviços pagos. Se uma fonte substituta tiver metodologia diferente, compare e documente antes de combinar séries.

## Leitura e revisão do funcionamento

Comece por [README principal](../README.md), [índice da documentação](README.md), [estado da pesquisa](CURRENT_RESEARCH_STATE_20260908.md), [handoff anterior](SESSION_HANDOFF_20260908.md), [pesquisa de lucro](PROFIT_RESEARCH.md), [escopo dessa pesquisa](evidence/profit_research_20260908/scope.json), [hipóteses](HYPOTHESES.md), [estado científico](../charters/scientific_state.json) e [resultado da rodada mais recente](evidence/economic_round_20260909/RESULTADOS.md).

[ARQUITETURA_CONSOLIDADA.md](ARQUITETURA_CONSOLIDADA.md) é um retrato histórico com erratas. Use-o como referência e reconstrua a arquitetura atual a partir do código, testes, configurações e entradas reais. Não reutilize notas antigas como avaliação atual.

Faça um inventário da estrutura e registre a cobertura da revisão. Leia os módulos e documentos que determinam o comportamento de todas as frentes ativas; siga o histórico necessário para verificar afirmações e decisões. Não diga que leu todos os arquivos se apenas listou nomes, consultou um resumo ou não examinou partes relevantes.

Mapeie de ponta a ponta: aquisição e normalização de dados → armazenamento, proveniência e tempo de disponibilidade → seleção e sinais/LLMs → validação e backtests → dimensionamento, custos, risco e execução simulada → registros, relatórios e operação. Inclua as relações entre GarimpoInvestimentos, DPL/Feature Store, V3, módulos compartilhados e os novos componentes de pesquisa, conferindo seus nomes atuais no repositório.

Para cada fluxo, explique finalidade, entradas, saídas, dependências, consumidor efetivo e evidência de funcionamento. Procure funções desconectadas, duplicação útil ou desnecessária, custos recorrentes, gargalos, dados desatualizados, falhas silenciosas e divergências entre código e documentação. Apresente um mapa atual compreensível e achados com referências verificáveis. Suspeita é hipótese até ser reproduzida.

## Conferência das afirmações, premissas e escolhas

Mantenha uma matriz de afirmações dentro do registro canônico da revisão. Cada afirmação material deve ter: identificador, origem e versão, significado verificável, componente ou conjunto de dados relacionado, evidência necessária, verificação executada, resultado, impacto e ação. Use estados explícitos: comprovada no escopo testado, parcialmente comprovada, contradita, não verificada ou desatualizada. Um teste passando só comprova o comportamento que ele efetivamente exercitou; uma frase repetida em vários MDs continua sendo uma única alegação sem prova adicional.

Inclua alegações dos READMEs, documentação técnica, configuração, interfaces, relatórios econômicos, material ao investidor e conclusões de auditorias anteriores. Classifique cada funcionalidade como implementada e conectada, implementada sem uso, simulada, planejada, desativada ou histórica. Rastreie as dependências compartilhadas quando determinarem o comportamento; não certifique uma integração examinando apenas seu wrapper. Registre as áreas lidas e verificadas, as verificadas por amostragem e as não examinadas, sem chamar inventário de leitura integral.

Para cada premissa que afeta uma decisão, explicite por que ela seria válida, em que condições falha e qual observação poderia refutá-la. Reexamine, entre outras, a utilidade do score e das notícias/LLMs, causalidade dos sinais, alinhamento temporal, qualidade e continuidade das fontes, disponibilidade histórica, interpretação de custos e retornos, tamanho da amostra, regras de entrada e ausência de operações. Investigue se zero entradas decorre dos dados, de um defeito, de filtros ou da própria hipótese; não afrouxe filtros só para produzir trades.

Avalie se cada escolha importante ainda é adequada ao objetivo, comparando sua contribuição, complexidade, custo, limitações e uma alternativa simples quando pertinente. O projeto existente não precisa ser defendido e também não precisa ser reescrito para demonstrar trabalho. Mantenha, simplifique, substitua ou retire componentes com justificativa e medição; preserve os registros históricos. Restrições expressas do dono, como diretório, gratuidade e ausência de autorização de capital, são condições de trabalho e não premissas que o revisor pode remover.

## Inventário de fontes e dados e resolução das lacunas

Para cada frente de pesquisa e fluxo ativo, liste os dados necessários e compare com os efetivamente encontrados. Registre fonte, endpoint ou arquivo, ativo e identidade do contrato, campo/unidade, frequência, período exigido e disponível, fuso, tempo do evento e momento de disponibilidade, esquema, quantidade, duplicatas, lacunas, valores inválidos, procedência/hashes, caminho bruto e derivado, coletor, consumidor, acesso/cota e evidência de validação. Diferencie chave preenchida, autenticação aceita, endpoint acessível, resposta válida e cobertura suficiente para a pergunta econômica.

Para cada ausência ou defeito, documente o impacto e execute a resolução disponível: recuperação pública, correção do coletor/normalizador, reconstrução a partir do bruto, conciliação com uma fonte alternativa ou mudança justificada do escopo. Grave novas versões e manifeste a proveniência. Não interpole silenciosamente, transforme aproximação em observação, finja disponibilidade histórica de dados obtidos hoje ou misture diagnósticos com avaliação independente. Se o dado continuar inacessível, registre tentativas, dependência externa concreta e quais conclusões ficam impedidas; proponha um caminho executável e seguro para a parte que ainda pode avançar.

As chaves e integrações opcionais devem ser avaliadas por necessidade: liste o que falta, mas não trate contratar todas as fontes como requisito para concluir um fluxo que não depende delas. Dados conhecidos e existentes também precisam de conferência de conteúdo e adequação, além de presença e hash.

## Reteste e melhorias

Execute a suíte completa com os extras exigidos, lint, formatação, tipagem, build, pacote instalado e entradas Windows, usando as configurações reais do projeto e de `.github/workflows/ci.yml`. Diferencie testes sintéticos, testes com dados preservados e verificações reais dos serviços. Informe testes não coletados, skips e dependências ambientais; não use o número antigo de testes como certificado novo.

Use diretórios de saída e temporários novos dentro de `C:\Cripto`. Preserve configurações privadas durante testes e evite que fixtures acionem APIs reais. Algumas verificações de procedência exigem código em estado commitado: revise e preserve alterações locais antes de estabelecer essa base; não enfraqueça o controle para aprovar testes. O Docker local não estava disponível na rodada anterior, mas o container passou no CI; confira a situação atual.

Verifique os componentes que podem invalidar decisões econômicas: causalidade temporal, vazamento de futuro, sobrevivência do universo, disponibilidade real das fontes, splits, contagem de tentativas, unidades, sinais de funding, custos, caixa, principal, posições, margem, liquidez e preços de execução. Confira cálculos materiais por um caminho separado e atribua corretamente a autoria.

Implemente correções demonstradas e melhorias com efeito justificável em confiabilidade, manutenção, custo ou decisão econômica. Meça o antes/depois com casos comparáveis. Não imponha reescrita geral por estética, não retire validações para passar e não crie testes que apenas repitam a implementação. Preserve mecanismos úteis e evidências de resultados ruins.

## Reanálise das ideias e foco econômico

O objetivo é lucro líquido absoluto executável, considerando capital comprometido, perdas possíveis, liquidez, capacidade e manutenção. Não existe obrigação de superar BTC, Selic ou outro benchmark. Os 5.000 USDT são referência hipotética, não saldo ou permissão de capital. Não há lucro real demonstrado nem projeção validada de lucro futuro.

Reavalie criticamente as ideias antigas e outras elegíveis em cripto. Uma revisão conceitual ampla não exige reexecutar indiscriminadamente todas as variantes encerradas. Para reabrir empiricamente uma família fechada, documente a evidência material e um novo protocolo antes de observar os novos resultados; mantenha a original preservada.

Priorize pela pergunta econômica: quem paga, por quê, quanto a execução e os riscos podem consumir, e qual observação mudaria a decisão? Escolha uma hipótese principal e no máximo uma alternativa ativa, conforme o mandato. Registre um orçamento finito de experimentos, variantes e aquisição antes dos resultados. Todos os resultados, inclusive negativos, contam. Não mantenha busca indefinida até encontrar um backtest positivo.

Teste cedo a premissa que pode inviabilizar a oportunidade. Siga até implementação e medição quando houver justificativa. Falha de acesso não prova inexistência de oportunidade; poucos dados não provam inviabilidade. Custos desconhecidos permitem cenários, parciais e pontos de equilíbrio claramente identificados, não lucro líquido final inventado. Não exija ganho em todo estresse como condição oculta; informe perdas e condições de falha sem esconder riscos graves.

Separe simulação e execução real, lucro bruto e resultado após custos, custos de desenvolvimento e despesas recorrentes. Não some cenários independentes financiados pelo mesmo capital, não trate principal como lucro e não iguale USDT/USDC/BRL sem conversão. O gasto total do projeto ainda não foi consolidado; não invente retorno sobre o investimento do dono ou do investidor.

Histórico já consultado permanece pesquisa adaptativa. Avaliação independente exige dados temporais ainda não usados ou futura observação. Não retrodate registros, invente amostra prospectiva ou altere sinais para forçar entradas. Não confunda otimização técnica com criação de lucro.

## Resultados que a nova revisão precisa confrontar

Mesma referência de 5.000 USDT por cenário independente, período longo de 01/01/2024 a 07/09/2026, 980 dias:

- AR1 BTC: +424,25 USDT base e +341,13 adverso; acumulados, não mensais. Contribuição adversa de 2026: somente +5,75 USDT até o corte.
- BR1 BTC: +230,17 base e +110,07 adverso; cinco operações, nenhuma em 2026; intervalo descritivo adverso inclui zero.
- AR2 BTC original: +17,79 base e -82,26 adverso. Reduzir giro na única renovação adjacente melhora hipoteticamente para +23,63 e -65,90. Até o limite otimista ampliado permanece -65,39 no adverso; isso rejeita somente a renovação como correção suficiente nessa referência, não toda possibilidade de carry.
- AR3: perda modelada próxima de 99% no cenário base. BR2: nenhuma entrada. Seletor atual de altcoins: zero operações em 140 semanas.
- Diagnóstico carry dos 84 dias até 08/09/2026: +10,56 base, -6,97 adverso e -21,65 no estresse. Não equivale ao piloto futuro.
- H1 da rodada de 09/09, Aave USDC: inconclusiva por acesso histórico bloqueado, seis chamadas/tentativas em duas fontes. Não foi medido rendimento. Precisa de índices históricos e liquidez de retirada; chaves de LLM não resolvem esse bloqueio.

Provas: [resultados econômicos completos](C:/Cripto/operacao/relatorios/RESULTADOS_ECONOMICOS_20260909.json), [registro canônico](evidence/economic_round_20260909/RESULTADOS.md) e [estado anterior](CURRENT_RESEARCH_STATE_20260908.md). [Resultado geral](C:/Cripto/operacao/relatorios/RESULTADO_GERAL_20260909.md) e [texto ao investidor](C:/Cripto/operacao/relatorios/ATUALIZACAO_INVESTIDOR_20260909.md) foram escritos antes da importação das chaves; essa pendência específica foi superada localmente, sem mudança dos resultados econômicos. Não apresente documentos anteriores como estado atualizado sem conferir datas.

## Observadores, publicação e limites mantidos

Observador de altcoins preservado: `C:\Cripto\restaurado-20260908\sessoes\20260907-altcoins\work\cripto-v1.2`, com dados nas pastas irmãs. Observador de carry: `C:\Cripto\restaurado-20260908\sessoes\20260907-pesquisa\work\cripto-research`, com dados irmãos em `carry-forward-data`. Os dados AR2 ficam em `C:\Cripto\restaurado-20260908\sessoes\20260907-pesquisa\work\carry-research-data`.

Não recrie, migre ou ative automações. Os horários e tarefas citados em registros antigos são históricos; esta revisão não autoriza operação contínua. Coletas públicas pontuais dentro dos recursos disponíveis estão autorizadas. Não envie ordens, assine transações, movimente fundos, use credenciais financeiras, crie contas externas ou contrate serviços. `capital_permission` permanece falso. Não envie mensagens ao investidor; prepare material para o dono revisar.

Branches, commits, PRs e integração de engenharia/pesquisa estão autorizados pelo mandato. Leia [POLITICA_DE_MERGE.md](POLITICA_DE_MERGE.md); revise o diff, valide contra a base atual e aguarde os quatro jobs exigidos: `quality`, `all-extras`, `container` e `python-314-experimental`. Após integrar, confira conteúdo, SHA e checks do estado resultante. Não faça force-push, limpeza destrutiva, sobrescrita de evidência ou divulgação de dados privados. Se a integração segura não for possível, deixe o PR revisável.

## Entrega e começo concreto

Use critérios de conclusão por finalidade. Para engenharia: comportamento declarado confrontado com implementação, defeitos críticos corrigidos, testes pertinentes aprovados e execução reproduzível. Para dados: campos e cobertura necessários à finalidade, qualidade e proveniência verificadas, com lacunas que afetem o resultado resolvidas ou explicitamente impeditivas. Para economia: cálculos reproduzíveis, premissas e custos explícitos e separação entre retrospectiva adaptativa e validação independente. Aprovação técnica não aprova automaticamente dados, estratégia ou operação financeira.

Ao encerrar, classifique cada frente como pronta para o uso declarado, pronta com limitações que não invalidam esse uso, bloqueada por dependência identificada ou abandonada por evidência. Não declare uma frente pronta se a lacuna remanescente invalida sua conclusão. Resolva as pendências executáveis dentro da autorização antes de concluir; tempo futuro, dados inacessíveis e informações privadas desconhecidas devem ficar como dependências concretas, sem promessa de que toda lacuna será recuperável.

Mantenha um registro canônico enxuto da revisão, com mapa da arquitetura real, cobertura de leitura, achados confirmados, correções, testes, experimentos, fontes, decisões e pendências. Salve evidências e entregas dentro de `C:\Cripto`; evite relatórios redundantes. Mostre o que já funciona e o que continua sem validação, sem prometer 100% ou lucro garantido.

Entregue também uma explicação acessível ao dono e ao investidor: avanços comprovados, erros e perdas, custos conhecidos/desconhecidos, resultado econômico compatível com o capital e período, próximos marcos e condições de interrupção. Responda: qual descoberta mais mudou a decisão, qual hipótese perdeu prioridade e qual informação decidiria o próximo passo? Se não houve melhoria econômica demonstrada, diga isso.

Atualize os MDs operacionais e a apresentação do estado atual quando uma alegação for corrigida. Em evidências congeladas, preserve os bytes e publique uma errata vinculada. Inclua uma conclusão explícita sobre o que o projeto prometia, o que realmente faz, quais premissas sobreviveram à revisão, o que foi resolvido e o que impede cada uso restante. O [texto final ao investidor da preparação](C:/Cripto/operacao/relatorios/ATUALIZACAO_INVESTIDOR_20260909_FINAL.md) também deve ser conferido, não copiado como conclusão da nova revisão.

Comece conferindo Git, as instruções locais, o status abaixo e a estrutura de código/testes; faça a nova revisão e a linha de base solicitadas. Não inicie o pipeline conectado antes de conferir cotas gratuitas, aplicação dos limites e exposição de segredos nas integrações.

```powershell
Set-Location -LiteralPath 'C:\Cripto\pesquisa-20260909'
git status --short
git branch --show-current
git rev-parse HEAD
git worktree list
C:\Cripto\CRIPTO.cmd status
```
