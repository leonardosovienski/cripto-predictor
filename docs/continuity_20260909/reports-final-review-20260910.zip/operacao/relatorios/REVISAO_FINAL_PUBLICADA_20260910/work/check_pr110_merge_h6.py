from pathlib import Path
from datetime import datetime, timezone
import importlib.util
import json
import subprocess

P=Path(r'C:\Cripto\pesquisa-20260909')
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\pr110')
state=json.loads((R/'state.json').read_bytes())
spec=importlib.util.spec_from_file_location('freeze_review',P/'scripts/freeze_h6_definition.py')
freeze=importlib.util.module_from_spec(spec)
spec.loader.exec_module(freeze)
frozen=json.loads((P/'charters/h6_definition_frozen.json').read_bytes())
merged_root=R/'merged_governing_code'
merged_file=merged_root/'GarimpoInvestimentos/analyzers/backtest.py'
merged_file.parent.mkdir(parents=True,exist_ok=False)
merged_file.write_bytes(subprocess.check_output(['git','show',state['merge_tree']+':GarimpoInvestimentos/analyzers/backtest.py'],cwd=P))
result={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'merge_tree':state['merge_tree'],'cases':{}}
for label,root in [('main_111',P),('pr110',R/'checkout'),('combined_auto_merge',merged_root)]:
    freeze.ROOT=root
    freeze.BACKTEST_PY=root/'GarimpoInvestimentos/analyzers/backtest.py'
    freeze.TRIALS_JSON=P/'GarimpoInvestimentos/trials.json'
    freeze._git_commit=lambda:label
    snapshot=freeze.build_snapshot()
    result['cases'][label]={
        'governing_code_matches_frozen':snapshot['governing_code_sha256']==frozen['governing_code_sha256'],
        'registered_trial_matches_frozen':snapshot['trials_json_entry_sha256']==frozen['trials_json_entry_sha256'],
    }
(R/'combined_h6_check.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
