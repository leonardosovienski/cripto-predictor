from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
P=Path(r'C:\Cripto\pesquisa-20260909')
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
def git(*args):return subprocess.check_output(['git',*args],cwd=P,text=True,encoding='utf-8').strip()
v=json.loads((R/'final02/validation.json').read_bytes())
differences=[p for p,h in v['source_hashes'].items() if not (P/p).is_file() or hashlib.sha256((P/p).read_bytes()).hexdigest()!=h]
prompt_same=(P/'docs/NEXT_CHAT_PROMPT.md').read_bytes()==(R/'baseline/initial_next_chat_prompt.md').read_bytes()
frozen_changes=git('diff','--name-only','276d6db224f266e9ec889b6de4ab5ba0328cc321','HEAD','--','charters','observation_plans','docs/evidence','GarimpoInvestimentos/trials.json','GarimpoInvestimentos/v3/regime_engine.py','GarimpoInvestimentos/v3/costs.py')
record={'at_utc':datetime.now(timezone.utc).isoformat(),'head':git('rev-parse','HEAD'),'checked_runtime_source_files':len(v['source_hashes']),'changed_since_final02':differences,'owner_prompt_preserved_byte_for_byte':prompt_same,'protected_tracked_paths_diff':frozen_changes,'working_tree_status':git('status','--short'),'test_checks_all_pass':all(c['exit_code']==0 for c in v['checks']),'coverage':json.loads((R/'final02/coverage.json').read_bytes())['totals']}
(R/'release_validation.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record))
assert not differences and prompt_same and not frozen_changes and record['test_checks_all_pass']
