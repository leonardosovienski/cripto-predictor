"""One new documented free public endpoint, two read-only availability calls maximum."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib,json
import httpx

R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')/'aave_1rpc'
R.mkdir(exist_ok=False)
old=json.loads(Path(r'C:\Cripto\pesquisa-20260909\docs\evidence\economic_round_20260909\h1_rpc\005.json').read_bytes())['request']['params']
endpoint='https://public.1rpc.io/arb'
scope={'registered_at_utc':datetime.now(timezone.utc).isoformat(),'purpose':'Test archive availability on one additional official public endpoint. No APY, pool selection or window change. Continue H1 only under a separately recorded bounded measurement if this capability succeeds.','calls_max':2,'retries':0,'timeout_seconds':12,'response_bytes_max':1000000,'methods':['eth_chainId','eth_call'],'endpoint':endpoint,'probe_block':old[-1],'free_service_evidence':'https://www.1rpc.io/ (Public: Free, 200 requests/day); https://docs.1rpc.io/using-the-web3-api/networks (Arbitrum public endpoint)','authentication':False,'orders_or_transactions':False}
(R/'scope.json').write_text(json.dumps(scope,indent=2),encoding='utf-8')
records=[]
with httpx.Client(timeout=12,trust_env=False,follow_redirects=False) as client:
    for method,params in [('eth_chainId',[]),('eth_call',old)]:
        request={'jsonrpc':'2.0','id':len(records)+1,'method':method,'params':params}
        record={'request':request,'at_utc':datetime.now(timezone.utc).isoformat()}
        try:
            with client.stream('POST',endpoint,json=request) as response:
                body=b''
                for chunk in response.iter_bytes():
                    body+=chunk
                    if len(body)>1000000:raise ValueError('response limit')
                record.update(http_status=response.status_code,raw_sha256=hashlib.sha256(body).hexdigest())
                (R/f'{len(records)+1:02}.response').write_bytes(body)
                record['response']=json.loads(body)
        except Exception as exc:record['error_type']=type(exc).__name__
        records.append(record)
        (R/f'{len(records):02}.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
        if method=='eth_chainId' and record.get('response',{}).get('result')!='0xa4b1':break
value=records[-1].get('response',{}).get('result') if len(records)==2 else None
result={'calls':len(records),'archive_index_available':isinstance(value,str) and value.startswith('0x') and len(value)==66 and int(value,16)>0,'historical_liquidity_verified':False,'source':endpoint,'economic_result':None}
(R/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
