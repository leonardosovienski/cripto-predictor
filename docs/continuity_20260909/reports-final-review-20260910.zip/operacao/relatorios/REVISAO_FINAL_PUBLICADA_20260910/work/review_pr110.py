from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import zipfile

P = Path(r'C:\Cripto\pesquisa-20260909')
R = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\pr110')
R.mkdir(exist_ok=False)
C = R / 'checkout'
C.mkdir()
sha = '4ae9e3d19d4dc7c761d353a8eab851d70f0230e3'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=P)

archive = R / 'pr110_git_tree.zip'
subprocess.run(['git', 'archive', '--format=zip', f'--output={archive}', sha], cwd=P, check=True)
with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
        if not (C / info.filename).resolve().is_relative_to(C):
            raise ValueError('Unsafe git tree path')
    z.extractall(C)
record = {
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'pr_head': sha,
    'main_compared': git('rev-parse', 'origin/main').decode().strip(),
    'isolated_snapshot': str(C),
    'owner_prompt_matches_snapshot': (C / 'docs/NEXT_CHAT_PROMPT.md').read_bytes() == (P / 'docs/NEXT_CHAT_PROMPT.md').read_bytes(),
    'changed_files_from_main': git('diff', '--name-only', 'origin/main', sha).decode().splitlines(),
}
merge = subprocess.run(['git', 'merge-tree', '--write-tree', 'origin/main', sha], cwd=P, capture_output=True, text=True)
(R / 'merge_simulation.txt').write_text(merge.stdout + merge.stderr, encoding='utf-8')
record['merge_simulation_exit'] = merge.returncode
record['merge_tree'] = merge.stdout.splitlines()[0]
(R / 'diff_from_main.patch').write_bytes(git('diff', sha, 'origin/main', '--', 'GarimpoInvestimentos', 'tests', 'README.md'))
(R / 'state.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps(record), flush=True)

pack = C / 'docs/continuity_20260909'
manifest = json.loads((pack / 'MANIFEST.json').read_bytes())
print(json.dumps({'manifest_keys': list(manifest), 'archive_keys': list(manifest['archives'][0]), 'entry_example': manifest['archives'][0]['entries'][0]}, ensure_ascii=True), flush=True)
env = os.environ.copy()
for key in list(env):
    if any(word in key.upper() for word in ('API_KEY','AUTH_TOKEN','API_SECRET','SECRET_KEY')):
        env.pop(key, None)
temp = Path(r'C:\Cripto\operacao\temporarios\revisao-pr110')
temp.mkdir(exist_ok=False)
(temp / 'empty.env').write_text('# Synthetic configuration only\n', encoding='utf-8')
env.update(CRIPTO_ENV_FILE=str(temp / 'empty.env'), GEMINI_API_KEY='test-gemini-key-for-unit-tests-only', SERP_API_KEY='test-serp-key-for-unit-tests-only', LLM_PROVIDER='gemini', GEMINI_MODEL='gemini-2.5-flash', PYTHONPATH=str(C), PYTHONIOENCODING='utf-8', PREDICTOR_EVENTS_PATH=str(temp / 'events.jsonl'), PREDICTOR_OPS_STATE_DIR=str(temp / 'state'))
for key in ('DATA','OUTPUT','CACHE','LOGS'):
    env[key + '_DIR'] = env['GARIMPO_' + key + '_DIR'] = str(temp / key.lower())

def run(label, args):
    result = subprocess.run(args, cwd=C, env=env, capture_output=True, text=True, encoding='utf-8', errors='replace')
    (R / (label + '.log')).write_text(result.stdout + result.stderr, encoding='utf-8')
    record = {'label': label, 'returncode': result.returncode, 'command': args, 'cwd': str(C), 'real_credentials_available': False}
    (R / (label + '.json')).write_text(json.dumps(record, indent=2), encoding='utf-8')
    print(json.dumps(record), flush=True)
    return result

run('verify_published_archives', [sys.executable, '-B', str(pack / 'restore_archives.py')])
run('targeted_head_tests', [sys.executable, '-B', '-m', 'pytest', '-q', '-ra', '--basetemp', str(temp / 'pytest'), '--junitxml', str(R / 'targeted.xml'), 'tests/test_dpl_stocks.py', 'tests/test_h6_power_context.py', 'tests/test_store_history.py', 'tests/test_review_data_contracts.py', 'tests/test_review_input_snapshots.py', 'tests/test_review_failure_boundaries.py', 'tests/test_run_redoma.py'])
