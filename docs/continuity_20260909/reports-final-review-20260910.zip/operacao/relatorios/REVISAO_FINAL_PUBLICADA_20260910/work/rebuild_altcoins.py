"""Second implementation: reconstruct every saved normalized altcoin row from raw responses."""
from collections import defaultdict
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import urlparse,parse_qs
import csv,gzip,hashlib,io,json,zipfile

R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
ROOT=Path(r'C:\Cripto\restaurado-20260908\sessoes\20260907-altcoins\work')
DAY=86400000
def ms(x):
    n=int(x)
    return n//1000 if n>=100_000_000_000_000 else n
def normalize(r):return [ms(r[0]),float(r[1]),float(r[2]),float(r[3]),float(r[4]),float(r[5]),float(r[7]),ms(r[6])]
results=[]
for name in ('altcoin-data','altcoin-retro-data'):
    root=ROOT/name
    report={'dataset':name,'raw_verified':0,'pairs':[],'conflicts':[],'hash_errors':[],'metadata_other_sources':0}
    sources=defaultdict(dict)
    for path in sorted((root/'raw').glob('*.json')):
        meta=json.loads(path.read_bytes())
        body=gzip.decompress(path.with_suffix('.bin.gz').read_bytes())
        if hashlib.sha256(body).hexdigest()!=meta['sha256']:report['hash_errors'].append(path.name)
        report['raw_verified']+=1
        url=urlparse(meta['url'])
        rows=[]
        if url.path=='/api/v3/klines':
            symbol=parse_qs(url.query)['symbol'][0]
            kind='REST'
            rows=json.loads(body)
        elif url.path.endswith('.zip') and '/spot/monthly/klines/' in url.path and '/1d/' in url.path:
            symbol=url.path.split('/klines/')[1].split('/')[0]
            kind='ARCHIVE'
            with zipfile.ZipFile(io.BytesIO(body)) as z:
                for member in z.namelist():
                    rows.extend(r for r in csv.reader(io.StringIO(z.read(member).decode())) if r and r[0].isdigit())
        else:
            report['metadata_other_sources']+=1
            continue
        if not isinstance(rows,list):continue
        for raw in rows:
            row=normalize(raw)
            old=sources[symbol,kind].get(row[0])
            if old is not None and old!=row:report['conflicts'].append({'symbol':symbol,'kind':kind,'open_ms':row[0]})
            sources[symbol,kind][row[0]]=row
    acquisition=json.loads((root/'acquisition.json').read_bytes())
    metas={p['symbol']:p for p in acquisition['pairs']}
    for file in sorted((root/'pairs').glob('*.json.gz')):
        data=json.loads(gzip.decompress(file.read_bytes()))
        meta=data['metadata']; rows=data['rows']; symbol=meta['symbol']; kind=meta['source']
        raw=sources[symbol,kind]
        missing=[]; different=[]
        for row in rows:
            if row[0] not in raw:missing.append(row[0])
            elif row!=raw[row[0]]:different.append(row[0])
        times=[r[0] for r in rows]
        gaps=[[a+DAY,b-DAY,(b-a)//DAY-1] for a,b in zip(times,times[1:]) if b-a>DAY]
        expected=metas[symbol].get('normalized_sha256')
        normalized_hash=hashlib.sha256(file.read_bytes()).hexdigest()
        report['pairs'].append({'symbol':symbol,'source':kind,'rows':len(rows),'raw_rows_reconstructed':len(raw),'missing_raw_rows':missing,'different_rows':different,'normalized_hash_matches':None if expected is None else expected==normalized_hash,'duplicates':len(times)-len(set(times)),'gaps':gaps,'nonstandard_close_rows':sum(r[7]!=r[0]+DAY-1 for r in rows),'first':min(times) if times else None,'last':max(times) if times else None})
    report['summary']={'pairs':len(report['pairs']),'rows':sum(p['rows'] for p in report['pairs']),'missing_raw_rows':sum(len(p['missing_raw_rows']) for p in report['pairs']),'different_rows':sum(len(p['different_rows']) for p in report['pairs']),'gap_days':sum(g[2] for p in report['pairs'] for g in p['gaps']),'nonstandard_close_rows':sum(p['nonstandard_close_rows'] for p in report['pairs']),'hash_errors':len(report['hash_errors']),'conflicting_raw_keys':len(report['conflicts'])}
    results.append(report)
    print(json.dumps({'dataset':name,**report['summary']}),flush=True)
(R/'altcoin_full_reconstruction.json').write_text(json.dumps({'at_utc':datetime.now(timezone.utc).isoformat(),'datasets':results,'scope':'Every saved normalized row compared with separately parsed raw REST/archive data, same assistant and original sources; no claim of complete historical universe or independent economic sample.'},indent=2),encoding='utf-8')
