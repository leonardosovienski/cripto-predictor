from pathlib import Path
from collections import Counter
from datetime import datetime, timezone, timedelta
import ast
import asyncio
import importlib.metadata
import json
import os
import sqlite3
import subprocess
import sys

P = Path(r"C:\Cripto\pesquisa-20260909")
R = Path(r"C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909")
T = Path(r"C:\Cripto\operacao\temporarios\revisao-inspecao")
T.mkdir(parents=True, exist_ok=True)
os.environ.update(CRIPTO_ENV_FILE=str(T/'empty.env'), GEMINI_API_KEY='test-gemini-key-for-unit-tests-only', SERP_API_KEY='test-serp-key-for-unit-tests-only', DATA_DIR=str(T/'data'), OUTPUT_DIR=str(T/'output'), CACHE_DIR=str(T/'cache'), LOGS_DIR=str(T/'logs'), PREDICTOR_EVENTS_PATH=str(T/'events.jsonl'))
for k in ('DATA','OUTPUT','CACHE','LOGS'): os.environ['GARIMPO_'+k+'_DIR'] = os.environ[k+'_DIR']
sys.path.insert(0, str(P))
tracked = subprocess.check_output(['git','ls-files'], cwd=P, text=True).splitlines()
inventory = {'at_utc':datetime.now(timezone.utc).isoformat(), 'tracked_count':len(tracked), 'by_top_directory':dict(Counter(p.split('/')[0] if '/' in p else '(root)' for p in tracked)), 'by_extension':dict(Counter(Path(p).suffix for p in tracked)), 'python':[], 'artifacts':[]}
for name in tracked:
    path=P/name
    if path.suffix == '.py' and not name.startswith('docs/source_archive'):
        source=path.read_text(encoding='utf-8-sig')
        try: tree=ast.parse(source)
        except SyntaxError: continue
        imports=[]
        for node in ast.walk(tree):
            if isinstance(node, ast.Import): imports.extend(x.name for x in node.names)
            if isinstance(node, ast.ImportFrom): imports.append(node.module or '')
        inventory['python'].append({'path':name,'lines':len(source.splitlines()),'imports':sorted(set(imports)),'functions':[n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]})
    if path.suffix in ('.ipynb','.pkl','.onnx','.pt','.db','.sqlite','.sqlite3'):
        inventory['artifacts'].append(name)
inventory['shared_distributions']={}
for name in ('predictor-core','predictor-ops'):
    d=importlib.metadata.distribution(name)
    inventory['shared_distributions'][name]={'version':d.version,'root':str(d.locate_file('')),'files': [str(f) for f in d.files or [] if str(f).endswith('.py')]}
(R/'inventory.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
db=Path(r'C:\Cripto\operacao\saidas\feature_store.db')
con=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True)
con.row_factory=sqlite3.Row
tables=[r[0] for r in con.execute("select name from sqlite_master where type='table' order by name")]
data={'path':str(db),'tables':{},'quick_check':con.execute('pragma quick_check').fetchone()[0]}
for name in tables:
    safe='"'+name.replace('"','""')+'"'
    data['tables'][name]={'rows':con.execute('select count(*) from '+safe).fetchone()[0],'schema':[dict(r) for r in con.execute('pragma table_info('+safe+')')]}
data['market_series']=[dict(r) for r in con.execute('select source,symbol,interval,count(*) n,min(ts) first,max(ts) last,min(published_at) first_published,max(published_at) last_published from raw_market_data group by source,symbol,interval')]
data['features']=[dict(r) for r in con.execute('select symbol,interval,feature_version,count(distinct ts) observations,min(ts) first,max(ts) last from features_aligned group by symbol,interval,feature_version')]
data['predictions']=[dict(r) for r in con.execute('select ativo,ts,score,price_usd,juiz,fonte,llm_fallback,input_degradado,news_provider from predictions order by ts')]
data['has_prediction_inputs']='prediction_inputs' in tables
con.close()
(R/'operational_store_inventory.json').write_text(json.dumps(data,indent=2),encoding='utf-8')

from GarimpoInvestimentos.dpl.contracts import MarketDataPoint
from GarimpoInvestimentos.dpl.feature_engineering import derive_features
from GarimpoInvestimentos.dpl.feature_store import FeatureStore
from GarimpoInvestimentos.core.history import to_prediction_rows
from GarimpoInvestimentos.dpl.providers import coingecko
start=datetime(2026,1,1,tzinfo=timezone.utc)
points=[MarketDataPoint(symbol='bitcoin',timestamp=start+timedelta(days=i*2),published_at=start+timedelta(days=i*2+1),open=100+i,high=100+i,low=100+i,close=100+i,volume=2,source='binance',interval='1d') for i in range(8)]
feats=derive_features(points)
with FeatureStore(T/'witness.db') as store:
    store.write_features('bitcoin','1d',[{'ts':points[-1].timestamp,**feats}])
    stale=store.latest_features('bitcoin','1d')
    stale_age=(datetime.now(timezone.utc)-stale['ts']).days
probe={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip(),
       'gap_series':{'observed_rows':8,'calendar_span_days':14,'change_7d_returned':feats.get('change_7d'),'true_7_day_close_available':False},
       'stale_serving':{'returned':bool(stale),'age_days':stale_age},
       'prediction_fields':list(to_prediction_rows([{'ativo':'bitcoin','data':'2026-09-09 21:00:00','market_timestamp':'2026-09-08T00:00:00+00:00','input_fingerprint':'public-input-digest','news_titles':['Synthetic headline']}])[0]),
       'tests_synthetic':True,'network_requests':0}
class Resp:
    def raise_for_status(self): pass
    def json(self): return [[int(start.timestamp()*1000),100,100,100,100],[int((start+timedelta(minutes=30)).timestamp()*1000),101,101,101,101]]
class Client:
    async def __aenter__(self): return self
    async def __aexit__(self,*args): pass
    async def get(self,*args,**kwargs): return Resp()
coingecko.get_http_client=lambda:Client()
rows=asyncio.run(coingecko.CoinGeckoProvider(api_key='')._fetch_intraday('bitcoin','bitcoin','1h',2))
probe['coingecko_intraday']={'requested':'1h','returned_labels':[r.interval for r in rows],'actual_spacing_minutes':(rows[1].timestamp-rows[0].timestamp).total_seconds()/60}
(R/'baseline_defect_witnesses.json').write_text(json.dumps(probe,indent=2),encoding='utf-8')
print(json.dumps({'tracked_count':len(tracked),'python_files':len(inventory['python']),'db_tables':len(tables),'market_series':data['market_series'],'probes':probe},indent=2))
