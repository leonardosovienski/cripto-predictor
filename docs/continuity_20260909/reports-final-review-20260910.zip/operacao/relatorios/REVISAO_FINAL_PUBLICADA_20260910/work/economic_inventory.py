from pathlib import Path
import gzip,json
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
B=Path(r'C:\Cripto\restaurado-20260908\sessoes\20260907-pesquisa\work')
A=Path(r'C:\Cripto\restaurado-20260908\sessoes\20260907-altcoins\work')
def read(p):return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
for p in [B/'basis-results-v2/BR2_CONVERGENCE_BTC/plan.json.gz',B/'absolute-results-v3/results.json',A/'altcoin-retro-results/scores.json.gz']:
    data=read(p)
    print(str(p), list(data)[:25] if isinstance(data,dict) else {'n':len(data),'first':data[0]})
    if p.name=='plan.json.gz':
        (R/'br2_plan_review.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
        print({k:v for k,v in data.items() if k!='decisions'})
print('training_paths', [str(p) for p in (A/'altcoin-retro-package').rglob('samples_identity_corrected.json.gz')])
from collections import Counter
data=read(B/'basis-results-v2/BR2_CONVERGENCE_BTC/plan.json.gz')
print('BR2',len(data['decisions']),data['decisions'][:2])
data=read(B/'absolute-results-v3/results.json')
print('CARRY',type(data['carry']),str(data['carry'])[:3200])
print('SPOT',str(data['spot'])[:1700])
