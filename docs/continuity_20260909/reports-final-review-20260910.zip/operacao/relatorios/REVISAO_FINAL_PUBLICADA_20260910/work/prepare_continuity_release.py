"""Create a derived publication; originals and the live API budget are read-only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, sqlite3, zipfile
from dotenv import dotenv_values

W=Path(r'C:\Cripto\correcao-pr110-20260910')
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
F=R/'closure110'
F.mkdir(exist_ok=True)
pack=W/'docs/continuity_20260909'
spec=importlib.util.spec_from_file_location('restore',pack/'restore_archives.py')
restore=importlib.util.module_from_spec(spec)
spec.loader.exec_module(restore)
original=json.loads((pack/'MANIFEST.json').read_bytes())
(F/'original_manifest.json').write_text(json.dumps(original,indent=2),encoding='utf-8')
manifest=json.loads(json.dumps(original))
old=next(a for a in manifest['archives'] if a['file']=='data-operacao.zip')
source=pack/old['file']
assert hashlib.sha256(source.read_bytes()).hexdigest()==old['sha256']
new=pack/'data-operacao-v2.zip'
removed=[]
entries=[]
with zipfile.ZipFile(source) as src,zipfile.ZipFile(new,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as dst:
    for entry in old['entries']:
        if restore.excluded_operational_path(entry['path']):
            removed.append(entry['path'])
            continue
        data=src.read(entry['path'])
        assert hashlib.sha256(data).hexdigest()==entry['sha256']
        dst.writestr(src.getinfo(entry['path']),data)
        entries.append(entry)
old.update(file=new.name,sha256=hashlib.sha256(new.read_bytes()).hexdigest(),bytes=new.stat().st_size,files=len(entries),entries=entries,derived_from={'file':source.name,'commit':'4ae9e3d19d4dc7c761d353a8eab851d70f0230e3','reason':'Remove transient API-budget sidecars; all retained payloads unchanged'})
# Preserve exact original outside the new working tree; history also retains it.
preserved=F/'original-data-operacao.zip'
with preserved.open('xb') as h:h.write(source.read_bytes())
assert source.resolve().is_relative_to(W.resolve())
source.unlink()
for path in removed:
    manifest['excluded'].append({'path':path,'reason':'Transient SQLite sidecar; never publish or restore API budgets'})

values=dotenv_values(r'C:\Cripto\configuracao\pipeline.env')
secrets=[v for k,v in values.items() if v and len(v)>=8 and any(x in k.upper() for x in ('API_KEY','SECRET','TOKEN','PASSWORD'))]
selected=[]
for folder in ('final02','postmerge01','live','aave_1rpc','altcoin_selector_audit','ar2_renewals'):
    selected.extend(p for p in (R/folder).rglob('*') if p.is_file() and p.suffix in {'.md','.json','.log','.xml','.response'} and not {'dist','previous_dist'} & set(p.parts))
selected.extend(p for p in R.glob('*') if p.suffix in {'.json','.md'})
selected.extend(p for p in (R/'pr110').glob('*') if p.suffix in {'.json','.log','.txt','.patch','.xml'})
selected.extend(p for p in (F/'aave_drpc').glob('*') if p.is_file())
selected.extend(p for p in (R/'work').glob('*.py'))
delta=pack/'reports-final-review-20260910.zip'
delta_entries=[]
prefix='operacao/relatorios/REVISAO_FINAL_PUBLICADA_20260910'
with zipfile.ZipFile(delta,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(set(selected)):
        rel=p.relative_to(R).as_posix()
        data=p.read_bytes()
        redacted=False
        for secret in secrets:
            if secret.encode() in data:
                data=data.replace(secret.encode(),b'[REDACTED]')
                redacted=True
        path=prefix+'/'+rel
        z.writestr(path,data)
        delta_entries.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'redacted':redacted})
manifest['archives'].append({'file':delta.name,'sha256':hashlib.sha256(delta.read_bytes()).hexdigest(),'bytes':delta.stat().st_size,'files':len(delta_entries),'original_directory':str(R),'entries':delta_entries,'purpose':'Completed PR111 validation, full review, PR110 findings and latest bounded dependency probe; capture before current PR integration'})

db=F/'diagnostic-final.db'
with sqlite3.connect(Path(r'C:\Cripto\operacao\saidas\feature_store.db').as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect(db) as dst:
    src.backup(dst)
    assert dst.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    counts={name:dst.execute('SELECT COUNT(*) FROM '+name).fetchone()[0] for name in ('predictions','market_snapshots','prediction_inputs')}
data=db.read_bytes()
assert not any(v.encode() in data for v in secrets)
db_archive=pack/'operational-diagnostic-final-20260910.zip'
db_path='operacao/diagnosticos-preservados/20260910/feature_store.db'
with zipfile.ZipFile(db_archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:z.writestr(db_path,data)
manifest['archives'].append({'file':db_archive.name,'sha256':hashlib.sha256(db_archive.read_bytes()).hexdigest(),'bytes':db_archive.stat().st_size,'files':1,'original_directory':r'C:\Cripto\operacao\saidas','entries':[{'path':db_path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'redacted':False}],'sqlite_backup':{'consistent':True,'integrity':'ok','counts':counts},'purpose':'Isolated final diagnostic copy; never overlaid on the operational database'})
manifest['updated_at_utc']=datetime.now(timezone.utc).isoformat()
manifest['validated_engineering_base']='909724e36d23b1683268c9e43d533f553c7dfe5f'
manifest['original_capture_preserved_in_commit']='4ae9e3d19d4dc7c761d353a8eab851d70f0230e3'
manifest['scope']='Versioned continuity package: original historical captures plus completed review evidence; corrected runtime inherited from PR111.'
(pack/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
result={'at_utc':manifest['updated_at_utc'],'archives':len(manifest['archives']),'files':sum(len(a['entries']) for a in manifest['archives']),'archive_bytes':sum(a['bytes'] for a in manifest['archives']),'removed_transient_paths':removed,'original_archive_preserved':str(preserved),'current_diagnostic_counts':counts,'supplement_files':len(delta_entries),'budget_modified':False}
(F/'publication_build.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
