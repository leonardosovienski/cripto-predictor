from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,sys,zipfile
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\pr110')
pack=R/'checkout/docs/continuity_20260909'
script=pack/'restore_archives.py'
cases=[]
def run(label,script_path,args):
    r=subprocess.run([sys.executable,'-B',str(script_path),*args],capture_output=True,text=True,encoding='utf-8',errors='replace')
    (R/(label+'.log')).write_text(r.stdout+r.stderr,encoding='utf-8')
    return r
out=R/'recovery_sample'
args=['--archive','operational-diagnostics.zip','--archive','data-20260907-altcoins-public-sources.zip','--output',str(out)]
for label in ('recovery_first','recovery_idempotent'):
    r=run(label,script,args)
    cases.append({'name':label,'exit_code':r.returncode,'pass':r.returncode==0})

manifest=json.loads((pack/'MANIFEST.json').read_bytes())
selected=next(a for a in manifest['archives'] if a['file']=='operational-diagnostics.zip')
entry=selected['entries'][-1]
conflict=R/'recovery_conflict'
target=conflict/entry['path']
target.parent.mkdir(parents=True,exist_ok=False)
target.write_bytes(b'owner-file-must-survive')
r=run('recovery_conflict',script,['--archive',selected['file'],'--output',str(conflict)])
cases.append({'name':'different_existing_file_rejected_before_any_write','exit_code':r.returncode,'pass':r.returncode!=0 and target.read_bytes()==b'owner-file-must-survive' and sum(p.is_file() for p in conflict.rglob('*'))==1})

synthetic=R/'unsafe_pack'
synthetic.mkdir()
shutil.copy2(script,synthetic/'restore_archives.py')
payload=b'public synthetic safety probe'
archive=synthetic/'unsafe.zip'
with zipfile.ZipFile(archive,'w') as z:z.writestr('../escape.txt',payload)
m={'archives':[{'file':'unsafe.zip','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'entries':[{'path':'../escape.txt','bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}]}]}
(synthetic/'MANIFEST.json').write_text(json.dumps(m),encoding='utf-8')
r=run('recovery_traversal',synthetic/'restore_archives.py',['--output',str(R/'unsafe_output')])
cases.append({'name':'traversal_rejected','exit_code':r.returncode,'pass':r.returncode!=0 and not (R/'escape.txt').exists() and not (R/'unsafe_output').exists()})
result={'at_utc':datetime.now(timezone.utc).isoformat(),'cases':cases,'all_passed':all(c['pass'] for c in cases),'originals_modified':False}
(R/'recovery_probes.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
assert result['all_passed']
