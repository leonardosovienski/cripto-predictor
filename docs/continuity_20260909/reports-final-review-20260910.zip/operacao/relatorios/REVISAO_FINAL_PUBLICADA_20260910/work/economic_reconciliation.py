from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal as D
from collections import Counter
import gzip,json,hashlib
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
B=Path(r'C:\Cripto\restaurado-20260908\sessoes\20260907-pesquisa\work')
A=Path(r'C:\Cripto\restaurado-20260908\sessoes\20260907-altcoins\work')
def read(p):return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
absolute=read(B/'absolute-results-v3/results.json')
basis=read(B/'basis-results-v2/results.json')
rows=[]
for strategy, result in absolute['carry'].items():
    for scenario,s in result['scenarios'].items():
        cash=D(str(s['funding_usdt']))+D(str(s['basis_pnl_usdt']))-sum(D(str(s[k])) for k in ['fees_slippage_usdt','residual_cost_usdt','unhedged_shock_usdt'])
        reported=D(str(s['profit_usdt_mechanical']))
        assert abs(cash-reported)<D('0.00000001')
        rows.append({'strategy':strategy,'scenario':scenario,'capital':5000,'days':980,'reported_profit':str(reported),'reconciled_cashflows':str(cash),'additional_annual_cost_break_even_if_positive':str(cash*D(365)/D(980)) if cash>0 else None,'hedges':s['round_trip_hedges'],'active_days':s['active_days'],'by_year':s['by_year'],'margin_breach':s['first_conservative_margin_breach'],'bootstrap':s['bootstrap'],'concentration':s['concentration']})
plan=read(B/'basis-results-v2/BR2_CONVERGENCE_BTC/plan.json.gz')
decisions=plan['decisions']; vals=[D(str(x['basis'])) for x in decisions if x.get('basis') is not None]
scores=read(A/'altcoin-retro-results/scores.json.gz')
zero={'BR2':{'decisions':len(decisions),'reasons':dict(Counter(x['reason'] for x in decisions)),'finite_basis_observations':len(vals),'max_basis':str(max(vals)),'entry_gate':'0.0075','entries':len(plan['spells'])},'altcoin_selector':{'observations':len(scores),'statuses':dict(Counter(x['status'] for x in scores)),'positive_neighbor_mean':sum(x.get('mean_log_payoff',0)>0 for x in scores),'qualified':sum(x['qualified'] for x in scores),'score_range':[min(x['score_log'] for x in scores if x.get('score_log') is not None),max(x['score_log'] for x in scores if x.get('score_log') is not None)]}}
payload={'at_utc':datetime.now(timezone.utc).isoformat(),'scope':'Separate arithmetic reconciliation of original cashflow totals; raw/ledger independent checks in companion auditors. Historical adaptive scenarios, not realized investor income. Scenarios are not additive.','capital_permission':False,'carry':rows,'basis_results':basis,'AR3':absolute['spot'],'zero_operations':zero,'sources':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [B/'absolute-results-v3/results.json',B/'basis-results-v2/results.json',B/'basis-results-v2/BR2_CONVERGENCE_BTC/plan.json.gz',A/'altcoin-retro-results/scores.json.gz']}}
(R/'economic_reconciliation.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
print(json.dumps(zero));print('basis_top_keys',list(basis))
for s in rows:
    if s['strategy']=='AR1_BTCUSDT':print(s['scenario'],s['reported_profit'],s['by_year'].get('2026'))
