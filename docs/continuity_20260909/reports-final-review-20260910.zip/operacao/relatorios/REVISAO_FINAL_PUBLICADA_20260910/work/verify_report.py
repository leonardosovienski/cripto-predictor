from pathlib import Path
from datetime import datetime, timezone
import json
import re

root = Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
report = root / 'REVISAO.md'
text = report.read_text(encoding='utf-8')
links = re.findall(r'\[[^\]]+\]\(([^)]+)\)', text)
local_links = [p for p in links if not p.startswith(('https://', 'http://', '#'))]
missing = [p for p in local_links if not (Path(p) if Path(p).is_absolute() else root / p).exists()]
placeholders = re.findall(r'@[A-Z_]+@', text)
record = {
    'checked_at_utc': datetime.now(timezone.utc).isoformat(),
    'report': str(report),
    'local_links_checked': len(local_links),
    'missing_local_links': missing,
    'unexpanded_placeholders': placeholders,
    'sections': re.findall(r'^## (.+)$', text, re.MULTILINE),
    'postmerge_tests': next(line for line in reversed((root / 'postmerge01/tests.log').read_text(encoding='utf-8').splitlines()) if 'passed' in line and ' in ' in line),
}
(root / 'report_verification.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(record, ensure_ascii=False))
assert not missing and not placeholders and len(record['sections']) == 11
