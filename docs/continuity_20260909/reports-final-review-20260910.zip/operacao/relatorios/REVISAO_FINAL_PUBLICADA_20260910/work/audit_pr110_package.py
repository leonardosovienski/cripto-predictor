from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import difflib
import gzip
import hashlib
import io
import json
import sqlite3
import zipfile
from dotenv import dotenv_values

R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\pr110')
C=R/'checkout'
P=Path(r'C:\Cripto\pesquisa-20260909')
pack=C/'docs/continuity_20260909'
m=json.loads((pack/'MANIFEST.json').read_bytes())
configured=dotenv_values(r'C:\Cripto\configuracao\pipeline.env')
needles=[v.encode() for k,v in configured.items() if v and len(v)>=8 and any(x in k.upper() for x in ('API_KEY','SECRET','TOKEN','PASSWORD'))]
matches=[]
members={}
collisions=[]
decoded_counts=Counter()
decode_errors=[]
decoded_bytes=0
raw_hash_failures=[]
raw_source_comparisons=0
missing_sources=[]
report_names=[]
db_record=None

def check_bytes(data, label, depth=0):
    global decoded_bytes
    decoded_counts['buffers']+=1
    decoded_bytes+=len(data)
    if any(value in data for value in needles):
        matches.append(label)
    if data.startswith(b'\x1f\x8b'):
        try:
            inner=gzip.decompress(data)
        except (OSError,EOFError):
            decode_errors.append({'path':label,'type':'gzip'})
        else:
            decoded_counts['gzip']+=1
            check_bytes(inner,label+'::gzip',depth+1)
    elif data.startswith(b'PK\x03\x04') and depth<4:
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                for info in z.infolist():
                    if not info.is_dir():
                        check_bytes(z.read(info),label+'::'+info.filename,depth+1)
            decoded_counts['nested_zip']+=1
        except zipfile.BadZipFile:
            decode_errors.append({'path':label,'type':'zip'})

for arc in m['archives']:
    with zipfile.ZipFile(pack/arc['file']) as z:
        for e in arc['entries']:
            path=e['path']
            norm=path.casefold()
            if norm in members and members[norm]['sha256']!=e['sha256']:
                collisions.append({'path':path,'archives':[members[norm]['archive'],arc['file']]})
            members[norm]={'archive':arc['file'],'sha256':e['sha256']}
            data=z.read(path)
            check_bytes(data,arc['file']+'::'+path)
            if arc['file'].startswith('data-'):
                original=Path(r'C:\Cripto')/path
                if original.exists():
                    raw_source_comparisons+=1
                    if hashlib.sha256(original.read_bytes()).hexdigest()!=e['sha256']:
                        raw_hash_failures.append(path)
                else:
                    missing_sources.append(path)
            if arc['file']=='reports-revisao_completa_20260909.zip':
                report_names.append(path)
            if arc['file']=='operational-diagnostics.zip' and path.endswith('feature_store.db'):
                db=R/'published_store.db'
                with db.open('xb') as f:f.write(data)
                with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True) as con:
                    tables=[r[0] for r in con.execute("select name from sqlite_master where type='table'")]
                    db_record={'integrity':con.execute('pragma integrity_check').fetchone()[0], 'counts':{t:con.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t in ('predictions','market_snapshots','prediction_inputs') if t in tables}}
for p in pack.rglob('*'):
    if p.is_file() and p.suffix!='.zip':check_bytes(p.read_bytes(),p.relative_to(C).as_posix())
a=(C/'docs/NEXT_CHAT_PROMPT.md').read_text(encoding='utf-8-sig')
b=(P/'docs/NEXT_CHAT_PROMPT.md').read_text(encoding='utf-8-sig')
result={
 'at_utc':datetime.now(timezone.utc).isoformat(),
 'archives':len(m['archives']),'members':sum(len(a['entries']) for a in m['archives']),
 'cross_archive_conflicting_paths':collisions,'known_configured_secret_matches':len(matches),'matching_locations_only':matches,
 'secret_values_or_fingerprints_persisted':False,'unknown_secret_safety_certified':False,
 'decoded_buffers':dict(decoded_counts),'decoded_bytes_checked':decoded_bytes,'decode_errors':decode_errors,
 'data_source_comparisons':raw_source_comparisons,'data_source_hash_mismatches':raw_hash_failures,'data_source_paths_not_found':missing_sources,
 'published_db':db_record,
 'owner_prompt_equal_normalized_newlines':a==b,
 'captured_review_files':report_names,
 'final_review_missing_from_capture':[n for n in ('REVISAO.md','integration.json','final02/validation.json','postmerge01/validation.json','live/result.json') if not any(p.endswith('/'+n) for p in report_names)],
}
(R/'package_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
if a!=b:(R/'prompt_text_diff.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='pr110',tofile='owner-current')),encoding='utf-8')
small={k:v for k,v in result.items() if k not in ('captured_review_files','data_source_paths_not_found','matching_locations_only')}
small['captured_review_files']=len(report_names)
small['data_source_paths_not_found']=len(missing_sources)
print(json.dumps(small),flush=True)
