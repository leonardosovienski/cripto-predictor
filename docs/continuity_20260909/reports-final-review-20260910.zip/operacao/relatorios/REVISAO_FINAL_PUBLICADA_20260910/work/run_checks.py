"""Isolated, secret-free evidence runner for the 2026-09-09 review."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
import platform
import re
import shutil
import subprocess
import sys

PROJECT = Path(r"C:\Cripto\pesquisa-20260909")
REVIEW = Path(r"C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909")
PHASE = sys.argv[1] if len(sys.argv) > 1 else "baseline"
RUN = REVIEW / PHASE
RUN.mkdir(parents=True, exist_ok=False)
TEMP = Path(r"C:\Cripto\operacao\temporarios") / ("revisao-" + PHASE)
TEMP.mkdir(parents=True, exist_ok=False)
ENV = os.environ.copy()
for key in list(ENV):
    if any(word in key.upper() for word in ("API_KEY", "AUTH_TOKEN", "API_SECRET", "SECRET_KEY")):
        ENV.pop(key, None)
ENV.update({
    "CRIPTO_ENV_FILE": str(TEMP / "synthetic.env"),
    "GEMINI_API_KEY": "test-gemini-key-for-unit-tests-only",
    "OPENAI_API_KEY": "test-openai-key-for-unit-tests-only",
    "SERP_API_KEY": "test-serp-key-for-unit-tests-only-xx",
    "LLM_PROVIDER": "gemini", "GEMINI_MODEL": "gemini-2.5-flash",
    "NEWS_PROVIDER": "serpapi", "LLM_MULTI_PROVIDERS": "gemini,groq",
    "PREDICTOR_OPS_STATE_DIR": str(TEMP / "state"),
    "PREDICTOR_EVENTS_PATH": str(TEMP / "events.jsonl"),
    "COVERAGE_FILE": str(RUN / "runtime.coverage"),
    "PYTHONIOENCODING": "utf-8", "PYRIGHT_PYTHON_CACHE_DIR": str(TEMP / "pyright"),
})
(TEMP / "synthetic.env").write_text("# No private configuration\n", encoding="utf-8")
for key in ("DATA", "OUTPUT", "CACHE", "LOGS"):
    ENV[key + "_DIR"] = ENV["GARIMPO_" + key + "_DIR"] = str(TEMP / key.lower())

def git(*args):
    return subprocess.check_output(["git", *args], cwd=PROJECT, text=True).strip()

state = {
    "started_at_utc": datetime.now(timezone.utc).isoformat(),
    "head": git("rev-parse", "HEAD"), "branch": git("branch", "--show-current"),
    "origin_main_local": git("rev-parse", "origin/main"),
    "status": git("status", "--short"), "worktrees": git("worktree", "list"),
    "python": sys.version, "executable": sys.executable, "platform": platform.platform(),
    "remote": re.sub(r"(https?://)[^/@\s]+@", r"\1[REDACTED]@", git("remote", "-v")),
    "real_credentials_available_to_checks": False,
    "private_dotenv_loaded": False, "temporary_root": str(TEMP),
    "source_hashes": {p: hashlib.sha256((PROJECT / p).read_bytes()).hexdigest()
                      for p in git("ls-files", "--cached", "--others", "--exclude-standard", "*.py", "*.toml", "*.lock", ".github/workflows/*").splitlines()
                      if (PROJECT / p).is_file()},
    "checks": [],
}
(RUN / "initial_next_chat_prompt.md").write_bytes((PROJECT / "docs/NEXT_CHAT_PROMPT.md").read_bytes())
(RUN / "initial_diff.patch").write_bytes(subprocess.check_output(["git", "diff", "--binary"], cwd=PROJECT))

def save():
    (RUN / "validation.json").write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def check(name, args, cwd=PROJECT):
    started = datetime.now(timezone.utc)
    result = subprocess.run(args, cwd=cwd, env=ENV, capture_output=True, text=True, encoding="utf-8", errors="replace")
    output = result.stdout + result.stderr
    # No real secrets are passed. Also redact credential-bearing URL forms in tool errors.
    output = re.sub(r"(https?://)[^/@\s]+@", r"\1[REDACTED]@", output)
    (RUN / (name + ".log")).write_text(output, encoding="utf-8")
    record = {"name": name, "command": args, "cwd": str(cwd), "exit_code": result.returncode,
              "started_at_utc": started.isoformat(), "finished_at_utc": datetime.now(timezone.utc).isoformat(),
              "log": name + ".log"}
    state["checks"].append(record)
    save()
    print(json.dumps(record), flush=True)
    return result

save()
CMD = r"C:\Cripto\CRIPTO.cmd"
if PHASE.startswith("postmerge"):
    check("sync_all_extras", [CMD, "uv", "sync", "--frozen", "--all-extras"])
    state["packages"] = {d.metadata["Name"]: d.version for d in importlib.metadata.distributions()}
    check("tests", [CMD, "python", "-u", "-m", "pytest", "-q", "-ra", "--basetemp", str(TEMP / "pytest"), "--junitxml", str(RUN / "tests.xml")])
    state["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
    save()
    raise SystemExit(any(c["exit_code"] != 0 for c in state["checks"]))
check("sync_all_extras", [CMD, "uv", "sync", "--locked", "--all-extras"])
state["packages"] = {d.metadata["Name"]: d.version for d in importlib.metadata.distributions()}
check("ruff", [CMD, "python", "-m", "ruff", "check", "."])
check("format", [CMD, "python", "-m", "ruff", "format", "--check", "--diff", "."])
check("pyright", [CMD, "uv", "run", "--no-sync", "pyright"])
check("secrets", [CMD, "python", "scripts/scan_secrets.py", "."])
build = check("build", [CMD, "uv", "build", "--out-dir", str(RUN / "dist")])
if build.returncode == 0:
    state["build_artifacts"] = {}
    for artifact in (RUN / "dist").iterdir():
        previous = PROJECT / "dist" / artifact.name
        if previous.exists():
            preserved = RUN / "previous_dist"
            preserved.mkdir(exist_ok=True)
            shutil.copy2(previous, preserved / artifact.name)
        shutil.copy2(artifact, previous)
        state["build_artifacts"][artifact.name] = hashlib.sha256(artifact.read_bytes()).hexdigest()
    save()
check("tests", [CMD, "python", "-u", "-m", "coverage", "run", "--rcfile=coverage-runtime.ini", "-m", "pytest", "-q", "-ra", "--basetemp", str(TEMP / "pytest"), "--junitxml", str(RUN / "tests.xml")])
check("coverage", [CMD, "python", "-m", "coverage", "report", "--rcfile=coverage-runtime.ini"])
check("coverage_json", [CMD, "python", "-m", "coverage", "json", "--rcfile=coverage-runtime.ini", "-o", str(RUN / "coverage.json")])
check("windows_status", [CMD, "status"])
check("windows_help", [CMD, "pipeline", "--help"])
state["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
save()
raise SystemExit(any(c["exit_code"] != 0 for c in state["checks"]))
