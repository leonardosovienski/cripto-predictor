from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,hashlib
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909')
root=Path(r'C:\Cripto\restaurado-20260908\sessoes')
paths=[root/'20260907-pesquisa/work/carry-forward-data',root/'20260907-altcoins/work/altcoin-reviewed-data',root/'20260907-altcoins/work/altcoin-forward-data']
out=[]
for path in paths:
    item={'directory':str(path),'exists':path.exists()}
    if path.exists():
        item['status_files']={}
        for f in path.glob('*status*.json'):
            data=json.loads(f.read_bytes());item['status_files'][f.name]=data
        journal=path/'ledger.jsonl'
        if journal.exists():
            rows=[json.loads(line) for line in journal.read_bytes().splitlines() if line]
            item['journal_rows']=len(rows);item['kinds']=dict(Counter(x.get('kind',x.get('type','unknown')) for x in rows));item['journal_sha256']=hashlib.sha256(journal.read_bytes()).hexdigest()
    out.append(item)
proto=json.loads(Path(r'C:\Cripto\pesquisa-20260909\docs\evidence\carry_forward_20260908\protocol.json').read_bytes())
result={'at_utc':datetime.now(timezone.utc).isoformat(),'read_only':True,'observers':out,'carry_entry_window':[proto['start'],proto['window_minutes']],'carry_interpretation':'The restored journal has no ENTRY, and the 2026-09-09 00:00..01:00 UTC entry window has passed. WAITING is a preserved preflight snapshot, not current readiness. Missing entry is terminal for this pilot. A new future pilot requires a new protocol/window; do not backdate or reset the old diary. No observer executed or scheduled.'}
(R/'observer_state_review.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps([{k:v for k,v in x.items() if k!='status_files'} for x in out]));print(result['carry_interpretation'])
