"""One finite diagnostic with the existing real budget; no orders or recurring jobs."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,sqlite3,subprocess,sys
from GarimpoInvestimentos.config import settings
from GarimpoInvestimentos.core.paths import FEATURE_STORE_DB
from GarimpoInvestimentos.core.api_guard import _BUDGET_DB
from GarimpoInvestimentos.security.redaction import safe_redact_text,configured_secret_values
R=Path(r'C:\Cripto\operacao\relatorios\REVISAO_COMPLETA_20260909\live')
P=Path(r'C:\Cripto\pesquisa-20260909')
def budget():
    with sqlite3.connect(_BUDGET_DB.as_uri()+'?mode=ro',uri=True) as c:
        c.row_factory=sqlite3.Row
        return [dict(row) for row in c.execute('SELECT * FROM api_budget')]
pre={'at_utc':datetime.now(timezone.utc).isoformat(),'provider':settings.LLM_PROVIDER,'model':settings.GEMINI_MODEL,'ensemble_n':settings.LLM_ENSEMBLE_N,'news_provider':settings.NEWS_PROVIDERS,'news_fallback':settings.NEWS_FALLBACK_PROVIDER,'guard_enabled':settings.API_GUARD_ENABLED,'limits':[settings.API_GUARD_MAX_INGEST_ASSETS,settings.API_GUARD_MAX_NEWS_ATTEMPTS_PER_PROVIDER,settings.API_GUARD_MAX_LLM_CALLS_PER_PROVIDER],'budget_path':str(_BUDGET_DB),'budget':budget(),'credentials_present':{k:bool(getattr(settings,k,'')) for k in ['GEMINI_API_KEY','SERP_API_KEY','GROQ_API_KEY','CEREBRAS_API_KEY','COINGECKO_API_KEY']}}
print(json.dumps(pre),flush=True)
if '--execute' not in sys.argv:raise SystemExit(0)
assert pre['guard_enabled'] and pre['limits']==[28,8,6]
assert pre['provider']=='gemini' and pre['news_provider']==['serpapi'] and pre['ensemble_n']==1
assert not pre['news_fallback']
R.mkdir(exist_ok=False)
(R/'scope.json').write_text(json.dumps({'question':'Does corrected BTC ingestion plus one real Gemini/SerpAPI diagnostic preserve exact new inputs and remain excluded from economic validation?','scope':'1 asset ingestion and 1 logical LLM analysis; existing retries and budgets apply, no resets. No alternative LLM, no economic hypothesis or outcome evaluation.','free_basis':'Owner confirmed free plans; prior generation/SerpAPI account checks preserved in FECHAMENTO_PENDENCIAS_20260909. Cerebras excluded. Binance/FearGreed public.','preflight':pre,'capital_permission':False,'scheduled':False},indent=2),encoding='utf-8')
with sqlite3.connect(FEATURE_STORE_DB.as_uri()+'?mode=ro',uri=True) as src:
    with sqlite3.connect(R/'store_before.db') as dst:src.backup(dst)
secrets=configured_secret_values()
records=[]
for label,args in [('ingest',['pipeline','--ingest','--assets','bitcoin']),('analysis',['pipeline','--assets','bitcoin','--no-cache','--summary'])]:
    started=datetime.now(timezone.utc).isoformat()
    completed=subprocess.run([r'C:\Cripto\CRIPTO.cmd',*args],cwd=P,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=360)
    output=safe_redact_text(completed.stdout+completed.stderr,secrets)
    (R/(label+'.log')).write_text(output,encoding='utf-8')
    records.append({'command':args,'started_utc':started,'ended_utc':datetime.now(timezone.utc).isoformat(),'exit_code':completed.returncode})
    print(json.dumps(records[-1]),flush=True)
    if completed.returncode:break
with sqlite3.connect(FEATURE_STORE_DB.as_uri()+'?mode=ro',uri=True) as c:
    c.row_factory=sqlite3.Row
    payloads=[json.loads(x[0]) for x in c.execute('SELECT payload_json FROM prediction_inputs')]
    summary={'predictions':c.execute('SELECT COUNT(*) FROM predictions').fetchone()[0],'market_snapshots':c.execute('SELECT COUNT(*) FROM market_snapshots').fetchone()[0],'prediction_inputs':len(payloads),'inputs':[{'contract':x['evaluation_contract'],'news_count':len(x['news_titles']),'raw_response_preserved':bool(x['analysis'].get('raw_response')),'market_snapshot_id':x['market_snapshot_id'],'started_at':x['analysis_started_at'],'completed_at':x['analysis_completed_at'],'llm_fallback':x['analysis'].get('llm_fallback')} for x in payloads],'quick_check':c.execute('PRAGMA quick_check').fetchone()[0]}
(R/'result.json').write_text(json.dumps({'commands':records,'database':summary,'budget_after':budget(),'classification':'OPERATIONAL_DIAGNOSTIC_NOT_PROSPECTIVE_SAMPLE','capital_permission':False},indent=2),encoding='utf-8')
print(json.dumps(summary),flush=True)
