# Revisão completa do projeto Cripto — 09/09/2026

Registro vivo único da revisão. Evidências abaixo são desta rodada, salvo indicação expressa de histórico. Atualização: 2026-09-09T23:44:34.474624+00:00. **Integração: INTEGRADO_E_VALIDADO_NO_MAIN — [PR #111](https://github.com/leonardosovienski/cripto-predictor/pull/111) — main `909724e36d23b1683268c9e43d533f553c7dfe5f`.** Engenharia e inferência econômica são julgadas separadamente; nenhuma autorização de capital ou automação.

## 1. Conclusão para o dono e o investidor

O projeto é uma plataforma de pesquisa com coleta pública, análise experimental por LLM, armazenamento local, avaliações históricas, modelos quantitativos e observadores teóricos. A execução conectada foi demonstrada; lucro real ou futuro validado não foi. O avanço material desta revisão foi descobrir que um preço anterior à resposta podia entrar como se fosse preço de decisão, além de séries com lacunas produzirem indicadores com horizontes incorretos. Corrigimos esses contratos e passamos a guardar os inputs das novas previsões antes das exportações.

Reproduzimos contas históricas por implementações separadas, preservando ganhos, perdas e ausências. Reconstruímos todas as 979.377 linhas das duas aquisições de altcoins frente aos brutos, sem divergências. Isso melhora a confiança nos registros existentes; não preenche lacunas nem transforma o histórico usado na escolha dos métodos em teste independente.

Cada cenário abaixo usa **5.000 USDT hipotéticos próprios**. Não são saldo do dono, autorização para aplicar ou resultados somáveis. Os valores são após custos modelados, antes de despesas pessoais desconhecidas, impostos, conversão e execução não comprovada.

| Estudo | Período | Base / adverso, USDT | Evidência e consequência |
|---|---|---|---|
| AR1 BTC | 980 dias, 01/01/2024–07/09/2026 | +424,2529 / +341,1276 | Um hedge contínuo; positivo histórico, mas 2026 contribuiu só +5,7485 no adverso. Não é renda mensal esperada |
| BR1 BTC | Mesmo intervalo | +230,17 / +110,07 | Cinco hedges, nenhum em 2026; intervalo descritivo adverso inclui zero |
| AR2 BTC | Mesmo intervalo | +17,7911 / −82,2580 | Três períodos de posição e uma renovação adjacente; ajuste só do delta daria +23,6348 / −65,8959, cenário hipotético |
| Limite otimista AR2 | Mesmo histórico, mesmas quantidades | +23,8515 / −65,3870 | Mesmo com custos de renovação anulados e concessões otimistas, o adverso não se torna positivo |
| AR3 | 140 semanas de pesquisa | −4.945,3514 no custo base; −4.974,3544 a 40 bps | 630 posições selecionadas, 231 ganhos/399 perdas; perda base de 98,91%, patrimônio final 54,65 USDT. Abandonar essa regra como candidata nesta referência |
| BR2 | 23.520 decisões horárias | 0 / 0 | Maior prêmio observado 0,288805%, abaixo do gatilho 0,75%; ausência de entradas explicada por filtro, não por falta de campo |
| Seletor de analogias | 140 semanas | 0 / 0 | 13.996 candidatos, nenhum qualificado; não há evidência de resultado de trades |
| Carry recente | 84 dias até 08/09 | +10,56 / −6,97; estresse −21,65 | Auditoria de 44 fontes e 334 comparações passou; ainda é diagnóstico retrospectivo |
| Aave USDC/Arbitrum | Protocolo fixo da rodada econômica | Não medido | Estado histórico/índice e liquidez inacessíveis nas fontes testadas; não inferir rendimento bom ou ruim |

**Não houve melhoria econômica demonstrada nesta revisão.** A melhoria demonstrada é técnica, contábil e de qualidade da decisão. A descoberta que mais muda a leitura do produto é o preço de contexto indevidamente contado na avaliação. A hipótese que perdeu prioridade é “otimizar a renovação basta para salvar AR2”: a conta separada confirma margem insuficiente no adverso. AR1 merece apenas investigação condicional futura, dado o enfraquecimento recente; não uma recomendação de alocação. O próximo marco econômico exige observação após a escolha do método e custos compatíveis com uma estrutura especificada.

O piloto preservado de carry **perdeu a janela de entrada** de 09/09/2026, 00:00–01:00 UTC: há somente PREFLIGHT no diário. O status WAITING salvo em 08/09 é antigo. Continuar exige novo protocolo e janela futura, preservando a ausência original. Altcoins também têm somente pré-testes nos diários lidos, sem resultados prospectivos. Não ativei ou migrei nenhum agendamento.

## 2. Estado real, mandato e preservação

Lidos AGENTS.md, configuração local, NEXT_CHAT_PROMPT e mandato econômico original. Trabalho individual; somente C:\Cripto; sem ordens, fundos, credenciais financeiras, contas, pagamentos, mensagens a terceiros ou agendamentos. Planos gratuitos e backups já confirmados pelo dono não foram perguntados novamente. Segredos não foram impressos, publicados ou usados como fingerprints.

Estado inicial: branch fix/data-readiness-20260909, HEAD/local origin/main/remoto consultado em **276d6db224f266e9ec889b6de4ab5ba0328cc321**. Único diff inicial: docs/NEXT_CHAT_PROMPT.md. Cópia exata e diff em baseline/initial_next_chat_prompt.md e baseline/initial_diff.patch. Nova branch: fix/full-review-20260909. O diff original do dono fica fora do commit de correções e deve permanecer byte a byte. Os snapshots restaurados, manifestos, custos científicos, charters, definições H6 e diários permanecem preservados.

Checkout: C:\Cripto\pesquisa-20260909. Operação: C:\Cripto\operacao. Histórico: C:\Cripto\restaurado-20260908. O perfil confina os caminhos configurados, não comandos arbitrários do Windows. Não foi feita nova cópia/restauração sobre os originais. Antes da única escrita conectada no banco operacional, foi feito backup SQLite consistente em live/store_before.db.

## 3. Nova linha de base, falhas e verificações

Baseline anterior às mudanças comportamentais: **1.285 passed, 1 skipped, zero falhas de testes**, 336,15 s. Skip: privilégio Windows para symlink. Instalação locked/all-extras, lint, formato, build, entradas Windows e pacote instalado fora do checkout passaram. Python 3.13.14; uv 0.12.1; Core 3.2.0 e Ops 4.1.0. Versões completas, hashes de fontes, comandos e tempos em baseline/validation.json.

Não ocultar dois problemas da baseline: `python -m pyright` achou o alias Microsoft Store e gerou 15 imports não resolvidos; pela entrada do CI `CRIPTO.cmd uv run --no-sync pyright` passou com zero erros. O scanner recursivo entrou em caches ignorados e foi interrompido após cerca de 235 s; não é execução aprovada. Sua correção restringe a busca aos arquivos publicáveis do Git e não emite hashes de possíveis segredos. A baseline completa de testes não significa baseline totalmente verde em todos os comandos.

O wheel de baseline teve SHA256 ebd288dc9ba28f3fa3c4986aad0c725c3a437b4fc25df4bf59078d3f71e8ae2a. O teste de distribuição da baseline usou o dist preexistente com os mesmos bytes; a instalação externa usou o novo build. Nas rodadas finais, os testes de distribuição usam exatamente o build novo, copiando-o para dist somente após preservar o anterior em previous_dist.

Falhas de desenvolvimento preservadas: targeted01/02 (fixtures incompletas e serialização de frozenset), integration01 (1.298 pass/4 falhas, incluindo isolamento do adaptador de ações e três consumidores de legado), targeted04 (nenhum teste: nome de arquivo inexistente), final01 (1.318 pass/2 falhas). Em final01, uma fixture COTAHIST tinha close maior que high; corrigiu-se a fixture, sem relaxar a validação. A segunda falha detectou alteração indevida nas funções congeladas da H6: a mudança foi retirada e a exclusão de novos diagnósticos foi colocada nos consumidores. Nenhum hash congelado foi atualizado para aceitar a mudança. targeted05: 81 pass; targeted06: 73 pass, incluindo o verificador real de freeze H6.

**Rodada final02:** 1321 passed, 1 skipped in 305.98s (0:05:05). Cobertura runtime combinada: 89.298743%; statements 1.801/1.959 (91,93%) e branches 402/508 (79,13%). Checks: sync_all_extras=0, ruff=0, format=0, pyright=0, secrets=0, build=0, tests=0, coverage=0, coverage_json=0, windows_status=0, windows_help=0. Comandos completos/artefatos/hashes: final02/validation.json, tests.xml, coverage.json e logs. A cobertura se refere ao escopo coverage-runtime.ini; não é percentual de prontidão, acerto ou revisão manual. A execução inclui todos os extras, inclusive HMM. Houve aumento líquido de 36 testes aprovados frente à baseline.

O pacote final foi instalado em ambiente novo fora do checkout por work/wheel_check.py: 164 membros, nenhum membro proibido, criação/instalação/contrato com saída zero. SHA256 do wheel: a704385e5360141a2e2addbb1d11bfb3170c231122ce6c598c9e1c8ea2c13a21; evidência em final02/wheel_contract.json. O release_validation.json compara os 1.542 arquivos de fontes, configuração, lock e workflows registrados na validação final, inclusive cópias históricas, e confirma que nenhum mudou depois dos testes; também confere o diff do dono e os caminhos congelados. O verificador freeze H6 passou sem alterar sua definição.

Docker não foi encontrado localmente; a prova de container é o job remoto, separado do smoke Windows. O run remoto 34403156484 da baseline já estava verde, mas não foi usado como prova das correções. O arquivo integration.json registra PR, SHA, base, quatro jobs e verificação pós-merge. PR #111 integrado em 09/09/2026, 22:57:48 UTC. Os quatro jobs exigidos passaram no PR (run 34414119277) e no push do main resultante (run 34414735590): quality, all-extras, container e python-314-experimental. Evidências em ci_pr.json e ci_main.json. O checkout operacional avançou por fast-forward até 909724e36d23b1683268c9e43d533f553c7dfe5f; sua árvore 427de5a6eba0d191a7c8e8404cc4178c02cf4abf é idêntica à árvore testada antes do merge. O main remoto foi reconferido nesse SHA. A verificação local exigida após merge passou com sync frozen/all-extras e 1.321 testes aprovados, um skip Windows de symlink, zero falhas em 135,30 s (postmerge01/validation.json). O diff original de NEXT_CHAT_PROMPT.md permanece byte a byte e fora do commit. Nenhum trabalho de integração ou teste ficou pendente.

**Diagnóstico conectado próprio, 22:34–22:38 UTC:** uma ingestão BTC e uma análise Gemini/SerpAPI, sem fallback LLM. 200 candles, cinco títulos, novo snapshot de mercado e inputs da previsão; três previsões totais, duas legadas. Banco quick_check=ok. Os budgets reais passaram 2→3 em ingest/assets, news/serpapi e llm/gemini; Groq/Cerebras permaneceram em 1. Guarda ligada (28/8/6), sem reset. Gemini levou aproximadamente 223 s nessa chamada lógica; não se presume custo, latência ou disponibilidade constantes. Preservado em live/scope.json, result.json e logs redatados. Essa versão do caminho de ingestão/análise é a mesma dos checks finais; depois foram reforçados apenas consumidores de avaliação/documentação. Não houve nova chamada para repetir o sucesso.

## 4. Cobertura da revisão

Inventário inicial: 2.057 arquivos versionados; 336 arquivos Python de código/testes analisados por AST fora das cópias de código histórico embutidas. Existem 1.534 .py contando essas cópias, que não equivalem a 1.534 módulos ativos. A maior parte dos arquivos está em docs/evidências/arquivos históricos. inventory.json registra imports, funções, classes, tipos, artefatos de modelos e dependências. A listagem não equivale a leitura ou validação.

| Componente | Profundidade real | Evidência/limite |
|---|---|---|
| Entradas CLI/Windows, configuração, caminhos e CI | Leitura direta dos caminhos materiais; execução | status/help, testes de escapes, instalação externa, isolamento de credenciais |
| main, phase1, ingest, features, store, cache, notícias, LLM e backtest | Leitura direta dos fluxos alterados e consumidores | Casos adversos, regressões, persistência, pipeline conectado; nova avaliação ainda sem desfechos futuros |
| Core/Ops compartilhados | Leitura material de contratos, routers, agregação, rede/retry, estatística, locks, escrita atômica, runner/redação; demais módulos inventariados | Versões fixadas e contratos/testes do domínio; não auditei integralmente os dois outros projetos nem alterei seus pacotes |
| V3/HMM | Leitura de pipeline, feature_builder, treino/scaler/inferência, partição WFA, custos e paper; cobertura dos demais módulos via testes e amostragem | HMM temporal e purge exercitados pela suíte; não reexecutado experimento congelado nem chamado treino histórico válido por mera presença de modelo |
| Trading | Leitura de contratos materiais, execução, reconciliação, ledger, adapter, custo e relatório de risco; amostragem dos auxiliares | Simulação testada; não existe confirmação de fills, margem e fee de conta real |
| Pesquisa carry/basis/altcoins | Auditores executados e inspecionados, protocolos/ledgers/decisões reconciliados | Reconstrução integral das duas bases de altcoins; 32 vetores do seletor por amostragem; contas materiais Decimal separadas |
| Observadores congelados | Leitura dos contratos de tempo/diário e estado real; testes offline do ciclo de vida | Journals só pré-testes; sem executar tick ou alterar os arquivos originais |
| Documentação histórica e modelos | Documentos de entrada lidos; HYPOTHESES e arquitetura histórica examinados nas hipóteses/erratas relevantes, não cada linha do longo diário; demais documentos/modelos inventariados/amostrados | Não certifico leitura de cada arquivo nem proveniência de cada narrativa antiga; conclusões históricas sem dados são limitadas |
| Frontend/API pública/notebooks/infra externa | Inventário de entradas e dependências | Não há frontend implantado ou API financeira operacional demonstrada; não foi criado serviço para satisfazer checklist |

A revisão cobre os fluxos ativos e o histórico material às decisões atuais. Não certifica toda biblioteca de terceiros, todos os documentos datados, o disco antigo inteiro ou um universo histórico completo. Essas limitações não invalidam o diagnóstico pontual e a reprodução das contas especificadas; impedem declarações universais de causalidade, recuperação ou produção financeira.

## 5. Arquitetura real e decisões

```text
CLI/Windows → perfil local + configuração privada + orçamento SQLite
  ├─ discovery (opcional, rede): catálogo/momentum/trending → lista de candidatos
  ├─ ingestão DPL: providers → router → candles/sinais → features + snapshot
  │                                  ↓
  └─ main/phase1 ← snapshot recente da store
         → pré-filtro → budget → notícias → LLM → score experimental
         → transação predictions + prediction_inputs → cache/exportações
         → avaliação de fechamentos futuros (descritiva, sem promoção científica)

V3 (ramo separado): funding/OI/spot CSV → features → HMM/scaler
  ├─ pipeline: ajuste/inferência → sinais teóricos → paper JSONL
  └─ WFA: treino IS por fold/purge → OOS → proxies de retorno/custos
         → adaptador de tipos de trade; família congelada recusada

Pesquisa econômica (ramo separado): fontes/normalizados congelados
  → protocolos AR/BR/analogias → ledgers/decisões → auditores separados
Observadores (ramo separado): protocolos e relógio real → diário durável
  → marcas hipotéticas e censura de ausências; sem ordem financeira
Core: tipos/rede/estatística. Ops: execução, locks, evidência e redação.
services/*: reexports de funções, não daemons HTTP.
```

| Responsabilidade, entrada → saída | Consumidor/estado e falha | Decisão, contribuição e alternativa |
|---|---|---|
| Perfil/CLI: flags/env → paths/settings | Todas as entradas; recusa caminho externo/configuração inválida | Manter. Custo pequeno; não substituir por sandbox fictícia |
| Discovery: mercado atual → candidatos | --discover/ingest; falha de rede ou filtro gera vazio explícito | Manter opcional, não usar para certificar universo histórico; universo fixo é alternativa simples para medir contribuição |
| DPL fallback: Binance→CoinGecko, Kraken no consenso | Ingestão; erro/retry/circuito; dado ruim rejeitado | Manter fallback identificado; fonte única Binance no diagnóstico reduz mistura metodológica. Não chamar consenso de verdade independente |
| Alinhamento/feature store: publicação/coleta/vintage → linhas | Serving e pesquisas; gaps/velhice/NaN | Manter SQLite local e snapshot. Custo de duplicar 200 candles é aceitável para integridade; reconstituir apenas features é insuficiente |
| LLM/notícias: contexto → score | main/phase1; quota, modelo inválido, JSON ruim, deriva do fornecedor | Manter experimental, limitar chamadas. Comparar futuramente preço persistente, sinal simples e ablação sem notícias/LLM; contribuição incremental não medida |
| HMM/V3: dados → regime/sinais | Pesquisa encerrada e paper teórico, não cadeia de execução real | Manter para reprodução; retirar da promessa de validação ao vivo. Scaler ajustado em toda série não torna previsões históricas OOS. Novo uso precisa novo protocolo e dados adequados |
| WFA/custos: folds → estatísticas | Estudos históricos; overlap, escassez, funding aproximado e fills ausentes | Manter definição congelada para reprodução. Não retunar para resgatar resultado; relatórios devem assumir limites, não alegar calibração de conta |
| Execução/risco: intenções → estados/fills sintéticos | Bibliotecas/testes; adapter financeiro real ausente, posição/margem incompleta | Manter separada sem ativar. Não implementar exchange autenticada antes de evidência e autorização específica |
| Core/Ops e services wrappers | Contratos materiais ligados por imports; outros wrappers só compatibilidade | Manter releases fixadas; reduzir documentação enganosa. Remover wrappers daria pouco benefício e risco de API sem melhorar a decisão econômica |
| Observadores | Código retomável sob freeze; dado futuro não existe, carry perdeu entrada | Preservar. Escolher nova janela registrada é necessário; resetar diário/recriar entrada com candles seria inválido |

Contradições confirmadas: (a) bitemporalidade integral versus upsert sem vintages de candles/inputs antigos; (b) granularidade CoinGecko solicitada versus entregue; (c) indicadores em dias versus posições após lacunas; (d) previsão posterior versus retorno que começou antes da resposta; (e) paper “paridade total/valida edge” versus ajuste retrospectivo e ausência de fills; (f) constante de custo chamada CALIBRATED_FOR_VERDICT versus pressuposto não calibrado, já reconhecido na errata histórica; (g) WAITING salvo versus janela de carry perdida. As erratas versionadas são docs/REVISAO_COMPLETA_20260909.md; os registros congelados não foram reescritos.

## 6. Matriz canônica de afirmações

| ID | Afirmação/origem/versão | Significado e uso | Evidência necessária | Verificação e resultado | Estado | Impacto/ação |
|---|---|---|---|---|---|---|
| C01 | Perfil local, base 276d6db | Saídas configuradas em C:\Cripto | Paths resolvidos, escapes, testes | Windows real e casos de caminho passaram; não é sandbox | comprovada no escopo testado | Manter contrato explícito |
| C02 | Engenharia anterior “verde” | Referência de comportamento | Baseline própria e versão | 1.285 pass; falhas ambientais/scanner preservadas | parcialmente comprovada | Checks finais próprios, não reutilizar CI anterior |
| C03 | Diário Binance fechado | Features disponíveis | OHLCV/tempo e ingestão real | 200 barras fechadas, source exato; não cobertura universal | comprovada no escopo testado | Limitar a BTC/janela exercitada |
| C04 | CoinGecko equivale à frequência pedida | Candles intercambiáveis | Contrato oficial/grid | Contradito na base; adaptador corrigido e regressões | contradita | Aceitar somente frequência real; OHLC diário sintético |
| C05 | Store totalmente bitemporal | Reprodução de todo passado | Inputs e vintages completos | Não existiam; 0019 preserva inputs novos | parcialmente comprovada | H5 antigo continua indisponível |
| C06 | change_7d são sete dias | Indicador temporal | Continuidade exata | Base: sete observações em 14 dias; novo sufixo contínuo | contradita | Corrigido, sem interpolar |
| C07 | Retorno posterior ao score | Validade preditiva | Base temporal após a resposta | Controle 100→200 anterior resulta agora em retorno futuro 0, não +100% | comprovada no escopo testado | Novo contrato, sem misturar legado |
| C08 | Score 75 = 75% chance ou lucro | Decisão de investimento | Calibração/OOS/custos | Não existe essa validação | não verificada | Score experimental; só diagnóstico descritivo |
| C09 | Notícias históricas exatas | Causalidade da narrativa | Publicação e recibo original | Preservados títulos/recibo novos; publicação histórica não verificada | parcialmente comprovada | Não backfill de notícia atual em pesquisa antiga |
| C10 | Inferência HMM forward prova OOS | V3 histórica/paper | Treino/scaler anteriores à inferência | Forward causal condicionado ao modelo; pipeline pode ajustar toda série | parcialmente comprovada | Não promover paper retrospectivo |
| C11 | Custos V3 calibrados | Resultado executável | Fee de conta, fills, funding realizado | São pressupostos; método não garante conservadorismo em todo caso | contradita | Manter referência congelada e errata; exigir medição para execução |
| C12 | Há execução financeira real | Resultado em conta | Adapter autenticado e fills reconciliados | Somente interfaces e simulações | contradita | Não criar/ativar na revisão |
| C13 | Altcoins integralmente reconstruídas | Integridade dos normalizados | Todo bruto e linha comparados | Duas aquisições completas, zero divergências; cobertura do mercado não certificada | comprovada no escopo testado | Não confundir integridade com completude |
| C14 | Lacunas de altcoins resolvidas | Elegibilidade contínua | Observações faltantes | 12 sondas anteriores não recuperaram; 542 dias somados continuam | contradita | Excluir janelas incompletas, dependência D03 |
| C15 | Carry/futuros contas corretas | Cenários históricos | Rebuild/Decimal/causalidade | Auditores atuais PASS, limites abaixo | comprovada no escopo testado | Resultado executável não decorre disso |
| C16 | Zero trades = ausência de alpha universal | BR2/seletor | Mecanismo da abstenção, poder | Filtros explicam zero; sem fills/retornos de posições | contradita | Não retunar nem generalizar |
| C17 | Aave sem dados = ruim/bom | Rendimento | Índice/liquidez 13 fronteiras | Nova fonte também sem estado de arquivo | não verificada | D01, nenhum rendimento calculado |
| C18 | WAITING do carry é atual | Continuidade | Diário e relógio real | Entrada inexistente após janela | desatualizada | D04, novo protocolo futuro necessário |
| C19 | Groq/SDK saudável = endpoint gratuito disponível | Integrações | Geração e quota reais | Gemini/SerpAPI usados; Groq com sucesso só na preparação; Cerebras retornou 402 | parcialmente comprovada | Não inferir acesso de listagem de modelos |
| C20 | A revisão aumentou lucro | Benefício econômico | Mesmas condições, resultado líquido novo | Nenhum resultado econômico novo positivo demonstrado | não verificada | Benefício comprovado é técnico |

“Existe / funciona / correto / validado para uso” não são sinônimos: DPL/main existem e funcionaram no diagnóstico; seus contratos corrigidos foram comparados com invariantes e fontes, mas o score não está validado para investir. As contas AR/BR existem, reproduzem e conciliam referências; execução futura não está validada. V3 existe e roda em testes; algumas afirmações de uso eram excessivas, e a família permanece encerrada. Os observadores existem e seus controles funcionam em testes; não há amostra futura formada. Frontend/ordens reais: inexistentes no fluxo, portanto não aplicáveis à prontidão do diagnóstico.

## 7. Premissas, refutação e dados

| Premissa/origem | Por que poderia valer | Falha/refutação observável | Resultado desta revisão |
|---|---|---|---|
| Candles em grade diária, adapters | Contrato UTC do feed | Intervalo desigual/duplicado/parcial | Defeito demonstrado e corrigido para inputs novos |
| Publicado ≤ decisão, causalidade | Campos temporais dos providers | Coleta futura/velha, revisão retrodatada | Guardas locais e snapshots; carimbo declarado pelo feed não é vintage histórico integral |
| Volume em USD, feature antiga | Notional aproximado | Base-volume tratado como dólares, USDT≠USD | Volume×close marcado estimativa; nenhuma conversão USDT/USDC/BRL assumida |
| Fonte consistente | Mesma régua reduz mistura | Troca de source, metodologia, alias/token | Novo alvo exige source exato; BNX→FORM 1:1 auditado no AR3; universo histórico incompleto |
| Score ordena retornos | Narrativa/momentum podem conter sinal | OOS nulo/invertido, baseline simples igual ou melhor | Contribuição incremental não validada; H5 histórico oposto sem reprodução integral disponível |
| HMM causal | Forward usa observações passadas | Scaler/modelo treinado no futuro | WFA IS separado; pipeline retrospectivo não certifica OOS |
| Custos representam operação | Cenários de fee/slippage/margem | Conta/fill/latência diferem, funding muda | Arredondamento/caixa reconciliados; fees e margem real não certificados |
| Cinco trades/140 semanas bastam | Contagem nominal grande | Dependência, concentração, ausência de exposição | BR1 pequeno; seletor zero; bootstrap descritivo condicionado ao histórico adaptativo |
| Dados grátis suficientes | Endpoints públicos acessíveis | 402/403, limite ou arquivo indisponível | Gemini/SerpAPI local sim; Aave não; não habilitar pagamento |
| Sem ordens implica sem risco de estratégia | Nenhum fundo foi exposto | Confundir simulação com investimento | Nenhum dano financeiro executado; risco teórico de AR3 visível e perdas preservadas |

| Base/uso | Fonte, unidade, frequência, período | Conteúdo conferido e limite | Local/consumidor |
|---|---|---|---|
| BTC operacional | Binance público via CCXT, BTC e USDT aproximado a USD, UTC/1d | 200 opens de 21/02 a 08/09/2026, publicados até 09/09; somente BTC, fonte única no novo snapshot | operacao/saidas/feature_store.db → main/phase1 |
| Notícias/LLM | SerpAPI títulos recebidos; Gemini 2.5 Flash JSON | Cinco títulos e resposta novos preservados, recibos e prompt; publicação original/modelo interno mutável não certificados | prediction_inputs → diagnóstico |
| Carry original | Binance spot/perp/funding/mark/metadata, BTC/ETH, diários e horários, janela de 980 dias | 68 brutos; 10 normalizados do manifesto, oito séries reconstruídas pelo auditor de conta (escopos distintos); 27 períodos de posição e 155.232 verificações horárias | restaurado/.../20260907-pesquisa/work/carry-research-data → AR1/AR2 |
| Futuros original | Binance Vision/REST, spot/perp/contratos trimestrais, UTC/1h | 532 brutos, 29 séries, 23.994 decisões, 165.258 comparações Decimal; 73.104 controles de margem/jump | .../basis-research-data → BR1/BR2 |
| Futuros recuperados | Mesma metodologia, 48 observações horárias de 29/06/2026 em dois marks | 534 fontes/29 séries reconferidas; suplemento não coincide com entradas BR1/BR2 preservadas | operacao/dados/basis-recovered-20260909; originais intactos |
| Altcoins inicial | REST/arquivo Binance spot USDT, UTC/1d | 241 pares/251.930 linhas; 326 dias somados de gaps; 83 fechamentos não padrão; zero diferenças frente aos brutos | restaurado/.../20260907-altcoins/work/altcoin-data |
| Altcoins retrospectiva | Arquivo/REST spot USDT, UTC/1d, treino 2021–23 e diagnóstico 2024–26 | 661 pares/727.447 linhas; 542 dias somados em 12 pares; 200 fechamentos não padrão. Inclui 199 parciais e um registro antigo com fechamento irregular; janelas completas os excluem. Não certifica universo histórico investível | .../altcoin-retro-data → seletor/AR3 |
| Carry recente | 44 respostas preservadas, 84 dias | 334 comparações; erro máximo 1,78e−12 USDT | .../immediate-audit-data → auditor Decimal |
| Aave | RPC público Arbitrum, USDC nativo e reserva fixos | Sem liquidityIndex histórico e liquidez nas 13 fronteiras; nenhuma estimativa | aave_1rpc/ e sondas anteriores → H1 da rodada econômica (não H1/V3) |

Duplicatas, gaps e fechamentos por par estão em altcoin_full_reconstruction.json; raw/normalizado/hash/código ficam vinculados nas respostas originais. Hashes provam identidade com referência, não verdade de mercado. Outliers reais não foram apagados para melhorar resultados. A inspeção do banco operacional usa SQLite readonly e quick_check; raw_market_data mantém upserts, por isso snapshot novo preserva exatamente o que a previsão usou.

## 8. Auditoria econômica e fontes novas

Auditoria separada significa outra implementação pelo mesmo assistente, **não auditor externo**. Os auditores carry/basis/immediate não importam o motor econômico avaliado. absolute_decimal_audit.json: 12 fluxos de custos conciliados, erro de caixa máximo 6,142635e−13 USDT; AR3: 13.996 elegibilidades ranqueadas, 36.830 barras selecionadas rastreadas e 2.520 payoffs Decimal, sem resultado selecionado censurado. basis_decimal_audit.json: máximo 9,7688e−10 USDT. basis_recovered_source_audit.json: 534 fontes/29 grupos PASS. immediate_decimal_audit.json: 334 comparações PASS. As diferenças são precisão numérica, não lucro novo.

economic_reconciliation.json refaz a soma funding + basis − execução − despesas − choque em Decimal e preserva decomposição, concentração, bootstrap e anos. AR1 base: 431,0767 de funding + 2,06625 de basis − 8,89004 de execução = 424,25289 USDT. O adverso usa 67,12329 de despesas e 24,89205 de execução, deixando 341,12759 USDT. Custos adicionais anuais de equilíbrio por aritmética, **não rendimento esperado**: cerca de 158,01/127,05 USDT por ano base/adverso para AR1; 85,73/40,99 para BR1. Custos pessoais podem consumir essa margem. Fluxos financeiros mantêm principal separado de lucro; caixa e pernas não são somados duas vezes; não se assume transferência instantânea dos ganhos spot para margem futura.

BR2: todas as 23.520 decisões com basis finito, motivo BASIS_BELOW_FIXED_GATE; máximo 0,0028880516283797952 contra 0,0075. Seletor: 12.730 sem margem positiva, 1.265 com vizinhos censurados, um com poucas semanas; 1.448 médias de vizinhos positivas antes da penalidade, mas score final entre −0,44197 e −0,02075. A auditoria amostral conferiu 32 vetores/scores, 3.881 barras e 560 fatores semanais, com erros máximos de 3,33e−16/2,78e−17. Zero trades significa métricas de ganho/perda/fills indefinidas, não risco zero.

AR2 foi reavaliado pelo diagnóstico de renovação sem mudar regra/quantidade/histórico: uma renovação, economia de giro de 5,8436793 USDT no base e 16,3620972 no adverso. O limite superior adverso continua negativo. Sua melhora mecânica não cria observação nem rejeita todo mecanismo de carry.

Nova sonda Aave pré-delimitada em aave_1rpc/scope.json: **uma fonte nova, máximo duas chamadas, sem retries, 12s e 1MB por resposta**. `eth_chainId` confirmou Arbitrum; `eth_call` da mesma reserva/bloco preservados retornou HTTP 200 com JSON-RPC −32000, estado histórico ausente (“missing trie node”). Resposta bruta e metadata preservadas; nenhum rendimento calculado. Fontes oficiais consultadas: [1RPC](https://www.1rpc.io/) e [redes](https://docs.1rpc.io/using-the-web3-api/networks), serviço público gratuito informado para 200 requisições/dia. Não repeti as fontes já malsucedidas nem inferi impossibilidade universal.

Contrato CoinGecko confrontado com [market_chart Demo](https://docs.coingecko.com/demo/reference/coins-id-market-chart) e [OHLC Demo](https://docs.coingecko.com/demo/reference/coins-id-ohlc): série diária com ponto recente adicional e frequência intradiária automática, timestamps de fechamento. A correção normaliza disponibilidade, sem reivindicar que o OHLC sintético seja candle negociável ou que volume intradiário ausente seja volume medido. Não houve nova coleta econômica CoinGecko.

## 9. Achados e pendências com critérios de aceite

| ID/prioridade | Problema, causa/evidência | Solução/aceite | Estado |
|---|---|---|---|
| F01 P0 avaliação | Preço anterior à resposta contava como entrada; controle 100→200 | Base futura, mesma fonte, ausência permanece ausente; regressão retorna 0% | corrigido e validado |
| F02 P1 temporal | Índices de linhas confundidos com dias após gap | Sufixo contínuo, rejeição de duplicata/intervalo; indicadores faltantes explícitos | corrigido e validado |
| F03 P1 fonte | OHLC CoinGecko rotulado em frequência inexistente e último ponto parcial | 30m/4h reais, diário normalizado, atraso e volume diário obrigatório | corrigido em contrato/testes; integração conectada dessa fonte não repetida |
| F04 P1 serving | Features antigas sem frescor/fonte/vínculo com previsão | Snapshot atual e limite de 26h antes das chamadas | corrigido; ver novo diagnóstico |
| F05 P1 persistência | Inputs perdidos/resultado dependente de exportação | Migração 0019 preserva registros imutáveis; hash, atomicidade e conflitos testados, inclusive falha de exportação | corrigido; legado não recuperado |
| F06 P1 LLM/cache | JSON inválido mascarado em 50; cache futuro ou malformado; recibo renovável | Fallback explícito e resposta preservada sem segredos; TTL e tipos; recibo original mantido | corrigido e validado |
| F07 P1 segurança/verificação | Scanner lia caches e emitia hashes de potenciais chaves | Arquivos Git publicáveis, sem fingerprints; fallback sem Git; wheels separados | corrigido e validado |
| F08 P1 governança | Novo diagnóstico poderia herdar “validado”/trials antigos | Consumidores descritivos, sem CI/DSR/promoção; H6 congelada byte-idêntica | corrigido e validado |
| F09 P1 integração | Cache V3 ignorava start/end, incluindo futuro fora do pedido | Filtrar intervalo e remover candle de 1h aberto; regressão independente | corrigido; não reexecuta modelo congelado |
| F10 P1 documentação | Promessas de calibração/bitemporalidade/paper excessivas | Errata operacional vinculada; usos limitados explicitamente | corrigido na documentação; validação financeira não concedida |
| D01 P1 Aave | Índices e liquidez ausentes nas 13 fronteiras; nova fonte também falhou | Fonte gratuita com estado histórico da mesma reserva e blocos, identidade, timestamps e liquidez; só então calcular | dependência externa de dados |
| D02 P1 H5/legado | Banco e inputs antigos ausentes nos backups examinados | Backup de previsões com timestamp, juiz, prompt, mercado e notícias; preços públicos não substituem | dependência de informação indisponível |
| D03 P1 completude altcoins | 542 dias somados em 12 pares, observações parciais e identidades | Nova resposta bruta oficial compatível; validar identidade e calendário, reconstruir janelas e versionar derivada; não preencher por estimativa | bloqueia completude universal; pesquisas com exclusões explícitas permanecem reproduzíveis |
| D04 P1 piloto carry | Entrada não registrada após 09/09, 01h UTC; status WAITING antigo | Novo pré-registro, janela futura e diretório próprio; custos, quantidades e critério fixados antes; preservar diário | piloto original terminou sem entrada; tempo passado irrecuperável |
| D05 P1 benefício preditivo | Nenhuma amostra independente do novo contrato, LLM ou notícias | Novo protocolo com universo, baselines, ablação, agrupamento por data, sobreposição, multiplicidade e poder; depois observações futuras | dependência de tempo e nova avaliação; diagnóstico não conta como prova |
| D06 P1 lucro executável | Fees, fills, conta, tamanho, margem, latência, impostos, conversão e custos próprios desconhecidos | Especificação do operador e evidência adequada; contas parciais e limites de custo já entregues, sem credenciais financeiras | dependência de informação e execução autorizada separadamente |
| D07 P1 produção V3 | Família fechada; OI escasso, treino paper retrospectivo e custos aproximados | Não promover. Reabertura só por evidência material e protocolo próprio; preservar resultados | abandonada para promoção sob as definições atuais |
| D08 P2 segurança histórica | Rotação declarada pelo dono; revogação e uso antigo não observáveis | Evidência do painel do provedor; não requer expor a chave novamente | externa, herdada; sem novo incidente |
| D09 P2 componentes secundários | Código/documentos fora do fluxo material não auditados linha a linha; feed opcional CoinGecko intradiário sem volume | Revisão específica antes de novo uso; contrato de volume, vintage e frequência | não invalida diagnóstico BTC; não autoriza nova finalidade |

Os itens F são executáveis resolvidos; os D distinguem dado externo, tempo, informação privada e finalidade abandonada. Não se usa “bloqueado” para esconder um teste local ainda executável: integração/checks pendentes aparecem no topo até terminar. As buscas antigas H5 (52.890 arquivos soltos, 125.575 entradas em 95 aberturas ZIP) e 12 sondas de gaps são evidência da preparação, consultada; não foram repetidas identicamente e não provam esgotamento universal.

Referências para verificar as correções e reproduzir as contas:

| Escopo | Código/contrato | Prova desta rodada |
|---|---|---|
| F01/F08, avaliação posterior à resposta | [backtest](C:/Cripto/pesquisa-20260909/GarimpoInvestimentos/analyzers/backtest.py), [quality_snapshot](C:/Cripto/pesquisa-20260909/GarimpoInvestimentos/quality_snapshot.py) | [Controles da baseline](baseline_defect_witnesses.json), [regressões de dados](C:/Cripto/pesquisa-20260909/tests/test_review_data_contracts.py), [falhas e governança](C:/Cripto/pesquisa-20260909/tests/test_review_failure_boundaries.py) |
| F02/F03, indicadores e candles | [feature_engineering](C:/Cripto/pesquisa-20260909/GarimpoInvestimentos/dpl/feature_engineering.py), [CoinGecko](C:/Cripto/pesquisa-20260909/GarimpoInvestimentos/dpl/providers/coingecko.py) | [Regressões de contrato](C:/Cripto/pesquisa-20260909/tests/test_review_data_contracts.py) e [diagnóstico real](live/result.json) |
| F04/F05, guarda dos inputs | [snapshots](C:/Cripto/pesquisa-20260909/GarimpoInvestimentos/dpl/snapshots.py), [migração 0019](C:/Cripto/pesquisa-20260909/GarimpoInvestimentos/dpl/migrations/_0019_input_snapshots.py), [store](C:/Cripto/pesquisa-20260909/GarimpoInvestimentos/dpl/feature_store.py) | [Regressões de persistência](C:/Cripto/pesquisa-20260909/tests/test_review_input_snapshots.py) e [falhas de exportação](C:/Cripto/pesquisa-20260909/tests/test_review_failure_boundaries.py) |
| F09, janela do cache V3 | [pipeline](C:/Cripto/pesquisa-20260909/GarimpoInvestimentos/v3/pipeline.py) | Testes de contrato acima; [freeze e arquivos preservados](release_validation.json) |
| Engenharia completa | [Runner isolado](work/run_checks.py), [contrato do pacote](work/wheel_check.py) | [Baseline](baseline/validation.json), [final02](final02/validation.json), [pós-merge](postmerge01/validation.json), [integração](integration.json) |
| Conteúdo integral das altcoins | [Reconstrutor separado](work/rebuild_altcoins.py) | [Reconstrução completa](altcoin_full_reconstruction.json), [seletor amostral](altcoin_selector_audit/audit.json) |
| Contas AR/BR/recentes | [Conciliação adicional](work/economic_reconciliation.py) | [AR Decimal](absolute_decimal_audit.json), [BR Decimal](basis_decimal_audit.json), [fontes recuperadas](basis_recovered_source_audit.json), [carry recente](immediate_decimal_audit.json), [decomposição econômica](economic_reconciliation.json) |
| Dependências de Aave e observadores | [Escopo Aave](aave_1rpc/scope.json), [leitor dos diários](work/observer_state.py) | [Resposta da sonda](aave_1rpc/02.json), [estado real dos observadores](observer_state_review.json) |

## 10. Prontidão por finalidade e retomada

| Finalidade | Classificação | Condição objetiva |
|---|---|---|
| Diagnóstico local BTC e guarda de novos inputs | Pronta com limitações que não invalidam esse uso, mediante checks finais registrados no topo | Contrato atual, SQLite íntegro e guarda ligada; sem probabilidade calibrada ou lucro demonstrado |
| Reprodução dos cenários econômicos especificados | Pronta com limitações | Contas e normalizados auditados; hipóteses de execução e histórico usado na seleção dos métodos explícitos |
| Completude histórica universal / H5 exato / Aave | Bloqueada por dependências D01–D03 | Não afirmar recuperação total |
| Prova preditiva, LLM incremental, lucro líquido executável | Bloqueada por D05/D06 | Observações futuras, controles adequados, custos próprios e fills ainda ausentes |
| AR3 e promoção de V3 sob regras atuais | Abandonada por evidência/decisão preservada | Não retunar ou reabrir para produzir resultado favorável |
| Piloto carry original | Sem entrada; não retomável como se tivesse iniciado | D04: novo protocolo antes de janela futura |
| Operação financeira/agendamento/frontend público | Não aplicável à entrega autorizada | Nenhum ativado; código aprovado não concede autorização de capital |

Retomada técnica: `C:\Cripto\CRIPTO.cmd status` e leitura de integration.json/REVISAO.md. Para reproduzir a revisão, executar o runner com **novo identificador** (por exemplo `work/run_checks.py verificacao03`, jamais sobrescrever baseline/final02) e depois work/wheel_check.py com o mesmo identificador. Ele cria outputs sintéticos e ambiente novo em C:\Cripto. Auditorias de dados usam os comandos preservados nos próprios scripts e novos arquivos de saída. Não repetir o diagnóstico conectado sem necessidade; o budget real e os limites persistem.

Antes de qualquer observador, conferir freeze/runtime/diário readonly e o horário do protocolo; não rodar os comandos antigos do runbook de carry como se a entrada ainda estivesse aberta. O caminho da fonte alternativa Aave é reutilizável apenas se surgir suporte público ao estado de arquivo solicitado; não gastar chamadas idênticas à resposta −32000. Para H5, a condição de retomada é encontrar inputs reais antigos, não pedir novamente os mesmos backups ou gerar LLM retroativo.

Nenhuma execução invisível em segundo plano é prometida. CI/integração e seus resultados finais estão no topo. Arquivos temporários, builds, banco anterior e falhas ficam preservados neste diretório/operacao para revisão do dono.

## 11. Revisão conjunta do PR #110 com o #111

Revisão adicional solicitada pelo dono após o fechamento acima. O [PR #110](https://github.com/leonardosovienski/cripto-predictor/pull/110), “Preservar repasse final, dados e estado da revisão em andamento”, permanece draft no commit `4ae9e3d19d4dc7c761d353a8eab851d70f0230e3`. Foi comparado ao main `909724e36d23b1683268c9e43d533f553c7dfe5f`, que contém o #111 validado. O #110 é uma captura intermediária de 22:31 UTC, com horários próprios para os pacotes. **Parecer: não integrar no estado atual.** Não se confunde a integridade dos ZIPs com aprovação do código capturado.

**R110-01 — P1: a combinação automática reintroduz alteração na definição congelada H6.** O #110 acrescenta o filtro `evaluation_contract` dentro de `close_h6_inverted_signal` e `h6_spearman_verdict`, em [backtest.py, linha 755](https://github.com/leonardosovienski/cripto-predictor/blob/4ae9e3d19d4dc7c761d353a8eab851d70f0230e3/GarimpoInvestimentos/analyzers/backtest.py#L755) e linha 827. O #111 preservou exatamente essas funções e colocou as exclusões nos consumidores. A simulação com `git merge-tree`, sem mudar o checkout, incorpora novamente os filtros mesmo sem conflito nesse arquivo. O verificador real confirma: código H6 do main confere com o freeze; código do #110 e código combinado divergem; a trial registrada permanece igual nos três casos. Assim, resolver apenas os três conflitos textuais não produz uma integração válida. Aceite: preservar as funções congeladas e os controles dos consumidores existentes no #111, sem regenerar o freeze para aceitar a alteração; depois passar a trava H6 e os quatro jobs sobre a base atual. [Prova da combinação](pr110/combined_h6_check.json).

**R110-02 — P2: o pacote publica sidecars do orçamento que declara excluir.** O [manifesto, linha 1423](https://github.com/leonardosovienski/cripto-predictor/blob/4ae9e3d19d4dc7c761d353a8eab851d70f0230e3/docs/continuity_20260909/MANIFEST.json#L1423) lista `operacao/dados/api_guard_budget.db-shm` (32.768 bytes) e `api_guard_budget.db-wal` (zero bytes), ambos presentes em `data-operacao.zip`. O `.db` principal está corretamente excluído. O README e `local_only_categories` afirmam excluir WAL/SHM e estado do orçamento; a seleção não aplicou essa exclusão aos sidecars. Eles não formam um backup utilizável do orçamento, e o recuperador os materializa como arquivos de dados. Não se observou vazamento de chaves nem corrupção de banco decorrente disso. Aceite: excluir também os dois sidecars da cópia publicada, atualizar ZIP, manifesto e contagens, mantendo intactos o orçamento real e os pacotes originais; repetir hash/verificação e confirmar ausência dos três caminhos do orçamento.

**Falhas reproduzidas e estado do CI.** No [run 34413466460](https://github.com/leonardosovienski/cripto-predictor/actions/runs/34413466460), container passou; quality, all-extras e python-314-experimental falharam. O log all-extras registra **1.317 pass / três falhas**. Execução local isolada do SHA do #110, sem configuração privada nos testes: **56 pass / as mesmas três falhas** em 91,67 s. São a trava H6, a fixture de ações cujo close excede high e a asserção estrutural que usa o primeiro `store.close()` (ramo de banco vazio), em vez do fechamento após persistir. Esses dois ajustes de teste já estão no #111; não é justificativa para relaxar a validação OHLC ou mover a persistência. A cópia do #110 também antecede as guardas finais que impedem novos diagnósticos de adquirir inferência/trials legados; a integração deve preservar a implementação atual dos consumidores e sua regressão. [Testes locais](pr110/targeted_head_tests.log), [evidência GitHub](pr110/github_review_evidence.json), [diferenças para o main](pr110/diff_from_main.patch).

Os três conflitos encontrados são README.md, tests/test_review_failure_boundaries.py e tests/test_store_history.py. `git merge-tree` foi usado somente como simulação; não houve merge, checkout da branch do PR, push, mudança no PR ou comentário enviado ao GitHub. O checkout operacional permaneceu no main integrado, com apenas o diff original do dono em NEXT_CHAT_PROMPT.md. O conteúdo desse prompt no #110 é igual após normalização das quebras de linha; a diferença de bytes da exportação não é perda de texto.

**Parte de preservação verificada.** Conferidos todos os 22 ZIPs e 9.713 membros contra o manifesto; não houve erro de hash, conflito de conteúdo entre caminhos repetidos ou erro de descompressão. Os 9.523 arquivos das aquisições de dados foram comparados com os originais locais: 9.521 iguais e apenas os dois sidecars transitórios acima diferentes, sem divergência em dados de mercado. A comparação pontual não substitui a auditoria científica dos dados feita nas seções anteriores. A recuperação seletiva de dois ZIPs, sua repetição idempotente, a recusa de um arquivo existente diferente antes de escrever qualquer outro arquivo e a recusa de traversal passaram. [Auditoria dos pacotes](pr110/package_audit.json), [provas de recuperação](pr110/recovery_probes.json).

A inspeção em memória de 659.282.044 bytes, incluindo 5.212 camadas gzip e 427 ZIPs internos, não encontrou correspondências com os segredos atualmente configurados. Não foram persistidos valores nem fingerprints de segredos; isso não certifica ausência de toda chave desconhecida ou revogada. O backup SQLite publicado tem integrity_check=ok, duas previsões, um snapshot de mercado e zero prediction_inputs. Ele representa um instante anterior ao diagnóstico final com três previsões e um input, não uma cópia desse diagnóstico final.

**Continuidade depois dos dois PRs.** O #110 preserva material útil, mas não contém integration.json, final02/validation.json, postmerge01/validation.json nem live/result.json da conclusão. Essa ausência é compatível com a captura datada e declarada; não é corrupção do pacote. Para torná-lo o ponto atual de retomada, acrescente uma atualização separada com o #111, este registro final, seus comprovantes e a janela de carry perdida; preserve a captura anterior identificada pela data. Depois mantenha no diff de integração apenas o valor adicional da continuidade, sem reintroduzir código intermediário. Nenhuma republicação, eliminação de pacote original, alteração de quota ou ativação de observador foi feita nesta revisão do PR.
