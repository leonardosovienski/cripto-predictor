> For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://docs.ethena.fi/backing-assets/protocol-revenue.md).

# Protocol Revenue

Ethena generates revenue from its backing assets. As the backing portfolio has diversified, so have the sources of that revenue, which now span several distinct and largely uncorrelated streams.

Protocol revenue is generated from:

* **Funding and basis spread.** The funding and basis earned on delta-neutral basis trades, in crypto markets and, increasingly, in non-crypto markets such as tokenised commodities. Historically, the mismatch between demand and supply for leveraged exposure has resulted in a positive funding and basis return over time.
* **Lending revenue.** The return earned on investments in overcollateralised loans of stable assets, supplied both into on-chain DeFi lending markets and to institutional counterparties.
* **Real-world asset yield.** The yield earned on tokenised real-world assets held as backing, including short-duration government debt and high-liquidity credit.
* **Liquid stablecoin rewards**. Rewards earned on liquid stablecoin holdings, depending on the asset and where it is held.

The central purpose of diversifying the backing portfolio is to diversify protocol revenue and risk. A model concentrated in a single strategy ties overall risk to a single set of market dynamics; spreading exposure across funding, lending, real-world assets, and stablecoin rewards reduces the likelihood of stress to the Ethena system resulting from revenue compression across all sources at the same time.&#x20;

Each stream responds to different drivers, so weakness in one can be offset by strength in others, producing a revenue base and risk profile designed to be more resilient across market cycles.

Periods of negative protocol revenue are designed to be borne by the Reserve Fund. See the [Reserve Fund](/protocol-overview/reserve-fund.md) section below.&#x20;


---

# Agent Instructions
This documentation is published with GitBook. GitBook is the documentation platform designed so that both humans and AI agents can read, navigate, and reason over technical content effectively. Learn more at gitbook.com.

## Querying This Documentation
If you need additional information that is not directly available in this page, you can query the documentation dynamically by asking a question.

Perform an HTTP GET request on the current page URL with the `ask` query parameter, and the optional `goal` query parameter:

```
GET https://docs.ethena.fi/backing-assets/protocol-revenue.md?ask=<question>&goal=<endgoal>
```

`ask` is the immediate question: it should be specific, self-contained, and written in natural language.
`goal` is optional and describes the broader end goal you are ultimately trying to accomplish on behalf of the user. GitBook uses it to tailor the answer towards what is most useful for that goal.

The response will contain a direct answer to the question and relevant excerpts and sources from the documentation.

Use this mechanism when the answer is not explicitly present in the current page, you need clarification or additional context, or you want to retrieve related documentation sections.
