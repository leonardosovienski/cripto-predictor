> For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://docs.ethena.fi/protocol-overview/risks/funding-risk.md).

# Funding Risk

## Context

Given Ethena uses derivatives positions, such as perpetual contracts, to hedge the delta of the backing assets, the protocol is exposed to "Funding Risk".

"Funding Risk" relates to the potential of persistently negative funding rates. Ethena is able to earn revenue from funding, but could also be required to pay funding.

While this is a direct risk to the protocol revenue and backing, the data presented below demonstrates that negative funding periods tend not to persist and revert to a positive mean.

Negative funding rates are a feature, rather than a bug of the system. USDe has been built with this in mind.

We acknowledge that historical data before Ethena's launch does not reflect Ethena's impact on the market. We are monitoring updated funding rate dynamics and will provide updates to this section as we collect the new data.

## How Ethena manages Funding Risk

An Ethena reserve fund exists and will step in on occasions when the combined revenue between LST assets, such as stETH, the funding rate for a short perpetual position, the basis from short dated futures as well as potential rewards from holding liquid stables, is negative. This seeks to protect the spot backing underpinning *USDe*. Ethena does not pass on any "negative revenue" to users who stake *USDe* for *sUSDe*.\
\
Ethena also adopts a dynamic allocation approach to the assets backing USDe. In periods of low or negative funding, more of the backing assets of USDe will be shifted into liquid stables earning approximately the U.S Treasury rate. This aims to reduce the exposure to negative funding rates and thus reduce the possibility of the Reserve Fund being drawn from. See the Dynamic Allocation section for more details.

### **Positive Bias**

*BTC and ETH* funding rates have exhibited natural positive bias and contango, with an average annualized rate of between 7.8% - 9% over the last 3 years on an open interest or volume-weighted basis, including the 2022 bear market.

<figure><img src="/files/skBe4MqtFpDEtkz31cBS" alt=""><figcaption><p>Data updated as of 31st December 2024</p></figcaption></figure>

Below represents the 30d moving average of funding rates, indicating that positive bias is evident, particularly in 2021 and 2023.

<figure><img src="/files/tPlNmWbihFctqQcVbXpP" alt=""><figcaption></figcaption></figure>

<figure><img src="/files/zQFwkw6F9sRBAWKMZR4I" alt=""><figcaption></figcaption></figure>

Charting the distribution of funding rates per contract, one can further see the positive bias per exchange, with the coloured box per contract indicating the middle 50% of datapoints. That middle 50% of funding data is predominantly positive values on most exchanges.

<figure><img src="/files/QRr2WmC34RhdqSVgMrrF" alt=""><figcaption></figcaption></figure>

<figure><img src="/files/jJkjMV9PJiJFJRAZvTKg" alt=""><figcaption></figcaption></figure>

<figure><img src="/files/inj2j8MyGXaLwj6H67j1" alt=""><figcaption></figcaption></figure>

<figure><img src="/files/MMiqCEdr8CpFcx3o41V8" alt=""><figcaption></figcaption></figure>

### **Margin of Safety**

Using LST collateral, such as *stETH,* as collateral for *USDe,* provides an additional margin of safety for negative funding in the form of the \~3% annualized returns earned on *stETH*.&#x20;

A reward-accruing liquid stables allocation also aims to provide an additional margin of safety, including the dynamic allocation approach mentioned above.

{% hint style="info" %}
That is to say, protocol revenue will only be negative when the combined *LST* yield, revenue from liquid stables, and funding rate sum to be negative.
{% endhint %}

Looking at annualized funding rate values, one observes 17.5% and 15.9% of days had a sum negative return for *ETH* and *BTC* perpetual futures respectively, with an average return over the entire period of 9.15% for ETH versus 7.80% for *BTC*. &#x20;

Combining annualized staked ETH income and *ETH* funding rate values, one observes only 8.84% of days had a sum negative revenue. This excess revenue could be seen as an upper bound to protocol revenue.

<figure><img src="/files/rtNcVOF9MgAu6I7srytY" alt=""><figcaption></figcaption></figure>

<figure><img src="/files/p45iWlm55XnepAT6AQzg" alt=""><figcaption></figcaption></figure>

There has only been one quarter in the last 3 years where the average sum return was negative and this data was polluted by the *ETH* PoW arbitrage period which was a one-off event that dragged funding deeply negative.

<figure><img src="/files/hwwwJghtTRCbnlQc2DvA" alt=""><figcaption><p>Q4 2024 as of October 2024</p></figcaption></figure>

### **Mean-reversion**

Funding rates have displayed mean-reverting characteristics, which is to say they may dip negative but those rates do not persist and don't drift lower over time. Positive baseline funding on some of the biggest derivative exchanges, with over 50% of open interest (Binance & Bybit), help keep funding rates naturally positive.

Reversion to a positive mean can be seen in the longest consecutive days of either positive or negative funding rates. Negative funding rates revert quicker thanks to the dynamics described above, with the longest streak of consecutive days with negative funding lasting just 13 days.

The longest streak of positive funding days has been 176 days, set between late 2023 and early 2024 and charted below.

<figure><img src="/files/AwIiXznxp5vmGupTKeGF" alt=""><figcaption></figcaption></figure>

For a more detailed explanation on the distribution of funding rates as it relates to *USDe*, please read this Twitter [thread](https://twitter.com/leptokurtic_/status/1682781070121652224?s=20) from the Ethena Labs founder on the topic.


---

# Agent Instructions
This documentation is published with GitBook. GitBook is the documentation platform designed so that both humans and AI agents can read, navigate, and reason over technical content effectively. Learn more at gitbook.com.

## Querying This Documentation
If you need additional information that is not directly available in this page, you can query the documentation dynamically by asking a question.

Perform an HTTP GET request on the current page URL with the `ask` query parameter, and the optional `goal` query parameter:

```
GET https://docs.ethena.fi/protocol-overview/risks/funding-risk.md?ask=<question>&goal=<endgoal>
```

`ask` is the immediate question: it should be specific, self-contained, and written in natural language.
`goal` is optional and describes the broader end goal you are ultimately trying to accomplish on behalf of the user. GitBook uses it to tailor the answer towards what is most useful for that goal.

The response will contain a direct answer to the question and relevant excerpts and sources from the documentation.

Use this mechanism when the answer is not explicitly present in the current page, you need clarification or additional context, or you want to retrieve related documentation sections.
