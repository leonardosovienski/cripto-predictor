> For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://docs.ethena.fi/protocol-overview/risks/backing-assets-risk.md).

# Backing Assets Risk

## **Context**

Given Ethena uses some stETH and other LSTs in part to margin the delta hedging derivatives positions, the integrity and confidence in those assets is paramount. "Backing Assets Risk" in this context refers to the fact that a backing asset for USDe differs from the underlying asset of the perpetual futures position.

Ethena is agnostic to Ethereum LSTs. While *stETH* market share initially looked to be winning in a winner's take-all market, its market share has dramatically been reduced by other assets such as Mantle's *mETH*.

As in these cases the backing asset, *ETH LSTs*, is different to the underlying asset of the hedging contracts, *ETH*, Ethena needs to ensure the price difference between those two assets is as small as possible. This is accomplished by supporting LST assets with the least chance of depegging and broad industry support.

As discussed in the [liquidation risk](/protocol-overview/risks/liquidation-risk.md) section, due to low leverage and tighter collateral haircuts, the impact of a stETH depeg is minimal to hedged positions and the possibility of liquidation is extremely unlikely.&#x20;

Staked Ethereum assets make up just \~6% of the backing assets of USDe as of January 2025.


---

# Agent Instructions
This documentation is published with GitBook. GitBook is the documentation platform designed so that both humans and AI agents can read, navigate, and reason over technical content effectively. Learn more at gitbook.com.

## Querying This Documentation
If you need additional information that is not directly available in this page, you can query the documentation dynamically by asking a question.

Perform an HTTP GET request on the current page URL with the `ask` query parameter, and the optional `goal` query parameter:

```
GET https://docs.ethena.fi/protocol-overview/risks/backing-assets-risk.md?ask=<question>&goal=<endgoal>
```

`ask` is the immediate question: it should be specific, self-contained, and written in natural language.
`goal` is optional and describes the broader end goal you are ultimately trying to accomplish on behalf of the user. GitBook uses it to tailor the answer towards what is most useful for that goal.

The response will contain a direct answer to the question and relevant excerpts and sources from the documentation.

Use this mechanism when the answer is not explicitly present in the current page, you need clarification or additional context, or you want to retrieve related documentation sections.
