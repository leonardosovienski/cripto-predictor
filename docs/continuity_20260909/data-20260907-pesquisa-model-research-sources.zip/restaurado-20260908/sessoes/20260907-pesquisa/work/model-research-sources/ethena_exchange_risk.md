> For the complete documentation index, see [llms.txt](https://docs.ethena.fi/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://docs.ethena.fi/protocol-overview/risks/exchange-failure-risk.md).

# Exchange Failure Risk

## Context <a href="#what-happens-in-the-event-of-a-bankruptcy-of-an-exchange" id="what-happens-in-the-event-of-a-bankruptcy-of-an-exchange"></a>

Ethena utilizes derivatives positions to offset the delta of the protocol backing assets. These derivatives positions are traded upon CeFi exchanges such as Binance, Bybit, Bitget, Deribit, and Okx. As such, in the event an exchange were to suddenly become unavailable such as FTX, Ethena would need to manage the consequences. This is the "Exchange Failure Risk" we are referring to.

{% hint style="info" %}
Protocol backing is NEVER deposited to exchanges and always resides with "Off Exchange Settlement" providers. Ethena has made significant efforts to minimize exposure to exchange failures.
{% endhint %}

## What happens in the event of a failure of an exchange? <a href="#what-happens-in-the-event-of-a-bankruptcy-of-an-exchange" id="what-happens-in-the-event-of-a-bankruptcy-of-an-exchange"></a>

Ethena retains complete control and ownership of the assets via Off-Exchange Settlement providers with no backing assets ever being deposited with any exchange. This limits Ethena's exposure to idiosyncratic events on any one exchange to the outstanding PnL between Off-Exchange Settlement providers' settlement cycles.

> Copper's Clearloop runs a settlement cycle daily.

As such, in the event of an exchange failure, Ethena would delegate the backing assets to another exchange and hedge the outstanding delta that was previously covered by the failed exchange. In the event of an exchange failure, the derivatives positions are considered closed with Ethena holding/owing no further obligation to the exchange estate.

Capital preservation is front of mind for Ethena. In the event of extreme circumstances, Ethena will always work to protect the value of the backing assets & *USDe* stable peg.

## How is the exchange failure risk managed?

As with all parts of Ethena' workflows, Ethena is agnostic to each provider at each step of the workflow.&#x20;

* Ethena diversifies the risk and mitigates the potential impact of exchange failure by utilizing multiple exchanges.
* Ethena is continually integrating with new sources of liquidity in an effort to limit the protocol's exposure to each source.
* Ethena actively monitors the ecosystem with investors, advisors, and friends across the industry, taking a proactive approach to de-risking exchange exposure if associated risks are perceived to have changed.

Ethena's strategy involves a portfolio allocation across different instruments and venues:

* 7% liquid cash (no intraday risk)
* 3% deliverable futures
* 90% perpetual futures, allocated as:
  * **Binance** (50%): Daily settlement, 3 funding cycles
  * **Bybit** (25%): 2-hour settlement, 1 funding cycle
  * **OKX** (15%): 4-hour settlement, 1 funding cycle
  * **Deribit** (5%): Daily settlement, 3 funding cycles
  * **Bitget** (5%): 4-hour settlement, 1 funding cycle

Ethena distribution across hedging venues can be viewed in our [transparency dashboards.](https://app.ethena.fi/dashboards/transparency)


---

# Agent Instructions
This documentation is published with GitBook. GitBook is the documentation platform designed so that both humans and AI agents can read, navigate, and reason over technical content effectively. Learn more at gitbook.com.

## Querying This Documentation
If you need additional information that is not directly available in this page, you can query the documentation dynamically by asking a question.

Perform an HTTP GET request on the current page URL with the `ask` query parameter, and the optional `goal` query parameter:

```
GET https://docs.ethena.fi/protocol-overview/risks/exchange-failure-risk.md?ask=<question>&goal=<endgoal>
```

`ask` is the immediate question: it should be specific, self-contained, and written in natural language.
`goal` is optional and describes the broader end goal you are ultimately trying to accomplish on behalf of the user. GitBook uses it to tailor the answer towards what is most useful for that goal.

The response will contain a direct answer to the question and relevant excerpts and sources from the documentation.

Use this mechanism when the answer is not explicitly present in the current page, you need clarification or additional context, or you want to retrieve related documentation sections.
