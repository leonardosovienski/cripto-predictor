# Revisão completa iniciada em 09/09/2026

Registro vivo único. Estado: **em revisão**, sem conclusão de prontidão ou lucro.

## Mandato, versão e preservação

Revisão integral autorizada por `C:\Cripto\AGENTS.md` e pelo repasse local `docs/NEXT_CHAT_PROMPT.md`. Trabalho individual, somente em C:\Cripto; nenhuma ordem, credencial financeira, conta, pagamento ou automação. Capital permanece desautorizado. Originais restaurados, protocolos, charters e o diff documental do dono são preservados.

Estado inicial diretamente verificado: branch `fix/data-readiness-20260909`, HEAD e origin/main local `276d6db224f266e9ec889b6de4ab5ba0328cc321`. Consulta `git ls-remote origin refs/heads/main` confirmou o mesmo SHA remoto. Único diff inicial: `docs/NEXT_CHAT_PROMPT.md`. Cópia byte a byte e diff preservados em `baseline/`. O snapshot restaurado permanece no worktree main `522de73`.

## Linha de base e protocolo desta revisão

Comandos, ambiente, versões, hashes de fontes, tempos e resultados em `baseline/validation.json`. Credenciais de teste sintéticas; dotenv privado excluído; saídas isoladas em `C:\Cripto\operacao\temporarios\revisao-baseline`. A execução de baseline antecede alterações comportamentais.

Verificações: instalação locked com todos os extras, ruff, formato, pyright, scanner, build, suíte completa com cobertura, Windows status/help, instalação nova fora do checkout. Docker local não encontrado no PATH; a evidência remota anterior é a consulta dos quatro jobs do run 34403156484, todos success, sobre a base. Não equivale a CI de correções futuras.

Primeira falha registrada: `python -m pyright` encontrou o alias Microsoft Store, não o ambiente .venv (15 erros de imports). Rechecagem pela entrada do CI `CRIPTO.cmd uv run --no-sync pyright` em andamento. Não se alteram regras de tipagem para passar.

Orçamento de revisão: examinar todos os fluxos ativos e dependências materiais; reconstruir dados e contas com artefatos preservados; corrigir defeitos demonstrados com regressões; uma rodada final de checks por versão, repetida somente se alteração/falha justificar. Não se inicia busca de parâmetros vencedores. Recuperações conectadas exigem pergunta e teto próprios antes das chamadas e consideração das tentativas já preservadas. Nenhuma nova hipótese econômica foi aberta.

## Cobertura (atualizada durante o trabalho)

Examinados diretamente: instruções, configuração local, mandato econômico, repasse, CI/empacotamento, política de merge, mapa de entradas, main, local_runtime, cache, orçamento API, notícias, ingestão, features, providers CCXT/CoinGecko, persistência/serving e ancoragem do backtest. Leitura direta dos documentos operacionais iniciais, resultados econômicos e charter; HYPOTHESES lido parcialmente, não integralmente. V3: pipeline e parte do regime_engine lidos diretamente. Demais módulos e testes: inventariados, exame material em andamento. Arquivos históricos não são considerados examinados apenas pela listagem.

## Matriz de afirmações e pendências em investigação

| ID | Afirmação/origem/versão | Significado e uso | Evidência necessária | Verificação e resultado | Estado | Impacto e ação |
|---|---|---|---|---|---|---|
| C01 | Perfil local confina saídas configuradas (base 276d6db) | Armazenamento operacional | Caminhos resolvidos e testes de escape | status real correto; revisão de local_runtime e testes em andamento | parcialmente comprovada | Não é sandbox para comandos arbitrários |
| C02 | Nova linha de base completa | Engenharia | Checks próprios sobre estado registrado | Em execução; falha de descoberta do Python pelo pyright preservada | não verificada | Concluir checks e instalação isolada |
| C03 | Diário Binance contém só candles fechados | Features causais | Timestamp de abertura/fechamento, fonte, casos extremos | Código remove candle aberto e reserva linha extra; conteúdo global ainda em exame | parcialmente comprovada | Confirmar ingestão e consumo temporal |
| C04 | Fallback CoinGecko equivale à frequência pedida | Dados usados como OHLCV | Contrato oficial e resposta representativa | /ohlc retorna granularidade automática; código rotula com intervalo solicitado sem validar | em investigação | Reproduzir incompatibilidade e corrigir contrato |
| C05 | Feature Store e previsões bastam para reprodução bitemporal | Reanálise exata | Inputs, publicação, coleta, versões e vínculos persistidos | raw_market_data faz upsert; features só v1 no serving; previsão perde ts do mercado e conteúdo das notícias | parcialmente comprovada | Delimitar capacidade real e resolver preservação futura |
| C06 | Score e retorno medem previsão posterior | Validade científica | Entrada temporal, preço-base disponível na decisão, alvo consistente | main carimba agora mas usa último candle sem frescor; backtest parte do preço salvo e dia-alvo | em investigação | Reproduzir viés antes de mudar cálculo |

As conclusões "existe", "funciona no escopo exercitado", "correto frente à referência" e "validado para o uso" serão preenchidas separadamente no mapa final. Suspeitas ainda não são achados confirmados.

## Dependências herdadas a reconferir

H5: banco/inputs antigos não encontrados nas buscas preservadas; preços públicos não reconstituem respostas antigas de LLM. Aave: índice e liquidez em 13 limites semanais ausentes; seis sondas adicionais anteriores falharam por acesso a arquivo histórico. Altcoins: lacunas com 12 sondas anteriores sem recuperação, 542 dias somados entre pares, sem alegação de esgotamento universal. Futuro independente, custos próprios e condições de conta ainda não disponíveis. Cerebras geração HTTP 402 permanece excluída. Cada item terá evidência, efeito e condição de retomada; não se repetem perguntas já respondidas.

## Entrega ao dono/investidor

Ainda em revisão. Nenhum ganho econômico novo demonstrado. Evidência anterior favorável e desfavorável será reconciliada sem somar cenários que usam os mesmos 5.000 USDT hipotéticos. O encerramento exigirá distinção entre dependência externa e trabalho ainda executável.
